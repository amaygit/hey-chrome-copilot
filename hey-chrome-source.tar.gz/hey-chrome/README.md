# Voice turn-taking update — 1.6.0

Speech fragments now collect into one editable draft. By default, sending waits for 3 seconds of silence and for interim recognition to finish; sustained local microphone activity extends that wait. Choose 2/3/5 seconds or manual Send. Uncertain recognition is held for review instead of guessed. Speech received during a running request is retained, and intermediate browser steps are no longer read aloud.

Microphone capture now stays open with echo cancellation and a local amplitude monitor. A detected wake phrase cancels speech immediately; sustained louder microphone input can also cancel playback before transcription. This is a local speech-activity heuristic, not a dedicated offline wake-word model. It can miss quiet speech or react to loud background sound. Headphones help. Stop reading remains available, and the activity interrupt can be disabled independently.

Flight day/month fragments are saved across turns and restored sessions. A month-only reply asks for its day; a known passenger count is preserved. Invalid date corrections ask for a valid date. No new key, model change, paid service or extension permission was added. API keys do not determine speech recognition quality.

# Voice and loading update — 1.5.1

The side panel and voice companion now show an animated loading card with the actual task phase and elapsed time. While a reply is spoken, speech recognition remains active; saying Hey Chrome interrupts playback immediately on the detected wake phrase and opens the follow-up window. A bare wake phrase does not cancel an in-progress browser task; say Hey Chrome, stop for that. Reading remains muted until a new command after interruption so late task updates do not immediately start speaking again. A Stop reading button is available as a manual fallback. Reduced-motion preferences are respected.

Wake interruption logic is covered by simulated recognition/synthesis event tests. Real microphone, speaker echo and recognition accuracy vary by Chrome and hardware and are not certified by those tests. Keep the companion tab open and listening.

# Hey Chrome 1.5 — shared universal browser assistant

Chrome voice/text assistant + persistent Gemini backend, with named member access, current-source research and a second check of proposed actions. Flights are just one example; the main flow supports general research, shopping comparisons, reading pages, ordinary forms and navigation.


## Reduce API usage

- Say **Hey Chrome, quick search how does a solar eclipse happen** (or type **quick search ...**). This opens a normal Google page and reads an available AI Overview or visible result snippets, with zero Gemini/search API requests. Google excerpts are labeled unverified and excluded from trusted assistant context. Availability and browser verification prompts still apply.
- **open https://example.com**, **scroll down**, **scroll up**, and **go back** also execute without AI calls. Review mode is respected when enabled.
- Normal research, comparisons and booking workflows retain Gemini planning/checking. With page sharing and Google permission enabled, the default research path opens Google instead of calling the search API. Turn off **Use Google pages for research** to use configured backend providers (Tavily keyless first).
- Only compact result cards, links and optional Overview text are sent for Google searches. Repeated historical page copies are bounded, while the last user requests remain available through long action sequences.

Google's website is not an unlimited API. AI Overviews may be absent or inaccurate. Search cards are snippets, not proof that the original source was read. Verify important claims on source pages; login, CAPTCHA and payment remain manual.

**Hosted backend:** https://hey-chrome-copilot.onrender.com · **Source:** https://github.com/amaygit/hey-chrome-copilot

Use the pre-connected personal extension on client computers. They need no local Node server or .env file. Render Free may take about a minute to wake. The active model is Gemini 3.1 Flash-Lite: planning and independent verification were tested live. Browser research avoids dedicated search API quotas. The optional backend search path tries configured independent providers and keeps raw provider quota errors out of ordinary chat.

## Your private copy is already configured

The **private ready-to-run package** has your supplied keys saved in the backend `.env` and its extension pre-connected using `extension/connection.local.json`. There is no need to paste keys each time, each restart, or into every member's extension. The first key is used for planning and search; the second key is used for verification. They can be changed later in one place on the server.

Keep the private server package for yourself. It contains credentials. Share only a named member's generated **extension** package; those packages contain a revocable personal access code, never a Gemini key.

1. Install Node.js 22+ if needed, then double-click **start.cmd**. Leave the backend running.
2. In Google Chrome, open `chrome://extensions`, enable Developer mode, choose **Load unpacked**, and select this folder's **extension** directory.
3. Pin and open **Hey Chrome · Voice Copilot**. The personal connection is already filled in. You can check it with Settings → Test.
4. Try “Help me find a laptop.” Answer its questions. Routine actions run automatically by default; Stop interrupts the task.
5. To read/control a page: select its tab → **Use current tab** → **Allow this site**. Page sharing goes to Gemini. Grant access separately for new domains.
6. For speech: **Voice mode** → **Start listening** → allow the microphone. Keep its companion tab open and say “Hey Chrome” followed by your request. Follow-up speech is accepted for 45 seconds after a reply. Use the panel to Stop or Resume a paused task.

For a source-only package without private configuration, run `node scripts/setup.mjs` once, set the backend's Gemini key once, and generate a pre-connected owner extension:

```powershell
node --env-file=.env scripts/member.mjs owner "Owner"
```

## Use it on any computer and share by name

Use one always-on backend with an HTTPS address. Install a pre-connected extension on each computer. The central server retains the Gemini keys, so members do not manage `.env` files or API credentials. Each computer controls its own Chrome; this is not remote control of another machine.

```powershell
# Run from the private server project, using your actual server address.
node --env-file=.env scripts/member.mjs add "Alex" https://assistant.your-domain.example
node --env-file=.env scripts/member.mjs list
node --env-file=.env scripts/member.mjs revoke MEMBER_ID
```

The add command writes a member extension under **exports/** and records a token hash in **.data/access.json**. Share that member's extension folder with that person. On first use, they click Settings → Save or Test to allow the HTTPS server connection. Their access can be revoked without changing the Gemini keys. Display names are labels for access codes; they are not verified email identities. No mailbox access is needed and no email is sent automatically.

See **[SHARING.md](SHARING.md)** for hosting, named access and costs. The backend is now deployed on Render Free at https://hey-chrome-copilot.onrender.com. See RENDER-DEPLOYMENT.md for the current configuration and membership updates. Personal conversation tabs are separate, and chat history is not synchronized between computers.

## How the accuracy features work

1. **Understand and clarify:** the planner identifies missing essential requirements before proposing actions. Flight essentials also receive deterministic date, passenger and trip-type validation.
2. **Research current evidence:** the planner can propose a public search query. In automatic mode, the server tries Grok web search when configured, then Gemini Google Search grounding and passes the retrieved sources into the next planning step. It does not treat an unsourced model answer as grounded research.
3. **Check the next step:** with `HIGH_ACCURACY=true`, a separate verification call checks proposed actions and researched answers against your request and available evidence. It can ask a question or withhold the action. Verification failure does not fall back to running an unchecked action.
4. **Verify execution:** the browser reports what actually happened. Element identity, labels, page URL, snapshot freshness and approval ID are checked before acting. Actions are never automatically replayed; a transient Gemini HTTP 503 gets at most one generation retry.

Separate keys organize the roles. They do not create intelligence or guarantee correct answers. Keys in the same Google project share project-level quotas. You can use different supported models for the planner, search and verifier; independent model choices can reduce some correlated errors, but no accuracy percentage has been measured for this project.

Grounded search uses public web information; a source link alone does not prove a claim. Flight inventory, live prices, product stock and selected website filters must still be verified on the actual provider page. Research queries are displayed before transmission; avoid putting private page content or secrets into them.

## Configuration

All AI credentials belong only to the private backend `.env`:

| Setting | Purpose |
| --- | --- |
| `GEMINI_API_KEY` / `GEMINI_MODEL` | Planner and default AI credential/model |
| `GEMINI_SEARCH_API_KEY` / `GEMINI_SEARCH_MODEL` | Optional separate grounded research credential/model; blank key reuses the main key |
| `GEMINI_VERIFY_API_KEY` / `GEMINI_VERIFY_MODEL` | Verification credential/model; blank key reuses the main key |
| `HIGH_ACCURACY` | `true` enables the verification step; `false` uses the basic planner with deterministic checks |
| `ASSISTANT_NAME` | Display name used by newly generated extension packages |
| `BACKEND_TOKEN` | Private owner access code; separate from Gemini credentials |
| `HOST` / `PORT` | Local default `127.0.0.1:8787`; use `0.0.0.0` only behind your HTTPS deployment |
| `ALLOWED_EXTENSION_IDS` | Comma-separated allowed extension IDs, or `*` for authenticated testing with unpacked installations |
| `ACCESS_FILE` | Named member registry; default `.data/access.json` |
| `DEMO_MODE` | `true` switches to the offline flight example provider |

`start.cmd` loads the same saved `.env` every time. `setup.mjs` preserves existing configuration. Restart the backend after changing AI settings. Member additions and revocations are read on subsequent requests without restarting it.

## Voice and browser boundaries

Voice uses Chrome speech recognition and browser text-to-speech. English (India/US) and Hindi recognition are selectable. Chrome may send audio to its speech service. Recognition pauses while replies are spoken. “Hey Chrome, stop” cancels a request; “Hey Chrome, stop listening” stops the microphone. The wake phrase requires an open listening tab and an initial user click. It cannot work when Chrome is closed, and Chrome may suspend background tabs.

The extension reads bounded visible top-frame text and at most 120 controls on the selected, permitted tab. Hidden fields, input values, scripts and contenteditable text are excluded, but visible text can still contain personal information. Cross-origin frames, canvas UI, closed shadow roots, restricted Chrome pages, some PDFs and all dynamic sites are not covered. The assistant cannot silently read all your tabs.

Routine searches, navigation, clicks, ordinary fills, scroll and back run automatically by default. Turn this off in Settings to review every step. Action proposals expire after two minutes. Navigation opens a new tab. Enable Settings → Allow browsing across websites once to read and control subsequent pages; Chrome requires this one-time permission. There is a limit of 30 automatic actions per request; Resume starts a fresh bounded run. Supported browser actions are HTTPS navigation, click, ordinary field fill, scroll and back. The assistant can work through reversible booking steps up to checkout, pause for login/CAPTCHA/payment, and resume after you complete the manual step. No shell execution, arbitrary JavaScript, secret entry, CAPTCHA solving, uploads, payment or final booking submission is implemented. Complete sensitive/irreversible steps yourself. Label/keyword checks are extra safeguards, not a universal classifier of all sites.

## Data and access

The server supports separate in-memory conversation namespaces for each named access code and keeps bounded context for up to an hour, pruned on requests. New chat resets it; a server restart clears conversation history. The extension keeps chat state in `chrome.storage.session`; its connection preference uses local extension storage. Generated connection packages contain personal bearer codes; anyone holding one can act as that member until it is revoked. There is no email login or multi-factor authentication in this starter.

The server requires 32+ character credentials, restricts web origins to extension origins, supports an optional extension-ID allowlist, limits request sizes, and applies per-member/global request limits. These request limits are not a monetary spending cap. `.env`, `.data`, `exports` and personal connection files are excluded from Git. Docker build context excludes private settings and connection files. Application code does not log credentials or chat text.

Long-running AI work uses authenticated jobs that the extension polls; this prevents the Chrome background worker from waiting on one long HTTP response. Job reads/cancellation are restricted to the same member. The server's job deadline is 110 seconds. AI timeouts, quota exhaustion and third-party site restrictions can still stop a task.

## Verification and previews

```powershell
node scripts/check.mjs
node --test tests/*.test.mjs
node --env-file=.env scripts/check-gemini.mjs
# Optional live calls using your Gemini quota:
node --env-file=.env scripts/smoke-live.mjs
```

The offline suite exercises shared-user isolation, revocation, private jobs, cancellation, explicit search approval, grounded-source handling, independent checks, model contracts and browser action validation. These checks do not measure real-world assistant accuracy.

For a simulated UI preview, run `preview.cmd` and open http://127.0.0.1:8788. It makes no AI calls and has no Chrome-control privileges. `start-demo.cmd` exercises the extension with an offline flight-only test provider; the real Gemini provider is universal. See **VERIFICATION.md** for observed results and limitations.

Official references: [Gemini Search grounding](https://ai.google.dev/gemini-api/docs/google-search), [rate limits](https://ai.google.dev/gemini-api/docs/rate-limits), [pricing](https://ai.google.dev/gemini-api/docs/pricing), [Chrome side panel](https://developer.chrome.com/docs/extensions/reference/api/sidePanel).

## Repeatable browser QA without a payment card

Run `node --env-file=.env qa/server.mjs` from this project, then open http://127.0.0.1:8789. The lab runs production content/background scripts against real browser DOM with simulated Chrome APIs and a fake booking site. Buttons exercise a fresh random reading code, native input events, dropdowns, stale targets, delayed updates, manual login handoff and Resume to payment. All payments are disabled. Live reading/booking tests use your existing Gemini allowance; DOM checks do not call AI. The lab binds only to loopback and is never started by the production server.
