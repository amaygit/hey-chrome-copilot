// Isolated-world code only; never evaluate page text or execute model-generated JavaScript.
if (!globalThis.__heyChromeInstalled) {
  globalThis.__heyChromeInstalled=true;
  let snapshotId='', snapshotURL='', nodes=new Map();
  const sensitive=el=>/password|credit.?card|cc-number|cc-csc|cvv|cvc|otp|one.?time|passport|social.?security|payment/i.test([el.type,el.name,el.id,el.autocomplete,el.getAttribute('aria-label'),el.placeholder].join(' '));
  const visible=el=>{const r=el.getBoundingClientRect(),s=getComputedStyle(el);return r.width>0&&r.height>0&&s.visibility!=='hidden'&&s.display!=='none'&&!el.closest('[aria-hidden="true"], [inert]');};
  const label=el=>(el.getAttribute('aria-label') || (el.labels ? Array.from(el.labels).map(x=>{const copy=x.cloneNode(true);copy.querySelectorAll('input,textarea,select,button').forEach(control=>control.remove());return copy.textContent;}).join(' ') : '') || el.getAttribute('placeholder') || (!['INPUT','TEXTAREA','SELECT'].includes(el.tagName) ? el.innerText : '') || el.getAttribute('title') || el.name || el.tagName).trim().replace(/\s+/g,' ').slice(0,180);
  function settlePage(){
    return new Promise(resolve=>{
      const start=performance.now();let last=start;
      const observer=new MutationObserver(()=>last=performance.now());
      observer.observe(document.body,{subtree:true,childList:true,characterData:true});
      const tick=()=>{
        const now=performance.now(),loading=Array.from(document.querySelectorAll('[aria-busy="true"],[role="progressbar"]')).some(visible);
        if(now-start>=3000 || (now-start>=350&&now-last>=200&&!loading)){observer.disconnect();resolve();}
        else setTimeout(tick,100);
      };tick();
    });
  }
  function readPage() {
    snapshotId=crypto.randomUUID(); snapshotURL=location.href; nodes=new Map(); const elements=[];
    const controls=[...document.querySelectorAll('input,textarea,select,button,[role="button"]'),...document.querySelectorAll('a[href],[role="link"]')];
    for(const el of new Set(controls)) {
      if(elements.length>=120) break;
      if(!visible(el) || el.disabled || el.type==='hidden') continue;
      const id=`el-${elements.length+1}`, name=label(el);
      const isSensitive=sensitive(el);
      nodes.set(id,{el,label:name,type:el.type});
      elements.push({id,tag:el.tagName.toLowerCase(),type:el.type || el.getAttribute('role') || '',label:isSensitive?'[Sensitive field]':name,sensitive:isSensitive,...(!isSensitive&&['INPUT','TEXTAREA','SELECT'].includes(el.tagName)?{filled:Boolean(el.value),required:Boolean(el.required)}:{}),...(el.tagName==='SELECT'&&!isSensitive?{selectedValue:el.value.slice(0,120),options:Array.from(el.options).slice(0,40).map(o=>({label:o.textContent.trim().slice(0,120),value:o.value.slice(0,120)}))}:{})});
    }
    // Do not serialize input values, scripts, hidden nodes, or contenteditable text.
    const walker=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);
    const parts=[];let length=0,node;
    while((node=walker.nextNode()) && length<18000) {
      const p=node.parentElement;
      if(!p || p.closest('script,style,noscript,input,textarea,select,[contenteditable="true"],[hidden]') || !visible(p)) continue;
      const text=node.textContent.trim().replace(/\s+/g,' '); if(text) {parts.push(text);length+=text.length+1;}
    }
    return {url:location.href,title:document.title,snapshotId,text:parts.join('\n').slice(0,18000),elements};
  }
  chrome.runtime.onMessage.addListener((req,sender,respond)=>{
    if(sender.id!==chrome.runtime.id) return;
    if(req.type==='HC_SNAPSHOT') {settlePage().then(()=>respond(readPage()));return true;}
    if(req.type!=='HC_ACTION') return;
    try {
      const a=req.action;
      if(!snapshotId || req.snapshotId!==snapshotId || location.href!==snapshotURL) throw new Error('Page snapshot is stale. Ask again.');
      if(a.type==='scroll') {window.scrollBy({top:(a.direction==='up'?-1:1)*innerHeight*0.75,behavior:'instant'}); respond({ok:true,message:'Scrolled the page.'});return;}
      if(a.type==='back') {history.back();respond({ok:true,message:'Requested browser back navigation.'});return;}
      const record=nodes.get(a.targetId),el=record?.el;
      if(!el || !el.isConnected || !visible(el) || el.disabled || record.label!==label(el) || record.type!==el.type) throw new Error('The element changed after review. Ask again.');
      if(sensitive(el) || /pay now|confirm booking|place order|purchase|buy now|delete|remove account|send|publish|submit order|complete booking|confirm reservation|log.?in|sign.?in|captcha/i.test(label(el))) throw new Error('Complete sensitive or final actions manually.');
      if(a.type==='click' && (el.type==='submit' || el.getAttribute('role')==='button') && el.form?.querySelector('input[type="password"],input[autocomplete^="cc-"]'))throw new Error('Complete login or payment directly in the website, then resume.');
      if(a.type==='click') {el.scrollIntoView({block:'center'});el.click();}
      else if(a.type==='fill') {
        if(!['INPUT','TEXTAREA','SELECT'].includes(el.tagName) || el.readOnly || ['file','password','hidden','submit','button','checkbox','radio'].includes(el.type)) throw new Error('This field cannot be filled.');
        if(typeof a.value!=='string' || a.value.length>500) throw new Error('Invalid field value.');
        if(el.tagName==='SELECT' && !Array.from(el.options).some(o=>o.value===a.value&&!o.disabled))throw new Error('That dropdown choice is not available.');
        const proto=el.tagName==='TEXTAREA'?HTMLTextAreaElement.prototype:el.tagName==='SELECT'?HTMLSelectElement.prototype:HTMLInputElement.prototype;
        Object.getOwnPropertyDescriptor(proto,'value').set.call(el,a.value);
        el.dispatchEvent(new Event('input',{bubbles:true}));el.dispatchEvent(new Event('change',{bubbles:true}));
        if(el.value!==a.value)throw new Error('The website did not retain the requested field value.');
      } else throw new Error('Unsupported action.');
      snapshotId='';nodes.clear();
      respond({ok:true,message:a.type==='fill'?`Filled ${record.label} with the requested value; the browser retained it. No other field was changed.`:'Clicked the reviewed element. A click does not guarantee the site accepted it.'});
    } catch(e) {respond({ok:false,error:e.message});}
  });
}
