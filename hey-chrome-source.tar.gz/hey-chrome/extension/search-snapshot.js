// Runs in the extension's isolated world. Reads visible DOM only, never a hidden API.
globalThis.__hcSearchSnapshot=(doc,pageURL,isVisible)=>{
  let u;try{u=new URL(pageURL);}catch{return null;}
  if(!/^(www\.)?google\.(com|co\.in)$/.test(u.hostname)||u.pathname!=='/search')return null;
  const results=[];
  for(const heading of doc.querySelectorAll('h3')){
    const anchor=heading.closest('a[href]');
    if(!anchor||!isVisible(heading)||anchor.closest('[data-text-ad],[data-ad],[aria-label="Ads"],[aria-label="Sponsored"]'))continue;
    try{
      let link=new URL(anchor.getAttribute('href'),u);
      if(link.origin===u.origin&&link.pathname==='/url')link=new URL(link.searchParams.get('q')||link.searchParams.get('url'));
      const googleLink=/(^|\.)google\.(com|co\.in)$/.test(link.hostname),redirectLink=googleLink&&link.pathname==='/goto';
      if(link.protocol!=='https:'||link.username||link.password||(googleLink&&!redirectLink)||results.some(r=>r.url===link.href))continue;
      const card=anchor.closest('article,.MjjYud,.g,[data-sokoban-container]')||anchor.parentElement?.parentElement||anchor;
      // innerText includes only rendered text, not scripts or hidden content.
      results.push({title:heading.innerText.trim().slice(0,180),url:link.href,snippet:card.innerText.trim().replace(/\s+/g,' ').slice(0,650),...(redirectLink?{redirectLink:true}:{})});
    }catch{}
    if(results.length===6)break;
  }
  const aiHeading=Array.from(doc.querySelectorAll('h1,h2,[role="heading"]')).find(h=>isVisible(h)&&/^AI Overview$/i.test(h.innerText.trim()));
  let overviewNode=aiHeading?.closest('section,[role="region"]');
  if(aiHeading&&(!overviewNode||overviewNode.innerText.length<70)){
    let parent=aiHeading;
    for(let i=0;i<6;i++){
      parent=parent.parentElement;if(!parent||parent===doc.body||parent.matches('main,#search'))break;
      if(parent.innerText.length>70&&parent.innerText.length<14000){overviewNode=parent;break;}
    }
  }
  const aiOverview=overviewNode?overviewNode.innerText.trim().slice(0,1800):'';
  const main=doc.querySelector('main,[role="main"],#search')||doc.body;
  const blocked=!results.length&&/unusual traffic|not a robot|complete the captcha|verify you are human/i.test(main.innerText)?'captcha':null;
  return{kind:'google-results',query:(u.searchParams.get('q')||'').slice(0,500),results,aiOverview,blocked};
};
