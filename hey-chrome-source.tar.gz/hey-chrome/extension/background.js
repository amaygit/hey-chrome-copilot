const DEFAULTS={ backend:'http://127.0.0.1:8787', token:'', share:false };
const packaged=fetch(chrome.runtime.getURL('connection.local.json')).then(r=>{if(!r.ok)throw new Error('No personal connection');return r.json();}).catch(()=>fetch(chrome.runtime.getURL('connection.json')).then(r=>r.ok?r.json():{}).catch(()=>({})));
function backendURL(value) {
  const u=new URL(value);
  if((u.protocol!=='https:' && !(u.protocol==='http:' && u.hostname==='127.0.0.1')) || u.username || u.password || u.pathname!=='/' || u.search || u.hash)throw new Error('Use an HTTPS server URL, or http://127.0.0.1:PORT for local use.');
  return u;
}
const blank=()=>({ messages:[], flight:{}, pending:null, busy:false, target:null, steps:0, mode:'', sessionId:crypto.randomUUID(), error:'' });
let state=blank(), controller, generation=0;
const ready=(async()=>{
  const saved=await chrome.storage.session.get('state');
  if (saved.state) { state={...blank(),...saved.state,busy:false}; if (saved.state.busy) state.error='The previous request was interrupted. Please retry.'; }
})();
chrome.sidePanel.setPanelBehavior({openPanelOnActionClick:true}).catch(()=>{});
chrome.commands.onCommand.addListener((command,tab)=>{ if (command === 'open-copilot' && tab?.windowId) chrome.sidePanel.open({windowId:tab.windowId}).catch(()=>{}); });
async function publish() {
  await chrome.storage.session.set({state});
  chrome.runtime.sendMessage({type:'STATE',state}).catch(()=>{});
}
function message(role,text) { state.messages.push({id:crypto.randomUUID(),role,text,time:Date.now()}); state.messages=state.messages.slice(-60); }
async function settings() { return {...DEFAULTS,...await packaged,...(await chrome.storage.local.get('settings')).settings}; }
async function api(path,body,signal,method) {
  const s=await settings();
  if (!s.token) throw new Error('Open Settings and enter your local backend token first.');
  const u=backendURL(s.backend);
  if(u.protocol==='https:' && !await chrome.permissions.contains({origins:[u.origin+'/*']}))throw new Error('Open Settings and click Save or Test to allow your shared server.');
  let response;
  try { response=await fetch(`${u.origin}${path}`,{method:method||(body?'POST':'GET'),headers:{'Content-Type':'application/json',Authorization:`Bearer ${s.token}`},...(body?{body:JSON.stringify(body)}:{}),signal:signal || AbortSignal.timeout(15000)}); }
  catch(e) { if (e.name === 'AbortError') throw e; throw new Error(u.hostname==='127.0.0.1'?'Cannot reach the local backend. Run start.cmd and check Settings.':'Cannot reach the shared server. If using Render Free, let it wake up and retry in about a minute.'); }
  if(!response.headers.get('content-type')?.includes('application/json'))throw new Error('The server is waking up or unavailable. Wait about a minute, then retry.');
  const data=await response.json(); if (!response.ok) throw new Error(data.error || `Backend HTTP ${response.status}`); return data;
}
async function planWithPolling(payload,signal){
  const {jobId}=await api('/api/jobs',payload,signal);
  try{
    while(!signal.aborted){
      const job=await api('/api/jobs/'+jobId,null,signal);
      if(job.status==='complete')return job.result;
      if(job.status==='failed')throw new Error(job.error || 'Planning failed.');
      if(job.stage && state.phase!==job.stage){state.phase=job.stage;await publish();}
      await new Promise((resolve,reject)=>{
        const abort=()=>{clearTimeout(timer);const e=new Error('Request stopped.');e.name='AbortError';reject(e);};
        const timer=setTimeout(()=>{signal.removeEventListener('abort',abort);resolve();},800);
        if(signal.aborted)abort();else signal.addEventListener('abort',abort,{once:true});
      });
    }
    const e=new Error('Request stopped.');e.name='AbortError';throw e;
  }finally{await api('/api/jobs/'+jobId,null,AbortSignal.timeout(4000),'DELETE').catch(()=>{});}
}
async function bindTarget() {
  const [tab]=await chrome.tabs.query({active:true,lastFocusedWindow:true});
  if (!tab || !/^https:\/\//.test(tab.url || '')) throw new Error('Select a normal HTTPS webpage, then click “Use current tab”. Chrome settings, new tabs, PDFs, and the Web Store cannot be controlled.');
  state.target={id:tab.id,url:tab.url,title:tab.title}; state.pending=null; await publish(); return state.target;
}
async function targetTab() {
  if (!state.target) return null;
  try { return await chrome.tabs.get(state.target.id); } catch { state.target=null; throw new Error('The selected tab was closed. Choose another tab.'); }
}
async function snapshot() {
  const s=await settings(), tab=await targetTab();
  if (!s.share || !tab || !/^https:\/\//.test(tab.url || '')) return null;
  const allowed=await chrome.permissions.contains({origins:[new URL(tab.url).origin+'/*']});
  if (!allowed) return null;
  await chrome.scripting.executeScript({target:{tabId:tab.id},files:['content.js']});
  return await chrome.tabs.sendMessage(tab.id,{type:'HC_SNAPSHOT'});
}
async function turn(text,observation=null,approvedSearchId=null) {
  if (state.busy) throw new Error('Wait for the current request or press Stop.');
  const turnGeneration=++generation;
  state.busy=true; state.phase='Understanding your request…'; state.error=''; state.pending=null;
  if (!observation) { message('user',text); state.steps=0; }
  await publish();
  controller=new AbortController();
  const turnController=controller;
  const timeout=setTimeout(()=>turnController.abort(),120000);
  try {
    const page=await snapshot();
    const data=await planWithPolling({sessionId:state.sessionId,message:text,observation,approvedSearchId,page,timezone:Intl.DateTimeFormat().resolvedOptions().timeZone},turnController.signal);
    if (turnGeneration !== generation) return;
    state.sessionId=data.sessionId; state.flight=data.flight; state.mode=data.mode;
    message('assistant',data.message);
    if (data.action) {
      if (state.steps>=8) message('assistant','I reached the action limit for this request. Tell me what to do next to continue.');
      else {
        const tab=await targetTab();
        state.pending={id:crypto.randomUUID(),action:data.action,tabId:tab?.id || null,tabURL:tab?.url || null,snapshotId:page?.snapshotId || null,createdAt:Date.now()};
      }
    }
  } catch(e) { if (turnGeneration === generation) { state.error=e.name === 'AbortError' ? 'Request stopped or timed out. You can retry.' : e.message; } }
  finally { clearTimeout(timeout); if (turnGeneration === generation) {state.busy=false; controller=null; await publish();} }
}
async function waitForLoad(id) {
  for(let i=0;i<35;i++) { const t=await chrome.tabs.get(id); if(t.status === 'complete') return; await new Promise(r=>setTimeout(r,250)); }
}
async function approve(id) {
  const p=state.pending;
  if (!p || p.id !== id || state.busy) throw new Error('This action is no longer pending.');
  if (Date.now()-p.createdAt>120000) { state.pending=null; throw new Error('Action expired. Ask again for a fresh page snapshot.'); }
  const a=p.action;
  if (p.tabId) { const tab=await chrome.tabs.get(p.tabId); if (tab.url !== p.tabURL) { state.pending=null; throw new Error('The tab navigated after this proposal. Ask again using the current page.'); } }
  state.pending=null; state.busy=true; state.error=''; state.steps++; await publish();
  const g=generation;
  let result;
  try {
    if(a.type==='web_search'){
      state.busy=false;await publish();await turn('',`Approved public research query: ${a.query}`,a.searchId);return;
    }else if (a.type === 'navigate') {
      const u=new URL(a.url);
      if (u.protocol !== 'https:' || u.username || u.password) throw new Error('Only HTTPS navigation is supported.');
      // Always use a new tab for a navigation proposal; preserve the user's existing page.
      const tab=await chrome.tabs.create({url:a.url,active:true});
      state.target={id:tab.id,url:a.url,title:'Search'}; await waitForLoad(tab.id);
      result='Opened the approved URL in a new tab. Site access must be granted before it can be read.';
    } else {
      if (!p.tabId) throw new Error('Choose a webpage first.');
      if (!(await settings()).share) throw new Error('Page sharing is off. Enable it before browser actions.');
      // The content script rechecks the node identity and label before touching it.
      result=await chrome.tabs.sendMessage(p.tabId,{type:'HC_ACTION',action:a,snapshotId:p.snapshotId});
      if (!result.ok) throw new Error(result.error);
      result=result.message;
      if (['click','back'].includes(a.type)) await waitForLoad(p.tabId);
    }
    if (g !== generation) return;
    message('tool',`${a.type}: ${result}`);
    state.busy=false; await publish();
    await turn('',`Approved action ${a.type}: ${result}`);
  } catch(e) { if(g===generation) {state.error=e.message;state.busy=false; await publish();} }
}
chrome.runtime.onMessage.addListener((req,sender,respond)=>{
  if (sender.id !== chrome.runtime.id || !sender.url?.startsWith(chrome.runtime.getURL('')) || !['GET_STATE','TURN','BIND','APPROVE','CANCEL_ACTION','STOP','RESET','SETTINGS','GET_SETTINGS','HEALTH','VOICE'].includes(req.type)) return;
  (async()=>{
    await ready;
    switch(req.type) {
      case 'GET_STATE': return {state};
      case 'GET_SETTINGS': return {settings:await settings()};
      case 'SETTINGS': {
        const {backend,token,share}=req.settings;
        const u=backendURL(backend);
        await chrome.storage.local.set({settings:{backend:u.origin,token:String(token || '').trim(),share:Boolean(share)}}); return {ok:true};
      }
      case 'HEALTH': return await api('/health');
      case 'BIND': return {target:await bindTarget()};
      case 'TURN': if(typeof req.text !== 'string' || !req.text.trim() || req.text.length>4000) throw new Error('Enter a message up to 4000 characters.'); await turn(req.text.trim()); return {ok:true};
      case 'APPROVE': await approve(req.id); return {ok:true};
      case 'CANCEL_ACTION': state.pending=null; message('tool','Proposed action dismissed.'); await publish(); return {ok:true};
      case 'STOP': generation++; controller?.abort(); controller=null; state.busy=false; state.pending=null; await publish(); return {ok:true};
      case 'RESET': {generation++; controller?.abort(); const oldId=state.sessionId; state=blank(); await publish(); api('/api/reset',{sessionId:oldId}).catch(()=>{}); return {ok:true};}
      case 'VOICE': {
        const url=chrome.runtime.getURL('voice.html'); const tabs=await chrome.tabs.query({}); const existing=tabs.find(t=>t.url===url);
        if(existing) await chrome.tabs.update(existing.id,{active:true}); else await chrome.tabs.create({url}); return {ok:true};
      }
    }
  })().then(respond).catch(async e=>{state.error=e.message; await publish(); respond({error:e.message});});
  return true;
});
