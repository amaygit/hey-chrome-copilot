const DEFAULTS={ backend:'http://127.0.0.1:8787', token:'', share:false, autoRun:true, browserResearch:true };
const packaged=fetch(chrome.runtime.getURL('connection.local.json')).then(r=>{if(!r.ok)throw new Error('No personal connection');return r.json();}).catch(()=>fetch(chrome.runtime.getURL('connection.json')).then(r=>r.ok?r.json():{}).catch(()=>({})));
function backendURL(value) {
  const u=new URL(value);
  if((u.protocol!=='https:' && !(u.protocol==='http:' && u.hostname==='127.0.0.1')) || u.username || u.password || u.pathname!=='/' || u.search || u.hash)throw new Error('Use an HTTPS server URL, or http://127.0.0.1:PORT for local use.');
  return u;
}
const blank=()=>({ messages:[], flight:{}, pending:null, busy:false, target:null, steps:0, mode:'', sessionId:crypto.randomUUID(), error:'',handoff:null });
let state=blank(), controller, generation=0;
const ready=(async()=>{
  const saved=await chrome.storage.session.get('state');
  if (saved.state) { state={...blank(),...saved.state,busy:false}; if (saved.state.busy) state.error='The previous request was interrupted. Please retry.'; }
})();
chrome.sidePanel.setPanelBehavior({openPanelOnActionClick:true}).catch(()=>{});
chrome.commands.onCommand.addListener((command,tab)=>{ if (command === 'open-copilot' && tab?.windowId) chrome.sidePanel.open({windowId:tab.windowId}).catch(()=>{}); });
async function publish() {
  await chrome.storage.session.set({state});
  chrome.runtime.sendMessage({type:'STATE',state}).catch(()=>{});
}
function message(role,text,extra={}) { state.messages.push({id:crypto.randomUUID(),role,text,time:Date.now(),...extra}); state.messages=state.messages.slice(-60); }
async function settings() { return {...DEFAULTS,...await packaged,...(await chrome.storage.local.get('settings')).settings}; }
async function api(path,body,signal,method) {
  const s=await settings();
  if (!s.token) throw new Error('Open Settings and enter your local backend token first.');
  const u=backendURL(s.backend);
  if(u.protocol==='https:' && !await chrome.permissions.contains({origins:[u.origin+'/*']}))throw new Error('Open Settings and click Save or Test to allow your shared server.');
  let response;
  try { response=await fetch(`${u.origin}${path}`,{method:method||(body?'POST':'GET'),headers:{'Content-Type':'application/json',Authorization:`Bearer ${s.token}`},...(body?{body:JSON.stringify(body)}:{}),signal:signal || AbortSignal.timeout(15000)}); }
  catch(e) { if (e.name === 'AbortError') throw e; throw new Error(u.hostname==='127.0.0.1'?'Cannot reach the local backend. Run start.cmd and check Settings.':'Cannot reach the shared server. If using Render Free, let it wake up and retry in about a minute.'); }
  if(!response.headers.get('content-type')?.includes('application/json'))throw new Error('The server is waking up or unavailable. Wait about a minute, then retry.');
  const data=await response.json(); if (!response.ok) throw new Error(data.error || `Backend HTTP ${response.status}`); return data;
}
async function planWithPolling(payload,signal){
  const {jobId}=await api('/api/jobs',payload,signal);
  try{
    while(!signal.aborted){
      const job=await api('/api/jobs/'+jobId,null,signal);
      if(job.status==='complete')return job.result;
      if(job.status==='failed')throw new Error(job.error || 'Planning failed.');
      if(job.stage && state.phase!==job.stage){state.phase=job.stage;await publish();}
      await new Promise((resolve,reject)=>{
        const abort=()=>{clearTimeout(timer);const e=new Error('Request stopped.');e.name='AbortError';reject(e);};
        const timer=setTimeout(()=>{signal.removeEventListener('abort',abort);resolve();},800);
        if(signal.aborted)abort();else signal.addEventListener('abort',abort,{once:true});
      });
    }
    const e=new Error('Request stopped.');e.name='AbortError';throw e;
  }finally{await api('/api/jobs/'+jobId,null,AbortSignal.timeout(4000),'DELETE').catch(()=>{});}
}
async function bindTarget() {
  const [tab]=await chrome.tabs.query({active:true,lastFocusedWindow:true});
  if (!tab || !/^https:\/\//.test(tab.url || '')) throw new Error('Select a normal HTTPS webpage, then click “Use current tab”. Chrome settings, new tabs, PDFs, and the Web Store cannot be controlled.');
  state.target={id:tab.id,url:tab.url,title:tab.title}; state.pending=null; await publish(); return state.target;
}
async function targetTab() {
  if (!state.target) return null;
  try { return await chrome.tabs.get(state.target.id); } catch { state.target=null; throw new Error('The selected tab was closed. Choose another tab.'); }
}
async function snapshot() {
  const s=await settings(), tab=await targetTab();
  if (!s.share || !tab || !/^https:\/\//.test(tab.url || '')) return null;
  const allowed=await chrome.permissions.contains({origins:[new URL(tab.url).origin+'/*']});
  if (!allowed) return null;
  state.target={id:tab.id,url:tab.url,title:tab.title};
  await chrome.scripting.executeScript({target:{tabId:tab.id},files:['search-snapshot.js','content.js']});
  return await chrome.tabs.sendMessage(tab.id,{type:'HC_SNAPSHOT'});
}
function localCommand(text){
  const quick=text.match(/^(?:quick search(?: for)?|google)\s+(.{1,500})$/i);
  if(quick)return{type:'navigate',url:'https://www.google.com/search?q='+encodeURIComponent(quick[1]),quickQuery:quick[1]};
  if(/^scroll (up|down)[.!]?$/i.test(text))return{type:'scroll',direction:/\bup\b/i.test(text)?'up':'down'};
  if(/^go back[.!]?$/i.test(text))return{type:'back'};
  const match=text.match(/^(?:open|visit|go to)\s+(https:\/\/\S+)$/i);if(!match)return null;
  const u=new URL(match[1]);
  if(u.protocol!=='https:'||u.username||u.password||u.port||!u.hostname.includes('.')||/^[\d.]+$/.test(u.hostname)||u.hostname.includes(':')||u.hostname==='localhost'||u.hostname.endsWith('.localhost')||u.hostname.endsWith('.local'))throw new Error('Use a public HTTPS website.');
  return{type:'navigate',url:u.href};
}
async function runLocal(text){
  const action=localCommand(text);if(!action)return false;
  if(state.busy)throw new Error('Wait for the current request or press Stop.');
  generation++;state.error='';state.pending=null;state.handoff=null;state.steps=0;message('user',text);
  let tab=null,page=null;
  if(action.type!=='navigate'){
    tab=await targetTab()||await bindTarget();page=await snapshot();
    if(!page)throw new Error('Enable page sharing and browsing access before controlling this page.');
  }
  state.pending={id:crypto.randomUUID(),action,tabId:tab?.id||null,tabURL:tab?.url||null,snapshotId:page?.snapshotId||null,createdAt:Date.now(),localOnly:true};
  await publish();if((await settings()).autoRun!==false)await approve(state.pending.id);return true;
}
async function turn(text,observation=null,approvedSearchId=null) {
  if (state.busy) throw new Error('Wait for the current request or press Stop.');
  const turnGeneration=++generation;
  state.busy=true; state.phase='Understanding your request…'; state.error=''; state.pending=null; state.handoff=null;
  if (!observation) { message('user',text); state.steps=0; }
  await publish();
  controller=new AbortController();
  const turnController=controller;
  const timeout=setTimeout(()=>turnController.abort(),120000);
  let autoId=null;
  try {
    const page=await snapshot();
    const s=await settings();
    const browserResearch=s.browserResearch!==false&&s.share&&await chrome.permissions.contains({origins:['https://www.google.com/*']});
    const clientContext={requests:state.messages.filter(m=>m.role==='user').slice(-3).map(m=>m.text.slice(0,4000)),flight:state.flight,intent:state.intent,history:state.messages.filter(m=>!m.external&&(m.role==='user'||m.role==='assistant')).slice(-12).map(m=>({role:m.role,text:m.text.slice(0,2000)}))};
    const data=await planWithPolling({sessionId:state.sessionId,message:text,observation,approvedSearchId,page,clientContext,researchMode:browserResearch?'browser':'api',timezone:Intl.DateTimeFormat().resolvedOptions().timeZone},turnController.signal);
    if (turnGeneration !== generation) return;
    state.sessionId=data.sessionId; state.flight=data.flight; state.intent=data.intent; state.mode=data.mode;
    message('assistant',data.message);
    if (data.action) {
      if(data.action.type==='handoff'){state.handoff={reason:data.action.reason};}
      else if (state.steps>=30) message('assistant','I reached the action limit for this request. Tell me what to do next to continue.');
      else {
        const tab=await targetTab();
        state.pending={id:crypto.randomUUID(),action:data.action,tabId:tab?.id || null,tabURL:tab?.url || null,snapshotId:page?.snapshotId || null,createdAt:Date.now()};
        if((await settings()).autoRun!==false && ['web_search','navigate','scroll','back','click','fill'].includes(data.action.type))autoId=state.pending.id;
      }
    }
  } catch(e) { if (turnGeneration === generation) { state.error=e.name === 'AbortError' ? 'Request stopped or timed out. You can retry.' : e.message; } }
  finally { clearTimeout(timeout); if (turnGeneration === generation) {state.busy=false; controller=null; await publish();} }
  if(autoId && turnGeneration===generation && state.pending?.id===autoId)await approve(autoId);
}
async function waitForLoad(id) {
  for(let i=0;i<35;i++) { const t=await chrome.tabs.get(id); if(t.status === 'complete') return; await new Promise(r=>setTimeout(r,250)); }
}
async function approve(id) {
  const p=state.pending;
  if (!p || p.id !== id || state.busy) throw new Error('This action is no longer pending.');
  if (Date.now()-p.createdAt>120000) { state.pending=null; throw new Error('Action expired. Ask again for a fresh page snapshot.'); }
  const a=p.action;
  if (p.tabId) { const tab=await chrome.tabs.get(p.tabId); if (tab.url !== p.tabURL) { state.pending=null; throw new Error('The tab navigated after this proposal. Ask again using the current page.'); } }
  state.pending=null; state.busy=true; state.error=''; state.steps++; await publish();
  const g=generation;
  let result;
  try {
    if(a.type==='web_search'){
      state.busy=false;await publish();await turn('',`Approved public research query: ${a.query}`,a.searchId);return;
    }else if (a.type === 'navigate') {
      const u=new URL(a.url);
      if (u.protocol !== 'https:' || u.username || u.password) throw new Error('Only HTTPS navigation is supported.');
      // Always use a new tab for a navigation proposal; preserve the user's existing page.
      const tab=await chrome.tabs.create({url:a.url,active:true});
      state.target={id:tab.id,url:a.url,title:'Search'}; await waitForLoad(tab.id);
      const access=await chrome.permissions.contains({origins:[u.origin+'/*']});
      result=access&&(await settings()).share?'Opened the approved URL in a new tab. The next step will inspect its current page.':'Opened the approved URL in a new tab. Enable browsing access in Settings to read and continue on this site.';
    } else {
      if (!p.tabId) throw new Error('Choose a webpage first.');
      if (!(await settings()).share) throw new Error('Page sharing is off. Enable it before browser actions.');
      // The content script rechecks the node identity and label before touching it.
      result=await chrome.tabs.sendMessage(p.tabId,{type:'HC_ACTION',action:a,snapshotId:p.snapshotId});
      if (!result.ok) throw new Error(result.error);
      result=result.message;
      if (['click','back'].includes(a.type)) await waitForLoad(p.tabId);
    }
    if (g !== generation) return;
    message('tool',`${a.type}: ${result}`);
    if(p.localOnly){
      let reply=a.type==='navigate'?`Opened a tab for ${a.url}`:result;
      if(a.quickQuery){
        const page=await snapshot();if(g!==generation)return;
        const r=page?.research;
        if(r?.aiOverview)reply=`Google AI Overview — unverified page excerpt:\n${r.aiOverview}\n\nSearch page: ${page.url}\nCheck the original sources before relying on this summary.`;
        else if(r?.results?.length)reply='Visible Google result snippets — original pages not yet read:\n\n'+r.results.slice(0,3).map(x=>`${x.title}\n${x.snippet}\n${x.url}`).join('\n\n');
        else if(r?.blocked)reply='Google is asking for verification. Complete it directly on the page, then retry quick search. No AI API request was sent.';
        else reply='Opened Google search. No readable answer was available; finish any page prompts and enable browsing access to read it.';
      }
      message('assistant',reply,{external:Boolean(a.quickQuery)});state.mode='local';state.busy=false;await publish();return;
    }
    state.busy=false; await publish();
    await turn('',`Approved action ${a.type}: ${result}`);
  } catch(e) { if(g===generation) {state.error=e.message;state.busy=false; await publish();} }
}
chrome.runtime.onMessage.addListener((req,sender,respond)=>{
  if (sender.id !== chrome.runtime.id || !sender.url?.startsWith(chrome.runtime.getURL('')) || !['GET_STATE','TURN','BIND','APPROVE','CANCEL_ACTION','STOP','RESET','SETTINGS','GET_SETTINGS','HEALTH','VOICE','RESUME'].includes(req.type)) return;
  (async()=>{
    await ready;
    switch(req.type) {
      case 'GET_STATE': return {state};
      case 'GET_SETTINGS': return {settings:await settings()};
      case 'SETTINGS': {
        const {backend,token,share,autoRun,browserResearch}=req.settings;
        const u=backendURL(backend);
        await chrome.storage.local.set({settings:{backend:u.origin,token:String(token || '').trim(),share:Boolean(share),autoRun:autoRun!==false,browserResearch:browserResearch!==false}}); return {ok:true};
      }
      case 'HEALTH': return await api('/health');
      case 'BIND': return {target:await bindTarget()};
      case 'TURN': if(typeof req.text !== 'string' || !req.text.trim() || req.text.length>4000) throw new Error('Enter a message up to 4000 characters.'); if(!await runLocal(req.text.trim()))await turn(req.text.trim()); return {ok:true};
      case 'RESUME': if(!state.handoff)throw new Error('No paused task to resume.');state.steps=0;await turn('','The user completed the manual step and requested Resume. Inspect the current site before continuing.');return {ok:true};
      case 'APPROVE': await approve(req.id); return {ok:true};
      case 'CANCEL_ACTION': state.pending=null; message('tool','Proposed action dismissed.'); await publish(); return {ok:true};
      case 'STOP': generation++; controller?.abort(); controller=null; state.busy=false; state.pending=null; await publish(); return {ok:true};
      case 'RESET': {generation++; controller?.abort(); const oldId=state.sessionId; state=blank(); await publish(); api('/api/reset',{sessionId:oldId}).catch(()=>{}); return {ok:true};}
      case 'VOICE': {
        const url=chrome.runtime.getURL('voice.html'); const tabs=await chrome.tabs.query({}); const existing=tabs.find(t=>t.url===url);
        if(existing) await chrome.tabs.update(existing.id,{active:true}); else await chrome.tabs.create({url}); return {ok:true};
      }
    }
  })().then(respond).catch(async e=>{state.error=e.message; await publish(); respond({error:e.message});});
  return true;
});
