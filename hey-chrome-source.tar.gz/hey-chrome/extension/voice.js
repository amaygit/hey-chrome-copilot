const $=id=>document.getElementById(id);
const Recognition=window.SpeechRecognition || window.webkitSpeechRecognition;
const WAKE=/\b(?:hey|hi|okay|ok)[,\s-]*(?:chrome|chrom)\b[,.!\s]*/i;
let recognition,wanted=false,running=false,speaking=false,silenced=false,awaitReplyUntil=0,lastSpoken='',lastUserId='',busy=false,retry,speechSerial=0,recognitionEpoch=0,wakeFloor=-1,echoGuardUntil=0;
let activityStarted=0,activityTicker;const handledFinal=new Set(),interruptedResults=new Set();
const status=text=>$('voiceStatus').textContent=text;
function activity(isBusy,phase){
  busy=isBusy;document.body.classList.toggle('thinking',busy);$('activity').classList.toggle('hidden',!busy);
  if(!busy){clearInterval(activityTicker);activityTicker=null;activityStarted=0;return;}
  $('activityDetail').textContent=phase||'Preparing your reply…';
  if(!activityStarted)activityStarted=Date.now();
  const tick=()=>{$('activityTime').textContent=Math.floor((Date.now()-activityStarted)/1000)+'s';};tick();
  if(!activityTicker)activityTicker=setInterval(tick,1000);
}
function speechUI(){document.body.classList.toggle('speaking',speaking);$('stopReading').classList.toggle('hidden',!speaking);}
function schedule(){clearTimeout(retry);if(wanted&&!running)retry=setTimeout(begin,500);}
function begin(){
  if(!wanted||running)return;
  try{recognition.lang=$('language').value;recognition.start();}catch(e){status(e.message);schedule();}
}
function cancelSpeech(){speechSerial++;speaking=false;speechSynthesis.cancel();speechUI();}
function interruptSpeech(){
  cancelSpeech();silenced=true;echoGuardUntil=0;awaitReplyUntil=Date.now()+45000;
  status(busy?'Reading stopped. The task is still working; say “stop” to cancel it.':'Reading stopped. I’m listening…');
  if(wanted&&!running)begin();
}
function stop(){wanted=false;clearTimeout(retry);recognition?.abort();cancelSpeech();document.body.classList.remove('listening');$('start').disabled=false;$('stopVoice').disabled=true;status('Microphone off');}
function speak(text){
  $('reply').textContent=text;awaitReplyUntil=Date.now()+45000;
  if(!$('speak').checked||!wanted||silenced)return;
  cancelSpeech();speaking=true;const serial=++speechSerial;speechUI();
  // Keep recognition running for interruption. Never speak our own wake phrase
  // into the microphone: ordinary speech echo is ignored while reading.
  const clean=text.replace(/https:\/\/\S+/g,'linked page').replace(/\b(?:hey|hi|okay|ok)[,\s-]*(?:chrome|chrom)\b/gi,'the wake phrase').slice(0,1500);
  const utterance=new SpeechSynthesisUtterance(clean);utterance.lang=$('language').value;
  const done=()=>{if(serial!==speechSerial)return;speaking=false;echoGuardUntil=Date.now()+600;awaitReplyUntil=Date.now()+45000;speechUI();status(busy?'Working on your request…':'Listening · say “Hey Chrome”');schedule();};
  utterance.onend=done;utterance.onerror=done;status('Reading reply · say “Hey Chrome” to interrupt');speechSynthesis.speak(utterance);begin();
}
if(!Recognition){$('start').disabled=true;status('Speech recognition is unavailable here. Use Google Chrome with speech services enabled, or type in the side panel.');}
else{
  recognition=new Recognition();recognition.continuous=true;recognition.interimResults=true;
  recognition.onstart=()=>{running=true;recognitionEpoch++;handledFinal.clear();interruptedResults.clear();wakeFloor=-1;status(speaking?'Reading reply · say “Hey Chrome” to interrupt':'Listening · say “Hey Chrome”');document.body.classList.add('listening');};
  recognition.onend=()=>{running=false;schedule();};
  recognition.onerror=e=>{
    if(['not-allowed','service-not-allowed','audio-capture'].includes(e.error)){stop();status('Microphone error: '+e.error+'. Allow microphone access in Chrome, then try again.');}
    else if(e.error!=='aborted'&&e.error!=='no-speech'){status('Speech service: '+e.error+'. Check your connection.');if(e.error==='network')stop();}
  };
  recognition.onresult=async event=>{
    if(!wanted)return;
    for(let i=event.resultIndex;i<event.results.length;i++){
      const result=event.results[i],raw=result[0].transcript.trim(),key=recognitionEpoch+':'+i,match=WAKE.exec(raw);
      if(speaking){
        if(!match){if(result.isFinal)handledFinal.add(key);continue;}
        interruptSpeech();wakeFloor=i;interruptedResults.add(key);
      }
      $('transcript').textContent=raw;
      if(!result.isFinal||handledFinal.has(key))continue;
      handledFinal.add(key);
      if(i<wakeFloor)continue;
      // A cancelled interim wake result is not a reliable command without a
      // final wake phrase. Wait for the next utterance rather than send echo.
      if(!match&&interruptedResults.has(key))continue;
      if(!match&&(Date.now()>awaitReplyUntil||Date.now()<echoGuardUntil))continue;
      const command=(match?raw.slice(match.index+match[0].length):raw).trim();awaitReplyUntil=Date.now()+45000;
      if(!command){status(busy?'The task is still working. Say “stop” to cancel.':'I’m listening. What would you like to do?');continue;}
      if(/^(stop listening|microphone off|go to sleep)[.!]?$/i.test(command)){stop();continue;}
      if(/^(stop|cancel)[.!]?$/i.test(command)){interruptSpeech();await chrome.runtime.sendMessage({type:'STOP'});status('Stopped the pending request.');continue;}
      if(busy){status('Working on your previous request. Say “stop” to cancel.');continue;}
      silenced=false;busy=true;activity(true,'Understanding your request…');status('Understanding your request…');
      try{const response=await chrome.runtime.sendMessage({type:'TURN',text:command});if(response?.error)status(response.error);}catch(e){status(e.message);}finally{activity(false);}
    }
  };
}
$('start').onclick=async()=>{
  try{
    const stream=await navigator.mediaDevices.getUserMedia({audio:true});stream.getTracks().forEach(t=>t.stop());
    wanted=true;silenced=false;$('start').disabled=true;$('stopVoice').disabled=false;begin();
  }catch(e){status('Could not open microphone: '+e.message);}
};
$('stopVoice').onclick=stop;
$('stopReading').onclick=interruptSpeech;
$('speak').onchange=()=>{if(!$('speak').checked)interruptSpeech();};
chrome.runtime.onMessage.addListener(req=>{
  if(req.type!=='STATE')return;
  const user=req.state.messages.filter(m=>m.role==='user').at(-1);
  if(user&&user.id!==lastUserId){lastUserId=user.id;silenced=false;}
  activity(req.state.busy,req.state.phase);
  if(busy&&!speaking&&wanted)status(req.state.phase||'Working on your request…');
  const last=req.state.messages.filter(m=>m.role==='assistant').at(-1);
  if(last&&last.id!==lastSpoken){lastSpoken=last.id;speak(last.text);}
  if(req.state.error)status(req.state.error);
});
const initial=await chrome.runtime.sendMessage({type:'GET_STATE'});lastSpoken=initial?.state?.messages.filter(m=>m.role==='assistant').at(-1)?.id || '';
if(initial?.state){lastUserId=initial.state.messages.filter(m=>m.role==='user').at(-1)?.id||'';activity(initial.state.busy,initial.state.phase);}
addEventListener('pagehide',()=>{stop();clearInterval(activityTicker);});
