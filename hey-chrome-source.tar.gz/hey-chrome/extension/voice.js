const $=id=>document.getElementById(id);
const Recognition=window.SpeechRecognition||window.webkitSpeechRecognition;
const WAKE=/\b(?:hey|hi|okay|ok)[,\s-]*(?:chrome|chrom)\b[,.!\s]*|हे\s*क्रोम[,.!\s]*/i;
let recognition,wanted=false,running=false,speaking=false,silenced=false,busy=false,retry,speechSerial=0,epoch=0,lastSpoken='',lastUserId='',followUntil=0;
let parts=new Map(),seen=new Set(),draftOverride=null,lastHeard=0,sendTimer,countdownTimer,editing=false,reviewNeeded=false,localSending=false;
let activityStarted=0,activityTicker,micStream,audioContext,audioTimer,lastRead='',lastReadEnded=0;
const status=text=>$('voiceStatus').textContent=text;
const normalize=text=>text.toLowerCase().replace(/[^\p{L}\p{N}]+/gu,' ').trim();
function draft(){return draftOverride!==null?draftOverride:Array.from(parts.values()).map(p=>p.text).filter(Boolean).join(' ').trim();}
function hasInterim(){return draftOverride===null&&Array.from(parts.values()).some(p=>!p.final);}
function clearSendTimer(){clearTimeout(sendTimer);clearInterval(countdownTimer);sendTimer=null;countdownTimer=null;}
function showDraft(){ $('transcript').value=draft();$('sendVoice').disabled=!draft();$('clearVoice').disabled=!draft(); }
function clearDraft(){clearSendTimer();parts.clear();draftOverride=null;reviewNeeded=false;showDraft();$('draftStatus').textContent='Your words stay here until you finish speaking.';}
function activity(value,phase){
  busy=value;document.body.classList.toggle('thinking',busy);$('activity').classList.toggle('hidden',!busy);
  if(!busy){clearInterval(activityTicker);activityTicker=null;activityStarted=0;return;}
  $('activityDetail').textContent=phase||'Preparing your reply…';if(!activityStarted)activityStarted=Date.now();
  const tick=()=>{$('activityTime').textContent=Math.floor((Date.now()-activityStarted)/1000)+'s';};tick();if(!activityTicker)activityTicker=setInterval(tick,1000);
}
function speechUI(){document.body.classList.toggle('speaking',speaking);$('stopReading').classList.toggle('hidden',!speaking);}
function cancelSpeech(){speechSerial++;speaking=false;speechSynthesis.pause?.();speechSynthesis.cancel();speechUI();lastReadEnded=Date.now();}
function begin(){if(!wanted||running)return;try{recognition.lang=$('language').value;recognition.start();}catch{schedule();}}
function schedule(){clearTimeout(retry);if(wanted&&!running)retry=setTimeout(begin,250);}
function interruptSpeech(){cancelSpeech();silenced=true;followUntil=Date.now()+45000;status('Reading stopped. I’m listening—finish your sentence before sending.');if(wanted&&!running)begin();}
function echo(raw){const text=normalize(raw);return text.split(' ').length>=4&&lastRead.includes(text);}
function armSend(){
  clearSendTimer();showDraft();if(!draft())return;
  if(editing){$('draftStatus').textContent='Editing paused automatic sending. Click Send now when ready.';return;}
  if(reviewNeeded){$('draftStatus').textContent='Some words were unclear. Review the transcript, then click Send now.';return;}
  const pause=Number($('pause').value)||0;
  if(!pause){$('draftStatus').textContent='Manual mode: finish speaking, then click Send now.';return;}
  if(hasInterim()){$('draftStatus').textContent='Listening… keep speaking.';return;}
  const remaining=Math.max(0,pause-(Date.now()-lastHeard));
  const tick=()=>{$('draftStatus').textContent=busy?'Your words are saved. Waiting for the current request…':'Listening… sends after '+Math.max(1,Math.ceil((pause-(Date.now()-lastHeard))/1000))+'s of silence.';};tick();
  if(busy)return;
  countdownTimer=setInterval(tick,250);sendTimer=setTimeout(()=>sendDraft(false),remaining);
}
async function sendDraft(manual){
  clearSendTimer();const text=draft().trim();if(!text)return;
  if(!manual&&(hasInterim()||reviewNeeded||editing)){armSend();return;}
  if(busy||localSending){$('draftStatus').textContent='Your words are saved. Waiting for the current request…';return;}
  clearDraft();silenced=false;localSending=true;activity(true,'Understanding your full request…');status('Sending your complete message…');
  try{const r=await chrome.runtime.sendMessage({type:'TURN',text});if(r?.error){draftOverride=text;showDraft();status(r.error);}}
  catch(e){draftOverride=text;showDraft();status(e.message);}
  finally{localSending=false;activity(false);if(draft())armSend();}
}
function speak(text){
  $('reply').textContent=text;followUntil=Date.now()+45000;
  // Never speak over an unfinished reply, an editable draft, or a running step.
  if(!$('speak').checked||!wanted||silenced||draft()||editing||busy)return;
  cancelSpeech();speaking=true;const serial=++speechSerial;speechUI();
  const clean=text.replace(/https:\/\/\S+/g,'linked page').replace(/\b(?:hey|hi|okay|ok)[,\s-]*(?:chrome|chrom)\b|हे\s*क्रोम/gi,'the wake phrase').slice(0,1500);lastRead=normalize(clean);
  const u=new SpeechSynthesisUtterance(clean);u.lang=$('language').value;
  const done=()=>{if(serial!==speechSerial)return;speaking=false;lastReadEnded=Date.now();followUntil=Date.now()+45000;speechUI();status(draft()?'Listening… keep speaking.':'Listening · say “Hey Chrome”');schedule();};
  u.onend=done;u.onerror=done;speechSynthesis.resume?.();status('Reading reply · say “Hey Chrome” or start speaking to interrupt');speechSynthesis.speak(u);begin();
}
async function monitor(stream){
  const Audio=window.AudioContext||window.webkitAudioContext;
  if(!Audio||!globalThis.HCVoiceGate)return;
  try{
    audioContext=new Audio();await audioContext.resume();const analyser=audioContext.createAnalyser();analyser.fftSize=1024;audioContext.createMediaStreamSource(stream).connect(analyser);
    const samples=new Float32Array(analyser.fftSize),gate=new HCVoiceGate();
    audioTimer=setInterval(()=>{
      if(!wanted)return;analyser.getFloatTimeDomainData(samples);let energy=0;for(const x of samples)energy+=x*x;
      const sample=gate.sample(Math.sqrt(energy/samples.length),Date.now(),speaking);
      $('micLevel').style.width=Math.round(sample.level*100)+'%';
      if(sample.started){
        if(speaking&&$('interruptSpeech').checked)interruptSpeech();
        if(!speaking&&(draft()||Date.now()<followUntil)){
          clearSendTimer();lastHeard=Date.now();$('draftStatus').textContent='Hearing you… keep speaking.';
        }
      }
      if(sample.active&&!speaking){lastHeard=Date.now();clearSendTimer();}
      if(sample.ended&&!speaking)armSend();
    },40);
  }catch{$('micNote').textContent='Microphone monitor unavailable; wake recognition and Stop reading are still available.';}
}
function stop(){
  wanted=false;clearTimeout(retry);clearSendTimer();recognition?.abort();cancelSpeech();clearInterval(audioTimer);audioTimer=null;micStream?.getTracks().forEach(t=>t.stop());micStream=null;audioContext?.close?.()?.catch?.(()=>{});audioContext=null;
  document.body.classList.remove('listening');$('start').disabled=false;$('stopVoice').disabled=true;$('micLevel').style.width='0%';status('Microphone off');
}
if(!Recognition){$('start').disabled=true;status('Speech recognition is unavailable. Use Chrome or type in the side panel.');}
else{
  recognition=new Recognition();recognition.continuous=true;recognition.interimResults=true;recognition.maxAlternatives=3;
  recognition.onstart=()=>{running=true;epoch++;seen.clear();status(speaking?'Reading reply · say “Hey Chrome” to interrupt':'Listening · say “Hey Chrome”');document.body.classList.add('listening');};
  recognition.onend=()=>{running=false;if(hasInterim()){reviewNeeded=true;armSend();}schedule();};
  recognition.onerror=e=>{
    if(['not-allowed','service-not-allowed','audio-capture'].includes(e.error)){stop();status('Microphone error: '+e.error+'. Check Chrome microphone access.');}
    else if(e.error==='network'){stop();status('Speech service network error. Your draft is kept; retry or type it.');}
  };
  recognition.onresult=async event=>{
    if(!wanted)return;
    for(let i=event.resultIndex;i<event.results.length;i++){
      const r=event.results[i],raw=r[0].transcript.trim(),key=epoch+':'+i,match=WAKE.exec(raw);if(seen.has(key))continue;
      if(speaking){if(!match){if(r.isFinal)seen.add(key);continue;}interruptSpeech();}
      if(!match&&(Date.now()>followUntil||(Date.now()-lastReadEnded<900&&echo(raw)))){if(r.isFinal)seen.add(key);continue;}
      const text=(match?raw.slice(match.index+match[0].length):raw).trim();followUntil=Date.now()+45000;
      if(!text){if(r.isFinal)seen.add(key);status('I’m listening. Finish your sentence; I’ll wait for a pause.');continue;}
      if(r.isFinal&&/^(stop listening|microphone off|go to sleep)[.!]?$/i.test(text)){seen.add(key);stop();continue;}
      if(r.isFinal&&/^(stop|cancel)[.!]?$/i.test(text)){seen.add(key);interruptSpeech();clearDraft();await chrome.runtime.sendMessage({type:'STOP'});status('Stopped the current request.');continue;}
      if(draftOverride!==null){parts.clear();parts.set('edited',{text:draftOverride,final:true});draftOverride=null;}
      parts.set(key,{text,final:r.isFinal});if(r.isFinal){seen.add(key);const confidence=r[0].confidence;if(confidence>0&&confidence<.6)reviewNeeded=true;}
      lastHeard=Date.now();showDraft();armSend();
    }
  };
}
$('start').onclick=async()=>{
  try{micStream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true}});wanted=true;silenced=false;$('start').disabled=true;$('stopVoice').disabled=false;await monitor(micStream);begin();}
  catch(e){stop();status('Could not open microphone: '+e.message);}
};
$('stopVoice').onclick=stop;$('stopReading').onclick=interruptSpeech;$('speak').onchange=()=>{if(!$('speak').checked)interruptSpeech();};
$('sendVoice').onclick=()=>sendDraft(true);$('clearVoice').onclick=()=>{clearDraft();status('Draft cleared. I’m listening.');};
$('transcript').onfocus=()=>{editing=true;if(speaking)interruptSpeech();clearSendTimer();armSend();};
$('transcript').oninput=()=>{draftOverride=$('transcript').value;reviewNeeded=false;lastHeard=Date.now();armSend();};
$('transcript').onblur=()=>{editing=false;lastHeard=Date.now();armSend();};
$('pause').onchange=()=>{lastHeard=Date.now();armSend();savePrefs();};$('interruptSpeech').onchange=savePrefs;
function savePrefs(){try{chrome.storage.local.set({voicePrefs:{pauseMs:Number($('pause').value),interruptOnSpeech:$('interruptSpeech').checked}}).catch(()=>{});}catch{}}
chrome.runtime.onMessage.addListener(req=>{
  if(req.type!=='STATE')return;const state=req.state,user=state.messages.filter(m=>m.role==='user').at(-1);
  if(user&&user.id!==lastUserId){lastUserId=user.id;if(!draft())silenced=false;}
  activity(state.busy,state.phase);const last=state.messages.filter(m=>m.role==='assistant').at(-1);
  if(last&&last.id!==lastSpoken){lastSpoken=last.id;$('reply').textContent=last.text;}
  // Read only the final answer, never intermediate action messages. Keep quiet
  // if the user is still building a reply or has interrupted this task.
  if(!busy&&!state.pending&&last&&last.id!==lastReadId&&!draft()){lastReadId=last.id;speak(last.text);}
  if(draft())armSend();else if(busy&&!speaking&&wanted)status(state.phase||'Working on your request…');
  if(state.error)status(state.error);
});
let lastReadId='';
const initial=await chrome.runtime.sendMessage({type:'GET_STATE'});
if(initial?.state){const s=initial.state;lastSpoken=s.messages.filter(m=>m.role==='assistant').at(-1)?.id||'';lastReadId=lastSpoken;lastUserId=s.messages.filter(m=>m.role==='user').at(-1)?.id||'';activity(s.busy,s.phase);}
$('pause').value='3000';$('interruptSpeech').checked=true;
try{const p=(await chrome.storage.local.get('voicePrefs')).voicePrefs;if(p){$('pause').value=String([0,2000,3000,5000].includes(p.pauseMs)?p.pauseMs:3000);$('interruptSpeech').checked=p.interruptOnSpeech!==false;}}catch{}
showDraft();addEventListener('pagehide',()=>{stop();clearInterval(activityTicker);});
