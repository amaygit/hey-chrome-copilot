const $=id=>document.getElementById(id);
const Recognition=window.SpeechRecognition||window.webkitSpeechRecognition;
const WAKE=/\b(?:hey|hi|okay|ok)[,\s-]*(?:chrome|chrom)\b[,.!\s]*|(?:हे|है|हेय|हाय|हेलो)\s*क्रोम[,.!।\s]*/i;
let recognition,wanted=false,running=false,speaking=false,silenced=false,busy=false,retry,speechSerial=0,epoch=0,lastSpoken='',lastUserId='',followUntil=0;
let parts=new Map(),seen=new Set(),draftOverride=null,lastHeard=0,sendTimer,countdownTimer,editing=false,reviewNeeded=false,localSending=false,sendFailed=false;
let activityStarted=0,activityTicker,micStream,audioContext,audioTimer,lastRead='',lastReadEnded=0,lastCancelAt=0,speechTimer,speechWatchdog,latestAnswer=null;
let wakeLead='',wakeLeadAt=0,lastBareWakeAt=0,trackInputSupported=true;
let networkFailures=0,retryDelay=250;
const status=text=>$('voiceStatus').textContent=text;
const report=kind=>chrome.runtime.sendMessage({type:'CLIENT_ERROR',kind}).catch(()=>{});
addEventListener('error',()=>report('voice_runtime'));
addEventListener('unhandledrejection',()=>report('voice_runtime'));
const normalize=text=>text.toLowerCase().replace(/[^\p{L}\p{N}]+/gu,' ').trim();
function draft(){return draftOverride!==null?draftOverride:Array.from(parts.values()).map(p=>p.text).filter(Boolean).join(' ').trim();}
function clearSendTimer(){clearTimeout(sendTimer);clearInterval(countdownTimer);sendTimer=null;countdownTimer=null;}
function showDraft(){ $('transcript').value=draft();$('sendVoice').disabled=!draft();$('clearVoice').disabled=!draft(); }
function clearDraft(){clearSendTimer();parts.clear();draftOverride=null;reviewNeeded=false;sendFailed=false;showDraft();$('draftStatus').textContent='Your words stay here until you finish speaking.';}
function activity(value,phase){
  busy=value;document.body.classList.toggle('thinking',busy);$('activity').classList.toggle('hidden',!busy);
  if(!busy){clearInterval(activityTicker);activityTicker=null;activityStarted=0;return;}
  $('activityDetail').textContent=phase||'Preparing your reply…';if(!activityStarted)activityStarted=Date.now();
  const tick=()=>{$('activityTime').textContent=Math.floor((Date.now()-activityStarted)/1000)+'s';};tick();if(!activityTicker)activityTicker=setInterval(tick,1000);
}
function speechUI(){document.body.classList.toggle('speaking',speaking);$('stopReading').classList.toggle('hidden',!speaking);}
function cancelSpeech(){speechSerial++;clearTimeout(speechTimer);clearTimeout(speechWatchdog);speaking=false;speechSynthesis.cancel();speechUI();lastReadEnded=Date.now();lastCancelAt=Date.now();}
function begin(){if(!wanted||running)return;try{recognition.lang=$('language').value;const track=micStream?.getAudioTracks?.().find(t=>t.kind==='audio'&&t.readyState==='live');if(track&&trackInputSupported){try{recognition.start(track);}catch(e){if(e.name!=='TypeError'&&e.name!=='NotSupportedError')throw e;trackInputSupported=false;recognition.start();}}else recognition.start();}catch{schedule();}}
function schedule(){clearTimeout(retry);if(wanted&&!running)retry=setTimeout(begin,retryDelay);}
function interruptSpeech(){cancelSpeech();silenced=true;followUntil=Date.now()+45000;status('Reading stopped. I’m listening—finish your sentence before sending.');if(wanted&&!running)begin();}
function echo(raw){const text=normalize(raw);return text.split(' ').length>=4&&lastRead.includes(text);}
function armSend(){
  clearSendTimer();showDraft();if(!draft())return;
  if(editing){$('draftStatus').textContent='Editing paused automatic sending. Click Send now when ready.';return;}
  if(sendFailed){$('draftStatus').textContent='Message was not sent. Click Send now to retry.';return;}
  const pause=Number($('pause').value)||0;
  if(!pause){$('draftStatus').textContent='Manual mode: finish speaking, then click Send now.';return;}
  const remaining=Math.max(0,pause-(Date.now()-lastHeard));
  const tick=()=>{$('draftStatus').textContent=busy?'Your words are saved. Waiting for the current request…':(reviewNeeded?'Check any unclear words. ':'')+'Sending in '+Math.max(1,Math.ceil((pause-(Date.now()-lastHeard))/1000))+'s unless you keep speaking.';};tick();
  if(busy)return;
  countdownTimer=setInterval(tick,250);sendTimer=setTimeout(()=>sendDraft(false),remaining);
}
async function sendDraft(manual){
  clearSendTimer();const text=draft().trim();if(!text)return;
  if(!manual&&editing){armSend();return;}
  if(busy||localSending){$('draftStatus').textContent='Your words are saved. Waiting for the current request…';return;}
  // Chrome may deliver a late final result for an interim transcript already sent.
  for(const key of parts.keys())seen.add(key);
  latestAnswer=null;clearDraft();silenced=false;localSending=true;activity(true,'Understanding your full request…');status('Sending your complete message…');
  try{const r=await chrome.runtime.sendMessage({type:'TURN',text});if(r?.error){draftOverride=text;sendFailed=true;showDraft();status(r.error);}}
  catch(e){draftOverride=text;sendFailed=true;showDraft();status(e.message);}
  finally{localSending=false;activity(false);if(draft())armSend();else readAnswer();}
}
function readAnswer(){if(latestAnswer&&latestAnswer.id!==lastReadId&&speak(latestAnswer.text))lastReadId=latestAnswer.id;}
function speak(text,force=false){
  $('reply').textContent=text;followUntil=Date.now()+45000;
  // Never speak over an unfinished reply, an editable draft, or a running step.
  if((!force&&(!$('speak').checked||!wanted||silenced))||draft()||busy||localSending)return false;
  if(speaking||speechSynthesis.speaking||speechSynthesis.pending)cancelSpeech();
  speaking=true;const serial=++speechSerial;speechUI();
  const clean=text.replace(/https:\/\/\S+/g,'linked page').replace(/\b(?:hey|hi|okay|ok)[,\s-]*(?:chrome|chrom)\b|(?:हे|है|हेय|हाय|हेलो)\s*क्रोम/gi,'the wake phrase').slice(0,1500);lastRead=normalize(clean);
  const u=new SpeechSynthesisUtterance(clean),language=/[\u0900-\u097f]/.test(clean)?'hi-IN':$('language').value==='hi-IN'?'en-IN':$('language').value;
  const voices=speechSynthesis.getVoices?.()||[],voice=voices.find(v=>v.lang?.toLowerCase()===language.toLowerCase())||voices.find(v=>v.lang?.split('-')[0]===language.split('-')[0])||voices.find(v=>v.default)||voices[0];
  if(voice){u.voice=voice;u.lang=voice.lang;}else u.lang=language;
  let started=false;u.onstart=()=>{if(serial!==speechSerial)return;started=true;clearTimeout(speechWatchdog);status('Speaking reply · say “Hey Chrome” to interrupt');};
  const done=()=>{if(serial!==speechSerial)return;clearTimeout(speechWatchdog);speaking=false;lastReadEnded=Date.now();followUntil=Date.now()+45000;speechUI();status(draft()?'Listening… keep speaking.':'Listening · say “Hey Chrome”');schedule();};
  u.onend=done;u.onerror=e=>{if(serial!==speechSerial)return;done();status('Chrome could not play this reply ('+(e.error||'speech unavailable')+'). Use Read last reply to retry; check the selected language and Chrome audio.');report('voice_runtime');};
  const play=()=>{if(serial!==speechSerial)return;try{speechSynthesis.resume?.();speechSynthesis.speak(u);speechWatchdog=setTimeout(()=>{if(serial===speechSerial&&!started&&!speechSynthesis.speaking){cancelSpeech();status('Chrome did not start audio. Click Read last reply to retry and check Chrome audio or the selected language.');report('voice_runtime');}},5000);}catch{u.onerror({error:'speech unavailable'});}};
  status('Starting spoken reply…');if(Date.now()-lastCancelAt<80)speechTimer=setTimeout(play,80);else play();begin();return true;
}
async function monitor(stream){
  const Audio=window.AudioContext||window.webkitAudioContext;
  if(!Audio||!globalThis.HCVoiceGate)return;
  try{
    audioContext=new Audio();await audioContext.resume();const analyser=audioContext.createAnalyser();analyser.fftSize=1024;audioContext.createMediaStreamSource(stream).connect(analyser);
    const samples=new Float32Array(analyser.fftSize),gate=new HCVoiceGate();
    audioTimer=setInterval(()=>{
      if(!wanted)return;analyser.getFloatTimeDomainData(samples);let energy=0;for(const x of samples)energy+=x*x;
      const sample=gate.sample(Math.sqrt(energy/samples.length),Date.now(),speaking);
      $('micLevel').style.width=Math.round(sample.level*100)+'%';
      // Ambient noise must never hold the send timer open. Recognition text,
      // not a raw loudness threshold, determines when the user finishes.
      if(sample.started&&speaking&&$('interruptSpeech').checked)interruptSpeech();
    },40);
  }catch{$('micNote').textContent='Microphone monitor unavailable; wake recognition and Stop reading are still available.';report('voice_monitor');}
}
function stop(){
  wanted=false;clearTimeout(retry);clearSendTimer();recognition?.abort();cancelSpeech();clearInterval(audioTimer);audioTimer=null;micStream?.getTracks().forEach(t=>t.stop());micStream=null;audioContext?.close?.()?.catch?.(()=>{});audioContext=null;
  document.body.classList.remove('listening');$('start').disabled=false;$('stopVoice').disabled=true;$('micLevel').style.width='0%';status('Microphone off');
}
if(!Recognition){$('start').disabled=true;status('Speech recognition is unavailable. Use Chrome or type in the side panel.');}
else{
  recognition=new Recognition();recognition.continuous=true;recognition.interimResults=true;recognition.maxAlternatives=3;
  recognition.onstart=()=>{running=true;epoch++;seen.clear();status(speaking?'Reading reply · say “Hey Chrome” to interrupt':'Listening · say “Hey Chrome”');document.body.classList.add('listening');};
  recognition.onend=()=>{running=false;if(draft())armSend();schedule();};
  recognition.onerror=e=>{
    if(e.error==='network')report('speech_network');if(e.error==='not-allowed'||e.error==='service-not-allowed')report('speech_not_allowed');if(e.error==='audio-capture')report('speech_audio_capture');
    if(['not-allowed','service-not-allowed','audio-capture'].includes(e.error)){stop();status('Microphone error: '+e.error+'. Check Chrome microphone access.');}
    else if(e.error==='network'){
      if(++networkFailures<=2){retryDelay=1000*networkFailures;running=false;if(draft()){sendFailed=true;armSend();}status('Speech service interrupted. Reconnecting… Your draft is kept.');recognition.abort();schedule();}
      else{stop();status('Chrome speech service is unavailable after two reconnect attempts. Click Start listening to retry, or type your request.');}
    }
  };
  recognition.onresult=async event=>{
    if(!wanted)return;
    networkFailures=0;retryDelay=250;
    for(let i=event.resultIndex;i<event.results.length;i++){
      const r=event.results[i],key=epoch+':'+i;if(seen.has(key))continue;let raw=r[0].transcript.trim(),match=WAKE.exec(raw);
      if(/^(?:hey|hi|okay|ok|हे|है|हेय|हाय)[,.!।\s]*$/i.test(raw)){wakeLead=raw;wakeLeadAt=Date.now();parts.delete(key);if(r.isFinal)seen.add(key);armSend();continue;}
      if(!match&&wakeLead&&Date.now()-wakeLeadAt<2500&&/^(?:chrome|chrom|क्रोम)\b/i.test(raw)){raw=wakeLead+' '+raw;match=WAKE.exec(raw);wakeLead='';}
      if(!match&&Date.now()-lastBareWakeAt<2000&&/^(?:chrome|chrom|क्रोम)[,.!।\s]*$/i.test(raw)){parts.delete(key);if(r.isFinal)seen.add(key);armSend();continue;}
      if(speaking){if(!match){if(r.isFinal)seen.add(key);continue;}interruptSpeech();}
      if(!match&&(Date.now()>followUntil||(Date.now()-lastReadEnded<900&&echo(raw)))){if(r.isFinal)seen.add(key);continue;}
      const text=(match?raw.slice(match.index+match[0].length):raw).trim();followUntil=Date.now()+45000;
      if(!text){lastBareWakeAt=Date.now();parts.delete(key);if(r.isFinal)seen.add(key);armSend();status('I’m listening. Finish your sentence; I’ll wait for a pause.');continue;}
      if(r.isFinal&&/^(stop listening|microphone off|go to sleep)[.!]?$/i.test(text)){seen.add(key);stop();continue;}
      if(r.isFinal&&/^(stop|cancel)[.!]?$/i.test(text)){seen.add(key);interruptSpeech();clearDraft();await chrome.runtime.sendMessage({type:'STOP'});status('Stopped the current request.');continue;}
      if(draftOverride!==null){parts.clear();parts.set('edited',{text:draftOverride,final:true});draftOverride=null;}
      const changed=parts.get(key)?.text!==text;
      parts.set(key,{text,final:r.isFinal});if(r.isFinal){seen.add(key);const confidence=r[0].confidence;if(confidence>0&&confidence<.6)reviewNeeded=true;}
      if(changed){lastHeard=Date.now();sendFailed=false;}showDraft();armSend();
    }
  };
}
$('start').onclick=async()=>{
  try{speechSynthesis.resume?.();speechSynthesis.getVoices?.();micStream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true}});wanted=true;silenced=false;networkFailures=0;retryDelay=250;$('start').disabled=true;$('stopVoice').disabled=false;await monitor(micStream);begin();readAnswer();}
  catch(e){stop();status('Could not open microphone: '+e.message);}
};
$('stopVoice').onclick=stop;$('stopReading').onclick=interruptSpeech;$('speak').onchange=()=>{if(!$('speak').checked)interruptSpeech();else{silenced=false;readAnswer();}};
$('readReply').onclick=()=>{if(latestAnswer){silenced=false;if(speak(latestAnswer.text,true))lastReadId=latestAnswer.id;}};
$('sendVoice').onclick=()=>sendDraft(true);$('clearVoice').onclick=()=>{clearDraft();editing=false;status('Draft cleared. I’m listening.');readAnswer();};
$('transcript').onfocus=()=>{if(speaking)interruptSpeech();};
$('transcript').oninput=()=>{editing=true;draftOverride=$('transcript').value;reviewNeeded=false;lastHeard=Date.now();armSend();};
$('transcript').onblur=()=>{editing=false;lastHeard=Date.now();armSend();if(!draft())readAnswer();};
$('pause').onchange=()=>{lastHeard=Date.now();armSend();savePrefs();};$('interruptSpeech').onchange=savePrefs;
$('language').onchange=()=>{savePrefs();if(wanted){recognition?.abort();}};
function savePrefs(){try{chrome.storage.local.set({voicePrefs:{version:2,pauseMs:Number($('pause').value),language:$('language').value,interruptOnSpeech:$('interruptSpeech').checked}}).catch(()=>{});}catch{}}
chrome.runtime.onMessage.addListener(req=>{
  if(req.type!=='STATE')return;const state=req.state,user=state.messages.filter(m=>m.role==='user').at(-1);
  if(user&&user.id!==lastUserId){lastUserId=user.id;if(!draft())silenced=false;}
  activity(state.busy,state.phase);const last=state.messages.filter(m=>m.role==='assistant').at(-1);
  if(last&&last.id!==lastSpoken){lastSpoken=last.id;$('reply').textContent=last.text;}
  // Read only the final answer, never intermediate action messages. Keep quiet
  // if the user is still building a reply or has interrupted this task.
  const userIndex=state.messages.findLastIndex(m=>m.role==='user'),answerIndex=state.messages.findLastIndex(m=>m.role==='assistant');
  latestAnswer=!busy&&!state.pending&&last&&answerIndex>userIndex?last:null;$('readReply').disabled=!latestAnswer;
  if(!busy&&!state.pending)readAnswer();
  if(draft())armSend();else if(busy&&!speaking&&wanted)status(state.phase||'Working on your request…');
  if(state.error)status(state.error);
});
let lastReadId='';
const initial=await chrome.runtime.sendMessage({type:'GET_STATE'});
if(initial?.state){const s=initial.state;latestAnswer=s.messages.filter(m=>m.role==='assistant').at(-1)||null;lastSpoken=latestAnswer?.id||'';lastReadId=lastSpoken;lastUserId=s.messages.filter(m=>m.role==='user').at(-1)?.id||'';activity(s.busy,s.phase);$('readReply').disabled=!latestAnswer;if(latestAnswer)$('reply').textContent=latestAnswer.text;}
$('pause').value='3000';$('interruptSpeech').checked=false;
try{const p=(await chrome.storage.local.get('voicePrefs')).voicePrefs;if(p){$('pause').value=String(([2000,3000,5000].includes(p.pauseMs)||p.version===2&&p.pauseMs===0)?p.pauseMs:3000);$('interruptSpeech').checked=p.version===2&&p.interruptOnSpeech===true;if(['en-IN','en-US','hi-IN'].includes(p.language))$('language').value=p.language;}savePrefs();}catch{}
showDraft();addEventListener('pagehide',()=>{stop();clearInterval(activityTicker);});
