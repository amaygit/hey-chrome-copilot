const $=id=>document.getElementById(id);
const Recognition=window.SpeechRecognition || window.webkitSpeechRecognition;
let recognition,wanted=false,running=false,speaking=false,awaitReplyUntil=0,lastSpoken='',busy=false,retry;
const status=text=>$('voiceStatus').textContent=text;
function schedule(){clearTimeout(retry);if(wanted&&!running&&!speaking)retry=setTimeout(begin,500);}
function begin(){
  if(!wanted||running||speaking)return;
  try{recognition.lang=$('language').value;recognition.start();}catch(e){status(e.message);}
}
function stop(){wanted=false;clearTimeout(retry);recognition?.abort();speechSynthesis.cancel();speaking=false;document.body.classList.remove('listening');$('start').disabled=false;$('stopVoice').disabled=true;status('Microphone off');}
function speak(text){
  $('reply').textContent=text;awaitReplyUntil=Date.now()+45000;
  if(!$('speak').checked||!wanted)return;
  speaking=true;recognition.abort();speechSynthesis.cancel();
  const utterance=new SpeechSynthesisUtterance(text.replace(/https:\/\/\S+/g,'linked page').slice(0,1500));utterance.lang=$('language').value;
  const done=()=>{speaking=false;awaitReplyUntil=Date.now()+45000;schedule();};utterance.onend=done;utterance.onerror=done;speechSynthesis.speak(utterance);
}
if(!Recognition){$('start').disabled=true;status('Speech recognition is unavailable here. Use Google Chrome with speech services enabled, or type in the side panel.');}
else{
  recognition=new Recognition();recognition.continuous=true;recognition.interimResults=true;
  recognition.onstart=()=>{running=true;status('Listening · say “Hey Chrome”');document.body.classList.add('listening');};
  recognition.onend=()=>{running=false;schedule();};
  recognition.onerror=e=>{
    if(['not-allowed','service-not-allowed','audio-capture'].includes(e.error)){stop();status(`Microphone error: ${e.error}. Allow microphone access in Chrome, then try again.`);}
    else if(e.error!=='aborted'&&e.error!=='no-speech'){status(`Speech service: ${e.error}. Check your connection.`);if(e.error==='network')stop();}
  };
  recognition.onresult=async event=>{
    if(speaking||!wanted)return;
    for(let i=event.resultIndex;i<event.results.length;i++){
      const result=event.results[i],raw=result[0].transcript.trim();$('transcript').textContent=raw;
      if(!result.isFinal)continue;
      const wake=/\b(?:hey|hi|okay|ok)\s*(?:chrome|chrom)\b[,.!\s]*/i;
      const hasWake=wake.test(raw);
      if(!hasWake&&Date.now()>awaitReplyUntil)continue;
      const command=raw.replace(wake,'').trim();awaitReplyUntil=Date.now()+45000;
      if(!command){speak('I’m listening. What would you like to do?');continue;}
      if(/^(stop listening|microphone off|go to sleep)[.!]?$/i.test(command)){stop();continue;}
      if(/^(stop|cancel)[.!]?$/i.test(command)){await chrome.runtime.sendMessage({type:'STOP'});status('Stopped the pending request.');continue;}
      if(busy){status('Working on your previous request. Say “stop” to cancel.');continue;}
      busy=true;status('Thinking…');
      try{const response=await chrome.runtime.sendMessage({type:'TURN',text:command});if(response?.error)status(response.error);}catch(e){status(e.message);}finally{busy=false;}
    }
  };
}
$('start').onclick=async()=>{
  try{
    // A visible top-level document can request microphone access with a user gesture.
    const stream=await navigator.mediaDevices.getUserMedia({audio:true});stream.getTracks().forEach(t=>t.stop());
    wanted=true;$('start').disabled=true;$('stopVoice').disabled=false;begin();
  }catch(e){status(`Could not open microphone: ${e.message}`);}
};
$('stopVoice').onclick=stop;
chrome.runtime.onMessage.addListener(req=>{
  if(req.type!=='STATE')return;
  busy=req.state.busy;
  const last=req.state.messages.filter(m=>m.role==='assistant').at(-1);
  if(last&&last.id!==lastSpoken){lastSpoken=last.id;speak(last.text);}
  if(req.state.error)status(req.state.error);
});
// Do not speak an old conversation when opening this tab.
const initial=await chrome.runtime.sendMessage({type:'GET_STATE'});lastSpoken=initial?.state?.messages.filter(m=>m.role==='assistant').at(-1)?.id || '';
addEventListener('pagehide',stop);
