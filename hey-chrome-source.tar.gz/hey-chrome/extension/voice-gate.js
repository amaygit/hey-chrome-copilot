// Local amplitude gate for barge-in. No audio leaves this module.
globalThis.HCVoiceGate=class {
  constructor(){this.floor=.004;this.since=null;this.active=false;this.lastLoud=0;this.readingAt=null;this.echo=.004;}
  sample(rms,time,reading){
    if(reading&&this.readingAt===null){this.readingAt=time;this.echo=this.floor;}
    if(!reading)this.readingAt=null;
    const warming=reading&&time-this.readingAt<450;
    // Do not learn a loud user interruption as the speaker's echo baseline.
    if(warming&&rms<Math.max(.02,this.floor*4))this.echo=this.echo*.8+rms*.2;
    if(!reading&&!this.active&&rms<.025)this.floor=this.floor*.96+rms*.04;
    const threshold=reading?Math.max(.018,this.floor*4,this.echo*2.4):Math.max(.012,this.floor*3.5);
    let started=false,ended=false;
    if(rms>threshold){
      this.lastLoud=time;if(this.since===null)this.since=time;
      if(!this.active&&time-this.since>=140){this.active=true;started=true;}
    }else{this.since=null;if(this.active&&time-this.lastLoud>500){this.active=false;ended=true;}}
    return{started,ended,active:this.active,level:Math.min(1,rms*8)};
  }
};
