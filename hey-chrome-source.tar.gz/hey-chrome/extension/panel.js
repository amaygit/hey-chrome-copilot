const $=id=>document.getElementById(id);
const send=async(type,extra={})=>{const r=await chrome.runtime.sendMessage({type,...extra});if(r?.error)throw new Error(r.error);return r;};
let current, config;
function error(e){$('error').textContent=e.message;$('error').classList.remove('hidden');}
function textNode(tag,text,cls){const el=document.createElement(tag);el.textContent=text;if(cls)el.className=cls;return el;}
function render(state){
  current=state;
  $('welcome').classList.toggle('hidden',state.messages.length>0);
  $('status').textContent=state.busy?(state.phase||'Working on your request…'):state.pending?'An action is ready to review':state.mode==='demo'?'Demo mode · no live AI':state.mode==='preview'?'UI preview · simulated responses':'Ready when you are';
  if(state.mode==='preview')document.querySelector('.version').textContent='UI PREVIEW';
  $('statusDot').classList.toggle('busy',state.busy);$('send').disabled=state.busy;$('stop').classList.toggle('hidden',!state.busy);
  $('target').textContent=state.target?`${state.target.title || 'Selected tab'}`:'No page selected';
  const msgs=$('messages');const nearEnd=window.innerHeight+window.scrollY>=document.body.scrollHeight-180;
  const oldLast=msgs.lastElementChild?.dataset.id;
  msgs.replaceChildren();
  for(const m of state.messages){
    const el=textNode('article','',`bubble ${m.role}`);el.dataset.id=m.id;
    if(m.role!=='tool')el.append(textNode('span',m.role==='user'?'YOU':'HEY CHROME','who'));
    // Never interpret AI or webpage text as HTML. Link only explicit HTTPS URLs.
    for(const part of m.text.split(/(https:\/\/[^\s<>]+)/g)){
      if(part.startsWith('https://')){const a=textNode('a',part);a.href=part;a.target='_blank';a.rel='noopener noreferrer';el.append(a);}else el.append(document.createTextNode(part));
    }
    msgs.append(el);
  }
  const f=state.flight,trip=$('trip');trip.replaceChildren();trip.classList.toggle('hidden',!f?.origin&&!f?.destination);
  if(f?.origin||f?.destination){trip.append(textNode('h2',`${f.origin || 'From?'} → ${f.destination || 'To?'}`));trip.append(textNode('p',[f.departureDate,f.returnDate?`Return ${f.returnDate}`:'',f.tripType,f.passengers?`${f.passengers} passenger(s)`:''].filter(Boolean).join(' · ')));trip.append(textNode('p',[f.departureTime,f.priority,f.cabin].filter(Boolean).join(' · ')));}
  $('approval').classList.toggle('hidden',!state.pending);
  if(state.pending){const a=state.pending.action;$('actionTitle').textContent={web_search:'Research current web sources',navigate:'Open a new page',click:'Click an element',fill:'Fill a field',scroll:'Scroll the page',back:'Go back'}[a.type];$('actionDetail').textContent=a.query || a.url || [a.label,a.value!==undefined?`Value: ${a.value}`:'',a.direction].filter(Boolean).join('\n');$('actionNote').textContent=a.type==='web_search'?'This query goes to Gemini with Google Search grounding. Review it before sharing.':'Runs once on the reviewed tab. Final purchases and sensitive steps stay manual.';}
  $('error').textContent=state.error||'';$('error').classList.toggle('hidden',!state.error);
  if(nearEnd&&oldLast!==msgs.lastElementChild?.dataset.id)window.scrollTo({top:document.body.scrollHeight,behavior:'smooth'});
}
async function loadSettings(){config=(await send('GET_SETTINGS')).settings;$('backend').value=config.backend;$('token').value=config.token;$('share').checked=config.share;$('sharing').textContent=config.share?'Page sharing on · site access required':'Page sharing is off';if(config.assistantName)$('assistantName').textContent=config.assistantName;if(current?.mode!=='preview')document.querySelector('.version').textContent=config.backend.startsWith('https:')?'SHARED SERVER':'LOCAL BACKEND';}
function readSettings(){return{backend:$('backend').value,token:$('token').value,share:$('share').checked};}
async function saveConnection(){const s=readSettings(),u=new URL(s.backend);if(u.protocol==='https:'){const allowed=await chrome.permissions.request({origins:[u.origin+'/*']});if(!allowed)throw new Error('Server permission was declined.');}await send('SETTINGS',{settings:s});await loadSettings();}
async function submit(text){if(!text.trim())return;$('input').value='';try{await send('TURN',{text});}catch(e){error(e);}}
$('composer').addEventListener('submit',e=>{e.preventDefault();submit($('input').value);});
$('input').addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();submit($('input').value);}});
document.querySelectorAll('[data-prompt]').forEach(el=>el.addEventListener('click',()=>submit(el.dataset.prompt)));
$('settingsButton').onclick=async()=>{try{await loadSettings();$('settings').showModal();}catch(e){error(e);}};
$('closeSettings').onclick=()=>$('settings').close();
$('settingsForm').onsubmit=async e=>{e.preventDefault();try{await saveConnection();$('settings').close();}catch(e){$('connection').textContent=e.message;}};
$('testConnection').onclick=async()=>{try{await saveConnection();const r=await send('HEALTH');$('connection').textContent=r.configured?`Connected · ${r.assistantName || r.mode} · ${r.memberName || 'Owner'} · ${r.accuracy || r.model}`:'Connected. The server owner must configure Gemini.';}catch(e){$('connection').textContent=e.message;}};
$('bind').onclick=()=>send('BIND').catch(error);
$('grant').onclick=async()=>{
  try{
    if(!current.target)throw new Error('Select a webpage and click “Use current tab” first.');
    const tab=await chrome.tabs.get(current.target.id);const u=new URL(tab.url);
    if(u.protocol!=='https:')throw new Error('Choose a regular HTTPS website.');
    const granted=await chrome.permissions.request({origins:[u.origin+'/*']});
    if(granted){config=(await send('GET_SETTINGS')).settings;await send('SETTINGS',{settings:{...config,share:true}});await loadSettings();$('sharing').textContent=`Sharing enabled for ${u.hostname}`;}
  }catch(e){error(e);}
};
$('approve').onclick=()=>send('APPROVE',{id:current.pending?.id}).catch(error);
$('dismiss').onclick=()=>send('CANCEL_ACTION').catch(error);
$('stop').onclick=()=>send('STOP').catch(error);
$('reset').onclick=()=>send('RESET').catch(error);
$('voice').onclick=()=>send('VOICE').catch(error);
chrome.runtime.onMessage.addListener(req=>{if(req.type==='STATE')render(req.state);});
try{render((await send('GET_STATE')).state);await loadSettings();if(!config.token || (config.backend.startsWith('https:') && !await chrome.permissions.contains({origins:[new URL(config.backend).origin+'/*']})))$('settings').showModal();}catch(e){error(e);}
