@echo off
cd /d "%~dp0"
if not exist .env node scripts/setup.mjs
node --env-file=.env server/index.mjs
pause
