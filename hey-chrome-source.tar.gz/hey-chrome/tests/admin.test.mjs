import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,readFileSync,existsSync,unlinkSync,rmdirSync,writeFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import {join} from 'node:path';
import {createApp} from '../server/app.mjs';
import {createRuntimeStore,loadRuntimeSettings} from '../server/runtime-settings.mjs';
import {createTelemetry,sentryTarget} from '../server/telemetry.mjs';
import {hashToken,resolveMember} from '../server/access.mjs';
const owner='test-owner-code-01234567890123456789',member='test-member-code-01234567890123456789',key='TEST_PRIVATE_GEMINI_KEY_123456789';
function temp(t){const dir=mkdtempSync(fileURLToPath(new URL('../../../work/admin-test-',import.meta.url)));t.after(()=>{for(const n of ['settings.json','events.json'])if(existsSync(join(dir,n)))unlinkSync(join(dir,n));rmdirSync(dir);});return dir;}
async function lab(t,{fetchImpl=async()=>new Response('{}'),env={},provider}={}){
 const dir=temp(t),vars={GEMINI_API_KEY:key,GEMINI_MODEL:'gemini-test',HIGH_ACCURACY:'false',ACCESS_MEMBERS_JSON:JSON.stringify([{id:'member',name:'Tester',tokenHash:hashToken(member),revoked:false}]),...env},store=createRuntimeStore({env:vars,file:join(dir,'settings.json'),fetchImpl}),telemetry=createTelemetry({getSecrets:()=>[owner,key,...Object.values(vars)]});
 const config={token:owner,key,model:vars.GEMINI_MODEL,highAccuracy:false,adminStore:store,telemetry,adminFetch:fetchImpl,provider:provider||(async()=>({message:'Hi',intent:'general',flight:{},action:{type:'none'}})),getMembers:()=>JSON.parse(vars.ACCESS_MEMBERS_JSON),resolvePrincipal:t=>resolveMember('unused',t,vars.ACCESS_MEMBERS_JSON)};
 const app=createApp(config);await new Promise(r=>app.listen(0,'127.0.0.1',r));t.after(()=>new Promise(r=>{app.closeAllConnections();app.close(r);}));const base='http://127.0.0.1:'+app.address().port;
 let cookie='',csrf='';
 const call=async(path,{body,headers={},method}={})=>{const r=await fetch(base+path,{method:method||(body===undefined?'GET':'POST'),headers:{...(cookie?{Cookie:cookie}:{}),...(body===undefined?{}:{Origin:base,'content-type':'application/json','x-csrf-token':csrf}),...headers},...(body===undefined?{}:{body:JSON.stringify(body)})});const raw=Buffer.from(await r.arrayBuffer()),type=r.headers.get('content-type')||'';return{status:r.status,headers:r.headers,data:type.includes('json')?JSON.parse(raw):raw};};
 const login=async()=>{const r=await call('/api/admin/login',{body:{code:owner}});assert.equal(r.status,200);cookie=r.headers.get('set-cookie').split(';')[0];csrf=r.data.csrf;return r;};
 return{call,login,config,store,vars,telemetry,dir,base,get cookie(){return cookie;},get csrf(){return csrf;}};
}
test('admin HTML has a restrictive CSP; only owner login receives an HttpOnly session',async t=>{
 const a=await lab(t);let r=await a.call('/admin');assert.equal(r.status,200);assert.match(r.headers.get('content-security-policy'),/frame-ancestors 'none'/);assert.ok(!r.data.includes(Buffer.from(key)));
 assert.equal((await a.call('/api/admin/status',{headers:{Authorization:'Bearer '+member}})).status,401);assert.equal((await a.call('/api/admin/login',{body:{code:member}})).status,401);
 r=await a.login();assert.match(r.headers.get('set-cookie'),/HttpOnly; SameSite=Strict/);assert.ok(!JSON.stringify(r.data).includes(owner));r=await a.call('/api/admin/status');assert.equal(r.status,200);assert.ok(!JSON.stringify(r.data).includes(key));assert.ok(!JSON.stringify(r.data).includes(hashToken(member)));
});
test('admin mutations reject cross-origin requests, missing CSRF and protected environment names',async t=>{
 const a=await lab(t);await a.login();assert.equal((await a.call('/api/admin/settings',{body:{field:'GEMINI_MODEL',value:'new-model'},headers:{Origin:'https://evil.example'}})).status,403);
 assert.equal((await a.call('/api/admin/settings',{body:{field:'GEMINI_MODEL',value:'new-model'},headers:{'x-csrf-token':'wrong'}})).status,403);
 assert.equal((await a.call('/api/admin/settings',{body:{field:'BACKEND_TOKEN',value:'new-owner-key'}})).status,400);assert.equal(a.config.token,owner);
 const bad=a.cookie.slice(0,-1)+(a.cookie.endsWith('x')?'y':'x');assert.equal((await a.call('/api/admin/status',{headers:{Cookie:bad}})).status,401);
});
test('validated key rotation persists before applying and metadata never exposes secret values',async t=>{
 let probe;const a=await lab(t,{fetchImpl:async(url,init)=>{probe={url,init};return new Response('{}');}});await a.login();const next='NEW_PRIVATE_GEMINI_KEY_987654321';
 let r=await a.call('/api/admin/settings',{body:{field:'GEMINI_API_KEY',value:next}});assert.equal(r.status,200);assert.equal(a.config.key,next);assert.equal(probe.init.headers['x-goog-api-key'],next);assert.ok(!probe.url.includes(next));
 const restored={};loadRuntimeSettings(restored,join(a.dir,'settings.json'));assert.equal(restored.GEMINI_API_KEY,next);assert.ok(restored.GEMINI_API_KEY!==key);
 r=await a.call('/api/admin/status');assert.equal(r.data.settings.find(d=>d.key==='GEMINI_API_KEY').configured,true);assert.ok(!JSON.stringify(r.data).includes(next));assert.ok(!JSON.stringify((await a.call('/api/admin/events')).data).includes(next));
 r=await a.call('/api/admin/settings',{body:{field:'GEMINI_MODEL',value:'new-gemini-model'}});assert.equal(r.status,200);assert.equal((await a.call('/health',{headers:{Authorization:'Bearer '+owner}})).data.model,'new-gemini-model');
});
test('invalid replacement keys leave the current key and persistent snapshot unchanged',async t=>{
 const a=await lab(t,{fetchImpl:async()=>new Response('{}',{status:403})});await a.login();const r=await a.call('/api/admin/settings',{body:{field:'GEMINI_API_KEY',value:'BAD_PRIVATE_KEY_987654321'}});assert.equal(r.status,400);assert.equal(a.config.key,key);assert.equal(a.store.get('GEMINI_API_KEY'),key);assert.equal(existsSync(join(a.dir,'settings.json')),false);
});
test('member ZIPs exclude provider/owner credentials and revocation takes effect immediately',async t=>{
 const a=await lab(t);await a.login();let r=await a.call('/api/admin/members',{body:{name:'Alex'}});assert.equal(r.status,200);assert.equal(r.data.readUInt32LE(0),0x04034b50);assert.ok(!r.data.includes(Buffer.from(owner)));assert.ok(!r.data.includes(Buffer.from(key)));
 const match=r.data.toString('utf8').match(/\{"backend":"http:\/\/127\.0\.0\.1:\d+","token":"([a-f0-9]{64})","assistantName":"Hey Chrome","memberName":"Alex"\}/);assert.ok(match);const token=match[1];r=await a.call('/health',{headers:{Authorization:'Bearer '+token}});assert.equal(r.status,200);assert.equal(r.data.memberName,'Alex');assert.ok(!('research' in r.data));
 const m=a.config.getMembers().find(m=>m.name==='Alex');await a.call('/api/admin/members/revoke',{body:{id:m.id}});assert.equal((await a.call('/health',{headers:{Authorization:'Bearer '+token}})).status,401);
});
test('extension diagnostics accept fixed categories only, discard supplied text and limit reports',async t=>{
 const a=await lab(t),headers={Authorization:'Bearer '+member,Origin:'chrome-extension://'+'b'.repeat(32)};assert.equal((await a.call('/api/client-errors',{body:{kind:'made-up',message:'private words'},headers})).status,400);
 for(let n=0;n<3;n++)assert.equal((await a.call('/api/client-errors',{body:{kind:'speech_network',message:'private words '+key},headers})).status,200);
 assert.equal((await a.call('/api/client-errors',{body:{kind:'speech_network'},headers})).status,429);assert.ok(!JSON.stringify(a.telemetry.events()).includes('private words'));assert.ok(!JSON.stringify(a.telemetry.events()).includes(key));
});
test('failed background jobs appear in redacted telemetry without recording prompt/history',async t=>{
 const a=await lab(t,{provider:async()=>{throw Error('Provider failed '+key);}});const r=await a.call('/api/jobs',{body:{message:'SENSITIVE PROMPT'},headers:{Authorization:'Bearer '+member,Origin:'chrome-extension://'+'b'.repeat(32)}});assert.equal(r.status,202);
 await new Promise(r=>setTimeout(r,10));const entries=a.telemetry.events();assert.ok(entries.some(e=>e.operation==='assistant.job'));assert.ok(!JSON.stringify(entries).includes(key));assert.ok(!JSON.stringify(entries).includes('SENSITIVE PROMPT'));
});
test('Render persistence updates only the dedicated settings variable, then requests a deploy',async()=>{
 const calls=[],env={RENDER:'true',RENDER_SERVICE_ID:'srv-abcdefgh1234',RENDER_ADMIN_API_KEY:'PRIVATE_RENDER_KEY_12345',GEMINI_API_KEY:key};const store=createRuntimeStore({env,fetchImpl:async(url,init)=>{calls.push({url,init});return new Response(JSON.stringify({id:'dep-test'}));}});
 const r=await store.save('GEMINI_API_KEY','NEXT_PRIVATE_KEY_987654321');assert.equal(r.restartRequested,true);assert.equal(calls.length,2);assert.match(calls[0].url,/\/env-vars\/HEY_CHROME_SETTINGS_JSON$/);assert.equal(calls[0].init.method,'PUT');assert.equal(JSON.parse(JSON.parse(calls[0].init.body).value).values.GEMINI_API_KEY,'NEXT_PRIVATE_KEY_987654321');assert.match(calls[1].url,/\/deploys$/);assert.ok(!JSON.stringify(r).includes('NEXT_PRIVATE_KEY'));
});
test('Render save failure does not change active keys; a deploy failure reports saved state honestly',async()=>{
 const env={RENDER:'true',RENDER_SERVICE_ID:'srv-abcdefgh1234',RENDER_ADMIN_API_KEY:'PRIVATE_RENDER_KEY_12345',GEMINI_API_KEY:key};let good=false;const store=createRuntimeStore({env,fetchImpl:async()=>new Response('{}',{status:good?200:403})});await assert.rejects(()=>store.save('GEMINI_API_KEY','NEXT_PRIVATE_KEY_987654321'));assert.equal(store.get('GEMINI_API_KEY'),key);
 let n=0;const s=createRuntimeStore({env,fetchImpl:async()=>new Response('{}',{status:++n===1?200:403})});const r=await s.save('GEMINI_API_KEY','NEXT_PRIVATE_KEY_987654321');assert.equal(r.saved,true);assert.equal(r.restartRequested,false);assert.match(r.warning,/Saved persistently/);
});
test('Render connection is limited to this service and stores its integration credential server-side',async()=>{
 const calls=[],env={RENDER:'true',RENDER_SERVICE_ID:'srv-abcdefgh1234'},s=createRuntimeStore({env,fetchImpl:async(url,init)=>{calls.push({url,init});return new Response('{}');}});
 await assert.rejects(()=>s.connect({apiKey:'PRIVATE_RENDER_KEY_12345',serviceId:'srv-other12345678'}),/only this/);assert.equal(calls.length,0);
 const r=await s.connect({apiKey:'PRIVATE_RENDER_KEY_12345',serviceId:'srv-abcdefgh1234'});assert.equal(r.connected,true);assert.equal(s.status().ready,true);assert.ok(!JSON.stringify(r).includes('PRIVATE_RENDER_KEY'));assert.ok(calls.some(c=>c.url.endsWith('/env-vars/RENDER_ADMIN_API_KEY')));
});
test('hosted writes stay disabled until persistent Render integration is configured',async()=>{
 const s=createRuntimeStore({env:{RENDER:'true',GEMINI_API_KEY:key}});await assert.rejects(()=>s.save('GEMINI_API_KEY','NEXT_PRIVATE_KEY_987654321'),/Connect Render/);assert.equal(s.get('GEMINI_API_KEY'),key);
});
test('telemetry bounds and redacts persisted events and forwards only errors to allowed Sentry endpoints',async t=>{
 const dir=temp(t),sent=[];const telemetry=createTelemetry({limit:2,file:join(dir,'events.json'),getSecrets:()=>[key,owner],getDSN:()=> 'https://'+'a'.repeat(32)+'@o1.ingest.us.sentry.io/123',fetchImpl:async(url,init)=>{sent.push({url,init});return new Response('{}');}});
 telemetry.capture({level:'info',operation:'admin.login',message:'Signed in'});telemetry.capture({source:'extension',operation:'voice',message:key+' Bearer '+owner+' https://site.example/x?private=secret',prompt:'PRIVATE PROMPT'});telemetry.capture({operation:'test',message:'Latest'});await new Promise(r=>setTimeout(r,10));
 const raw=readFileSync(join(dir,'events.json'),'utf8');assert.equal(JSON.parse(raw).length,2);assert.ok(!raw.includes(key));assert.ok(!raw.includes(owner));assert.ok(!raw.includes('private=secret'));assert.ok(!raw.includes('PRIVATE PROMPT'));assert.equal(sent.length,2);assert.ok(!sent[0].init.body.includes(key));assert.match(sent[0].url,/ingest.us.sentry.io\/api\/123\/envelope/);
 assert.throws(()=>sentryTarget('https://key@127.0.0.1/123'));assert.throws(()=>sentryTarget('http://'+'a'.repeat(32)+'@o1.ingest.sentry.io/123'));
});


test('admin login is throttled and session cookies remain valid after a process restart',async t=>{
 const a=await lab(t),b=await lab(t);await a.login();assert.equal((await b.call('/api/admin/status',{headers:{Cookie:a.cookie}})).status,200);
 for(let n=0;n<5;n++)assert.equal((await a.call('/api/admin/login',{body:{code:'incorrect'}})).status,401);
 assert.equal((await a.call('/api/admin/login',{body:{code:owner}})).status,429);
});
