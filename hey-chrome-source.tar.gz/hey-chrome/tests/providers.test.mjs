import test from 'node:test';
import assert from 'node:assert/strict';
import {groqTurn,groqReview} from '../server/groq.mjs';
import {createApp} from '../server/app.mjs';
import {fetchGemini} from '../server/gemini-http.mjs';
import {configuredResearch} from '../server/research.mjs';
const plan={message:'I will open the page.',intent:'general',flight:{},action:{type:'navigate',url:'https://example.com'}};
const completion=(value,finish='stop')=>new Response(JSON.stringify({choices:[{finish_reason:finish,message:{content:typeof value==='string'?value:JSON.stringify(value),reasoning:'Private reasoning must not become the answer.'}}]}));
test('Groq uses authenticated JSON generation and the same planner schema/instructions',async()=>{
 let sent;const r=await groqTurn({message:'Open example.com'},{key:'GROQ_PRIVATE_TEST_KEY_123456',fetchImpl:async(url,init)=>{sent={url,init};return completion(plan);}});
 assert.equal(r.action.type,'navigate');assert.equal(sent.url,'https://api.groq.com/openai/v1/chat/completions');assert.equal(sent.init.headers.Authorization,'Bearer GROQ_PRIVATE_TEST_KEY_123456');const b=JSON.parse(sent.init.body);assert.equal(b.model,'openai/gpt-oss-120b');assert.equal(b.response_format.type,'json_object');assert.match(b.messages[0].content,/untrusted DATA/);assert.ok(!sent.init.body.includes('GROQ_PRIVATE_TEST_KEY'));assert.ok(!JSON.stringify(r).includes('Private reasoning'));
});
test('Groq retries malformed or truncated JSON once and never returns incomplete actions',async()=>{
 let n=0;const r=await groqTurn({},{key:'test',fetchImpl:async()=>++n===1?completion('{"message":'):completion(plan)});assert.equal(n,2);assert.equal(r.action.type,'navigate');
 n=0;await assert.rejects(()=>groqTurn({},{key:'test',fetchImpl:async()=>{n++;return completion(plan,'length');}}),/previous details are still saved/);assert.equal(n,2);
});
test('Groq independent review accepts only allow, ask or block',async()=>{
 assert.equal((await groqReview({proposal:plan},{key:'test',fetchImpl:async()=>completion({verdict:'allow',message:''})})).verdict,'allow');
 await assert.rejects(()=>groqReview({},{key:'test',fetchImpl:async()=>completion({verdict:'execute',message:''})}),/previous details are still saved/);
});
test('Groq rate limits are not retried and cancellation cannot start a retry',async()=>{
 let n=0;await assert.rejects(()=>groqTurn({},{key:'test',fetchImpl:async()=>{n++;return new Response('{}',{status:429});}}),/Groq rate or free-tier limit/);assert.equal(n,1);
 const c=new AbortController();c.abort();n=0;await assert.rejects(()=>groqTurn({},{key:'test',signal:c.signal,fetchImpl:async()=>{n++;return completion(plan);}}));assert.equal(n,0);
});
async function server(t,options){const token='provider-test-owner-01234567890123456789',app=createApp({token,model:'test',...options});await new Promise(r=>app.listen(0,'127.0.0.1',r));t.after(()=>new Promise(r=>{app.closeAllConnections();app.close(r);}));return async body=>{const r=await fetch('http://127.0.0.1:'+app.address().port+'/api/turn',{method:'POST',headers:{Authorization:'Bearer '+token,'content-type':'application/json'},body:JSON.stringify(body)});return{status:r.status,data:await r.json()};};}
test('hello is answered locally with zero planner or reviewer calls, even without an API key',async t=>{
 const turn=await server(t,{provider:async()=>{throw Error('No model should run');},review:async()=>{throw Error('No reviewer should run');}});const r=await turn({message:'hello'});assert.equal(r.status,200);assert.equal(r.data.mode,'local');assert.match(r.data.message,/Hello/);assert.equal(r.data.action,null);
 const noKey=await server(t,{});assert.equal((await noKey({message:'नमस्ते'})).data.mode,'local');assert.equal((await noKey({message:'Explain a bicycle'})).status,503);
});
test('greeting recognition never intercepts an actual browsing request',async t=>{
 let calls=0;const turn=await server(t,{provider:async()=>{calls++;return plan;}});const r=await turn({message:'Hello, open example.com'});assert.equal(r.status,200);assert.equal(calls,1);assert.equal(r.data.action.type,'navigate');
});
test('selected Groq handles both planning and independent review with existing action validation',async t=>{
 let calls=0;const turn=await server(t,{aiProvider:'groq',groqKey:'GROQ_TEST_KEY_PRIVATE',key:'GEMINI_MUST_NOT_BE_USED',highAccuracy:true,groqFetch:async()=>completion(++calls===1?plan:{verdict:'allow',message:''})});const r=await turn({message:'Open example.com'});assert.equal(r.status,200);assert.equal(r.data.mode,'groq');assert.equal(r.data.review,'allow');assert.equal(calls,2);assert.equal(r.data.action.url,'https://example.com/');
});
test('selected Groq does not fall back to Gemini without a Groq key or through search',async t=>{
 const turn=await server(t,{aiProvider:'groq',key:'GEMINI_MUST_NOT_BE_USED'});assert.equal((await turn({message:'Explain a bicycle'})).status,503);assert.deepEqual(configuredResearch({aiProvider:'groq',keylessSearch:false,key:'Gemini'}).diagnostics(),[]);
});
test('Gemini transient timeouts and network errors receive only one inference retry',async()=>{
 for(const error of [new DOMException('Timed out','TimeoutError'),new TypeError('Network failed')]){let n=0;const r=await fetchGemini({key:'test',model:'test',retryDelayMs:0,fetchImpl:async()=>{if(++n===1)throw error;return new Response('{}');}},{});assert.equal(r.status,200);assert.equal(n,2);}
 let n=0;await assert.rejects(()=>fetchGemini({key:'test',model:'test',retryDelayMs:0,fetchImpl:async()=>{n++;throw new DOMException('Timed out','TimeoutError');}},{}));assert.equal(n,2);
});
test('user cancellation is never treated as a transient inference timeout',async()=>{
 let n=0;const c=new AbortController();await assert.rejects(()=>fetchGemini({key:'test',model:'test',retryDelayMs:0,signal:c.signal,fetchImpl:async()=>{n++;c.abort();throw c.signal.reason;}},{}));assert.equal(n,1);
});
