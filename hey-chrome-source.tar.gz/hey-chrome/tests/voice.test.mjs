import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import vm from 'node:vm';
const code=await readFile(new URL('../extension/voice.js',import.meta.url),'utf8');
const gateCode=await readFile(new URL('../extension/voice-gate.js',import.meta.url),'utf8');
async function voice(t,{audio=false,prefs,voices=[],turnImpl,trackInput=false,trackReject=false}={}){
  const elements=new Map(),messages=[],utterances=[],timers=new Map();let listener,recognizer,cancels=0,now=1000000,next=0,stops=0,pauses=0;
  const classes=()=>{const set=new Set();return{add:x=>set.add(x),remove:x=>set.delete(x),toggle:(x,on)=>on?set.add(x):set.delete(x),contains:x=>set.has(x)};};
  const el=id=>{if(!elements.has(id))elements.set(id,{textContent:'',value:id==='language'?'en-IN':'',checked:true,disabled:false,style:{},classList:classes()});return elements.get(id);};
  const later=(fn,ms,interval=0)=>{const id=++next;timers.set(id,{fn,at:now+ms,interval});return id;};
  class Recognition{constructor(){recognizer=this;this.running=false;this.aborts=0;}start(track){this.lastTrack=track;if(track&&trackReject)throw new TypeError('Unsupported track');this.running=true;this.onstart?.();}abort(){this.aborts++;this.running=false;this.onend?.();}}
  const speechSynthesis={cancel(){cancels++;},pause(){pauses++;},resume(){},getVoices:()=>voices,speak:u=>utterances.push(u)};
  const chrome={storage:{local:{get:async()=>({voicePrefs:prefs}),set:async()=>{}}},runtime:{sendMessage:async r=>{messages.push(r);if(r.type==='TURN'&&turnImpl)return turnImpl(r);return r.type==='GET_STATE'?{state:{busy:false,messages:[]}}:{ok:true};},onMessage:{addListener:fn=>listener=fn}}};
  let level=.004;class Audio{async resume(){}createAnalyser(){return{fftSize:1024,getFloatTimeDomainData:a=>a.fill(level)};}createMediaStreamSource(){return{connect(){}};}async close(){}}
  const liveTrack={kind:'audio',readyState:'live',stop(){stops++;}};
  const context={window:{SpeechRecognition:Recognition,...(audio?{AudioContext:Audio}:{})},document:{getElementById:el,body:{classList:classes()}},navigator:{mediaDevices:{getUserMedia:async()=>({getTracks:()=>[liveTrack],...(trackInput?{getAudioTracks:()=>[liveTrack]}:{})})}},chrome,speechSynthesis,SpeechSynthesisUtterance:class{constructor(text){this.text=text;}},setTimeout:(f,ms)=>later(f,ms),clearTimeout:id=>timers.delete(id),setInterval:(f,ms)=>later(f,ms,ms),clearInterval:id=>timers.delete(id),Date:class extends Date{static now(){return now;}},addEventListener(){}};
  vm.runInNewContext(gateCode,context);
  await vm.runInNewContext('(async()=>{'+code+'})()',context);
  const api={liveTrack,el,messages,utterances,recognizer,classes:context.document.body.classList,setLevel:value=>level=value,get pauses(){return pauses;},get cancels(){return cancels;},get stops(){return stops;},turns:()=>messages.filter(m=>m.type==='TURN').map(m=>m.text),state:state=>listener({type:'STATE',state:{messages:[],busy:false,...state}}),async hear(text,{final=true,index=0,confidence=.95}={}){const results=[];results[index]=Object.assign([{transcript:text,confidence}],{isFinal:final});await recognizer.onresult({resultIndex:index,results});},async advance(ms){const target=now+ms;for(let safety=0;safety<10000;safety++){const pair=[...timers].filter(([,v])=>v.at<=target).sort((a,b)=>a[1].at-b[1].at)[0];if(!pair)break;const [id,timer]=pair;now=timer.at;if(timer.interval)timer.at+=timer.interval;else timers.delete(id);await timer.fn();await Promise.resolve();}now=target;}};
  t.after(()=>el('stopVoice').onclick());await el('start').onclick();return api;
}
test('multiple final speech fragments form one message after a full pause',async t=>{
  const v=await voice(t);await v.hear('Hey Chrome book a flight for five adults');await v.advance(1200);await v.hear('on the 25th',{index:1});await v.advance(1700);await v.hear('of December',{index:2});
  assert.deepEqual(v.turns(),[]);assert.match(v.el('transcript').value,/five adults on the 25th of December/);await v.advance(2999);assert.deepEqual(v.turns(),[]);await v.advance(1);assert.deepEqual(v.turns(),['book a flight for five adults on the 25th of December']);
});
test('a stable interim result sends on time, and a late final cannot submit it again',async t=>{
  const v=await voice(t);await v.hear('Hey Chrome December',{final:false});await v.advance(2999);assert.deepEqual(v.turns(),[]);await v.advance(1);assert.deepEqual(v.turns(),['December']);await v.hear('Hey Chrome December');await v.advance(5000);assert.deepEqual(v.turns(),['December']);
});
test('low confidence does not silently require manual send; actual typing still pauses sending',async t=>{
  const v=await voice(t);await v.hear('Hey Chrome five adults',{confidence:.3});await v.advance(3000);assert.deepEqual(v.turns(),['five adults']);
  await v.hear('December 25th',{index:1});v.el('transcript').onfocus();v.el('transcript').value='December 26th';v.el('transcript').oninput();await v.advance(6000);assert.deepEqual(v.turns(),['five adults']);await v.el('sendVoice').onclick();assert.deepEqual(v.turns(),['five adults','December 26th']);
});
test('manual mode waits indefinitely and supports clearing a draft',async t=>{
  const v=await voice(t);v.el('pause').value='0';v.el('pause').onchange();await v.hear('Hey Chrome search Goa');await v.advance(20000);assert.deepEqual(v.turns(),[]);v.el('clearVoice').onclick();assert.equal(v.el('transcript').value,'');await v.hear('Hey Chrome search Delhi',{index:1});await v.el('sendVoice').onclick();assert.deepEqual(v.turns(),['search Delhi']);
});
test('speech during a running request is kept and sent after completion without spoken interruption',async t=>{
  const v=await voice(t);v.state({busy:true,messages:[{role:'assistant',id:'progress',text:'Searching'}]});await v.hear('Hey Chrome actually two passengers');await v.advance(4000);assert.deepEqual(v.turns(),[]);assert.equal(v.utterances.length,0);
  v.state({busy:false,messages:[{role:'assistant',id:'done',text:'A result'}]});await v.advance(0);assert.deepEqual(v.turns(),['actually two passengers']);assert.equal(v.utterances.length,0);
});
test('reading keeps recognition active and removes the spoken wake phrase to avoid self-interruption',async t=>{
  const v=await voice(t);v.state({messages:[{role:'assistant',id:'one',text:'Say Hey Chrome to ask another question.'}]});
  assert.equal(v.recognizer.running,true);assert.equal(v.recognizer.aborts,0);assert.equal(v.classes.contains('speaking'),true);assert.doesNotMatch(v.utterances.at(-1).text,/hey chrome/i);
});
test('an interim wake immediately interrupts reading without submitting an empty command',async t=>{
  const v=await voice(t);v.state({messages:[{role:'assistant',id:'one',text:'Here is a long answer.'}]});const before=v.cancels,old=v.utterances.at(-1);
  await v.hear('Hey Chrome',{final:false});assert.ok(v.cancels>before);assert.equal(v.classes.contains('speaking'),false);assert.equal(v.recognizer.running,true);await v.hear('Hey Chrome');await v.advance(6000);assert.deepEqual(v.turns(),[]);old.onend();assert.match(v.el('voiceStatus').textContent,/listening/i);
});
test('wake and command in the same utterance interrupt immediately but dispatch once after the pause',async t=>{
  const v=await voice(t);v.state({messages:[{role:'assistant',id:'one',text:'The previous reply.'}]});await v.hear('Hey Chrome quick search eclipses',{final:false});await v.hear('Hey Chrome quick search eclipses');await v.hear('Hey Chrome quick search eclipses');assert.deepEqual(v.turns(),[]);await v.advance(3000);assert.deepEqual(v.turns(),['quick search eclipses']);
});
test('ordinary TTS echo is ignored and late updates stay silent after interruption',async t=>{
  const v=await voice(t);v.state({messages:[{role:'assistant',id:'one',text:'Here are the results.'}]});await v.hear('Here are the results');assert.deepEqual(v.turns(),[]);await v.hear('Hey Chrome',{final:false,index:1});await v.hear('Hey Chrome',{index:1});v.state({messages:[{role:'assistant',id:'two',text:'Another progress update.'}]});assert.equal(v.utterances.length,1);
  await v.hear('open https://example.com',{index:2});await v.advance(3000);assert.deepEqual(v.turns(),['open https://example.com']);
});
test('recognition restarts during reading and retains drafts across recognition sessions',async t=>{
  const v=await voice(t);v.state({messages:[{role:'assistant',id:'one',text:'Still reading.'}]});v.recognizer.running=false;v.recognizer.onend();await v.advance(250);assert.equal(v.recognizer.running,true);
  await v.hear('Hey Chrome five adults');v.recognizer.onend();await v.advance(250);await v.hear('December 25th');await v.advance(3000);assert.deepEqual(v.turns(),['five adults December 25th']);
});
test('only completed answers are spoken, never a pending automatic browser step',async t=>{
  const v=await voice(t);v.state({busy:true,phase:'Researching…',messages:[{role:'assistant',id:'a1',text:'Searching'}]});assert.equal(v.el('activity').classList.contains('hidden'),false);assert.equal(v.utterances.length,0);
  v.state({busy:false,pending:{action:{type:'navigate'}},messages:[{role:'assistant',id:'a1',text:'Searching'}]});assert.equal(v.utterances.length,0);v.state({messages:[{role:'assistant',id:'a2',text:'Final answer'}]});assert.equal(v.utterances.length,1);assert.equal(v.el('activity').classList.contains('hidden'),true);
});
test('manual stop reading leaves recognition running; microphone off releases the capture stream',async t=>{
  const v=await voice(t);v.state({messages:[{role:'assistant',id:'one',text:'A reply.'}]});v.el('stopReading').onclick();assert.equal(v.recognizer.running,true);assert.equal(v.stops,0);v.el('stopVoice').onclick();assert.equal(v.recognizer.running,false);assert.equal(v.stops,1);assert.equal(v.el('voiceStatus').textContent,'Microphone off');
});
test('new typed requests restore narration, while updates for the interrupted task stay silent',async t=>{
  const v=await voice(t);v.state({messages:[{role:'user',id:'u1',text:'First question'},{role:'assistant',id:'a1',text:'First answer'}]});await v.hear('Hey Chrome');v.state({messages:[{role:'user',id:'u1',text:'First question'},{role:'assistant',id:'a2',text:'Late old-task update'}]});assert.equal(v.utterances.length,1);v.state({messages:[{role:'user',id:'u2',text:'New question'},{role:'assistant',id:'a3',text:'New answer'}]});await v.advance(80);assert.equal(v.utterances.length,2);
});
test('local audio gate rejects steady echo/noise, detects sustained louder input and releases',()=>{
  const c=vm.createContext({});vm.runInContext(gateCode,c);const gate=vm.runInContext('new HCVoiceGate()',c);
  for(let t=0;t<1000;t+=40)assert.equal(gate.sample(.004,t,false).started,false);
  for(let t=1000;t<2000;t+=40)assert.equal(gate.sample(.01,t,true).started,false);
  let starts=0;for(let t=2000;t<2400;t+=40)starts+=Number(gate.sample(.08,t,true).started);assert.equal(starts,1);
  assert.equal(gate.sample(.003,3000,false).ended,true);
});

test('optional noise interruption cancels playback only when explicitly enabled',async t=>{
  const v=await voice(t,{audio:true,prefs:{version:2,pauseMs:3000,interruptOnSpeech:true}});v.state({messages:[{role:'assistant',id:'read',text:'Reading a long result.'}]});v.setLevel(.01);await v.advance(800);assert.equal(v.classes.contains('speaking'),true);const before=v.cancels;
  v.setLevel(.08);await v.advance(240);assert.ok(v.cancels>before);assert.equal(v.classes.contains('speaking'),false);assert.equal(v.recognizer.running,true);assert.deepEqual(v.turns(),[]);await v.hear('Hey Chrome stop',{final:false});await v.hear('Hey Chrome stop');assert.ok(v.messages.some(m=>m.type==='STOP'));
});
test('constant microphone noise neither blocks auto-send nor cancels replies by default',async t=>{
  const v=await voice(t,{audio:true});await v.hear('Hey Chrome five adults');v.setLevel(.05);await v.advance(3000);assert.deepEqual(v.turns(),['five adults']);
  v.state({messages:[{role:'user',id:'u',text:'five adults'},{role:'assistant',id:'a',text:'What date?'}]});await v.advance(1000);assert.equal(v.utterances.length,1);assert.equal(v.classes.contains('speaking'),true);assert.equal(v.pauses,0);
});
test('an interruption at playback start is not learned as the echo baseline',()=>{
  const c=vm.createContext({});vm.runInContext(gateCode,c);const gate=vm.runInContext('new HCVoiceGate()',c);let starts=0;
  for(let t=0;t<400;t+=40)starts+=Number(gate.sample(.08,t,true).started);assert.equal(starts,1);
});

test('two-second auto send works with noise, interim results and low confidence together',async t=>{
  const v=await voice(t,{audio:true,prefs:{version:2,pauseMs:2000,interruptOnSpeech:false}});v.setLevel(.08);await v.hear('Hey Chrome open YouTube',{final:false,confidence:.2});await v.advance(1999);assert.deepEqual(v.turns(),[]);await v.advance(1);assert.deepEqual(v.turns(),['open YouTube']);
});
test('unchanged interim updates cannot endlessly reset the send deadline',async t=>{
  const v=await voice(t);await v.hear('Hey Chrome open YouTube',{final:false});await v.advance(1800);await v.hear('Hey Chrome open YouTube',{final:false});await v.advance(1200);assert.deepEqual(v.turns(),['open YouTube']);
});
test('new words reset the timer and focusing without typing does not force a manual send',async t=>{
  const v=await voice(t);await v.hear('Hey Chrome search',{final:false});await v.advance(2200);await v.hear('Hey Chrome search YouTube',{final:false});v.el('transcript').onfocus();await v.advance(2999);assert.deepEqual(v.turns(),[]);await v.advance(1);assert.deepEqual(v.turns(),['search YouTube']);
});
test('legacy noise interruption and manual-mode preferences migrate to safe automatic defaults',async t=>{
  const v=await voice(t,{prefs:{pauseMs:0,interruptOnSpeech:true}});assert.equal(v.el('interruptSpeech').checked,false);assert.equal(v.el('pause').value,'3000');await v.hear('Hey Chrome hello');await v.advance(3000);assert.deepEqual(v.turns(),['hello']);
});
test('a final reply that arrives before TURN resolves is spoken after the send completes',async t=>{
  let done;const wait=new Promise(r=>done=r),v=await voice(t,{turnImpl:()=>wait});await v.hear('Hey Chrome hello');const sending=v.el('sendVoice').onclick();v.state({messages:[{role:'user',id:'u',text:'hello'},{role:'assistant',id:'a',text:'Hello there'}]});assert.equal(v.utterances.length,0);done({ok:true});await sending;assert.equal(v.utterances.length,1);assert.equal(v.pauses,0);
});
test('speech chooses an available Hindi voice and does not require microphone input for explicit replay',async t=>{
  const voices=[{name:'English',lang:'en-US',default:true},{name:'Hindi',lang:'hi-IN'}],v=await voice(t,{voices});v.state({messages:[{role:'assistant',id:'hi',text:'नमस्ते, मैं आपकी सहायता कर सकता हूँ।'}]});assert.equal(v.utterances.at(-1).voice.name,'Hindi');v.el('stopVoice').onclick();v.el('readReply').onclick();await v.advance(80);assert.equal(v.utterances.length,2);
});
test('English replies use an available English voice even when recognition is set to Hindi',async t=>{
  const v=await voice(t,{prefs:{version:2,pauseMs:3000,language:'hi-IN'},voices:[{name:'English default',lang:'en-US',default:true}]});v.state({messages:[{role:'assistant',id:'en',text:'Hello, how can I help?'}]});assert.equal(v.utterances.at(-1).lang,'en-US');
});
test('the observed Hindi wake transcription interrupts without becoming a new chat message',async t=>{
  const v=await voice(t);v.state({messages:[{role:'assistant',id:'en',text:'Reading this reply.'}]});await v.hear('है क्रोम',{final:false});assert.equal(v.classes.contains('speaking'),false);await v.hear('है क्रोम');await v.advance(3000);assert.deepEqual(v.turns(),[]);
});
test('speech failures are visible and the explicit replay button can retry',async t=>{
  const v=await voice(t);v.state({messages:[{role:'assistant',id:'a',text:'A reply to read.'}]});v.utterances.at(-1).onerror({error:'language-unavailable'});assert.match(v.el('voiceStatus').textContent,/language-unavailable/);v.el('readReply').onclick();assert.equal(v.utterances.length,2);
});
test('a failed send is retained for retry rather than automatically resubmitted in a loop',async t=>{
  const v=await voice(t,{turnImpl:async()=>({error:'Offline'})});await v.hear('Hey Chrome hello');await v.advance(30000);assert.deepEqual(v.turns(),['hello']);assert.match(v.el('draftStatus').textContent,/retry/);await v.el('sendVoice').onclick();await v.advance(10000);assert.deepEqual(v.turns(),['hello','hello']);
});
test('turning read replies on reads a waiting final answer instead of losing it',async t=>{
  const v=await voice(t);v.el('speak').checked=false;v.state({messages:[{role:'assistant',id:'a',text:'A waiting answer.'}]});assert.equal(v.utterances.length,0);v.el('speak').checked=true;v.el('speak').onchange();assert.equal(v.utterances.length,1);
});

test('a final bare wake removes stale interim text instead of submitting a wake phrase',async t=>{
 const v=await voice(t);await v.hear('Hey Chrome hey Chrome',{final:false});await v.hear('Hey Chrome');await v.advance(4000);assert.deepEqual(v.turns(),[]);assert.equal(v.el('transcript').value,'');
});
test('a wake phrase split across recognition segments wakes without sending the phrase',async t=>{
 const v=await voice(t);v.state({messages:[{role:'assistant',id:'a',text:'A reply.'}]});await v.hear('hey');await v.hear('Chrome',{index:1});assert.equal(v.classes.contains('speaking'),false);await v.advance(3000);assert.deepEqual(v.turns(),[]);await v.hear('open YouTube',{index:2});await v.advance(3000);assert.deepEqual(v.turns(),['open YouTube']);
});
test('recognition receives the live processed microphone track when supported',async t=>{
 const v=await voice(t,{trackInput:true});assert.equal(v.recognizer.lastTrack,v.liveTrack);
});
test('browsers that reject audio-track input fall back to standard microphone recognition',async t=>{
 const v=await voice(t,{trackInput:true,trackReject:true});assert.equal(v.recognizer.running,true);assert.equal(v.recognizer.lastTrack,undefined);
});

test('temporary speech network errors reconnect twice, then stop visibly without retrying forever',async t=>{
 const v=await voice(t);v.recognizer.onerror({error:'network'});await v.advance(1000);assert.equal(v.recognizer.running,true);v.recognizer.onerror({error:'network'});await v.advance(2000);assert.equal(v.recognizer.running,true);v.recognizer.onerror({error:'network'});await v.advance(10000);assert.equal(v.recognizer.running,false);assert.match(v.el('voiceStatus').textContent,/after two reconnect/);
});
