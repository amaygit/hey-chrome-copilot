import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import vm from 'node:vm';
const code=await readFile(new URL('../extension/voice.js',import.meta.url),'utf8');
const gateCode=await readFile(new URL('../extension/voice-gate.js',import.meta.url),'utf8');
async function voice(t,{audio=false}={}){
  const elements=new Map(),messages=[],utterances=[],timers=new Map();let listener,recognizer,cancels=0,now=1000000,next=0,stops=0;
  const classes=()=>{const set=new Set();return{add:x=>set.add(x),remove:x=>set.delete(x),toggle:(x,on)=>on?set.add(x):set.delete(x),contains:x=>set.has(x)};};
  const el=id=>{if(!elements.has(id))elements.set(id,{textContent:'',value:id==='language'?'en-IN':'',checked:true,disabled:false,style:{},classList:classes()});return elements.get(id);};
  const later=(fn,ms,interval=0)=>{const id=++next;timers.set(id,{fn,at:now+ms,interval});return id;};
  class Recognition{constructor(){recognizer=this;this.running=false;this.aborts=0;}start(){this.running=true;this.onstart?.();}abort(){this.aborts++;this.running=false;this.onend?.();}}
  const speechSynthesis={cancel(){cancels++;},pause(){},resume(){},speak:u=>utterances.push(u)};
  const chrome={storage:{local:{get:async()=>({}),set:async()=>{}}},runtime:{sendMessage:async r=>{messages.push(r);return r.type==='GET_STATE'?{state:{busy:false,messages:[]}}:{ok:true};},onMessage:{addListener:fn=>listener=fn}}};
  let level=.004;class Audio{async resume(){}createAnalyser(){return{fftSize:1024,getFloatTimeDomainData:a=>a.fill(level)};}createMediaStreamSource(){return{connect(){}};}async close(){}}
  const context={window:{SpeechRecognition:Recognition,...(audio?{AudioContext:Audio}:{})},document:{getElementById:el,body:{classList:classes()}},navigator:{mediaDevices:{getUserMedia:async()=>({getTracks:()=>[{stop(){stops++;}}]})}},chrome,speechSynthesis,SpeechSynthesisUtterance:class{constructor(text){this.text=text;}},setTimeout:(f,ms)=>later(f,ms),clearTimeout:id=>timers.delete(id),setInterval:(f,ms)=>later(f,ms,ms),clearInterval:id=>timers.delete(id),Date:class extends Date{static now(){return now;}},addEventListener(){}};
  vm.runInNewContext(gateCode,context);
  await vm.runInNewContext('(async()=>{'+code+'})()',context);
  const api={el,messages,utterances,recognizer,classes:context.document.body.classList,setLevel:value=>level=value,get cancels(){return cancels;},get stops(){return stops;},turns:()=>messages.filter(m=>m.type==='TURN').map(m=>m.text),state:state=>listener({type:'STATE',state:{messages:[],busy:false,...state}}),async hear(text,{final=true,index=0,confidence=.95}={}){const results=[];results[index]=Object.assign([{transcript:text,confidence}],{isFinal:final});await recognizer.onresult({resultIndex:index,results});},async advance(ms){const target=now+ms;for(let safety=0;safety<10000;safety++){const pair=[...timers].filter(([,v])=>v.at<=target).sort((a,b)=>a[1].at-b[1].at)[0];if(!pair)break;const [id,timer]=pair;now=timer.at;if(timer.interval)timer.at+=timer.interval;else timers.delete(id);await timer.fn();await Promise.resolve();}now=target;}};
  t.after(()=>el('stopVoice').onclick());await el('start').onclick();return api;
}
test('multiple final speech fragments form one message after a full pause',async t=>{
  const v=await voice(t);await v.hear('Hey Chrome book a flight for five adults');await v.advance(1200);await v.hear('on the 25th',{index:1});await v.advance(1700);await v.hear('of December',{index:2});
  assert.deepEqual(v.turns(),[]);assert.match(v.el('transcript').value,/five adults on the 25th of December/);await v.advance(2999);assert.deepEqual(v.turns(),[]);await v.advance(1);assert.deepEqual(v.turns(),['book a flight for five adults on the 25th of December']);
});
test('an unfinished interim result prevents sending and reading over the user',async t=>{
  const v=await voice(t);await v.hear('Hey Chrome December',{final:false});await v.advance(6000);v.state({messages:[{role:'assistant',id:'a1',text:'An old answer'}]});assert.deepEqual(v.turns(),[]);assert.equal(v.utterances.length,0);
  await v.hear('Hey Chrome December 25th for five adults');await v.advance(3000);assert.deepEqual(v.turns(),['December 25th for five adults']);
});
test('editing and low confidence hold a transcript for review; Send now uses edited text',async t=>{
  const v=await voice(t);await v.hear('Hey Chrome why adults',{confidence:.3});await v.advance(6000);assert.deepEqual(v.turns(),[]);assert.match(v.el('draftStatus').textContent,/unclear/);
  v.el('transcript').onfocus();v.el('transcript').value='five adults on December 25th';v.el('transcript').oninput();await v.advance(6000);assert.deepEqual(v.turns(),[]);await v.el('sendVoice').onclick();assert.deepEqual(v.turns(),['five adults on December 25th']);
});
test('manual mode waits indefinitely and supports clearing a draft',async t=>{
  const v=await voice(t);v.el('pause').value='0';v.el('pause').onchange();await v.hear('Hey Chrome search Goa');await v.advance(20000);assert.deepEqual(v.turns(),[]);v.el('clearVoice').onclick();assert.equal(v.el('transcript').value,'');await v.hear('Hey Chrome search Delhi',{index:1});await v.el('sendVoice').onclick();assert.deepEqual(v.turns(),['search Delhi']);
});
test('speech during a running request is kept and sent after completion without spoken interruption',async t=>{
  const v=await voice(t);v.state({busy:true,messages:[{role:'assistant',id:'progress',text:'Searching'}]});await v.hear('Hey Chrome actually two passengers');await v.advance(4000);assert.deepEqual(v.turns(),[]);assert.equal(v.utterances.length,0);
  v.state({busy:false,messages:[{role:'assistant',id:'done',text:'A result'}]});await v.advance(0);assert.deepEqual(v.turns(),['actually two passengers']);assert.equal(v.utterances.length,0);
});
test('reading keeps recognition active and removes the spoken wake phrase to avoid self-interruption',async t=>{
  const v=await voice(t);v.state({messages:[{role:'assistant',id:'one',text:'Say Hey Chrome to ask another question.'}]});
  assert.equal(v.recognizer.running,true);assert.equal(v.recognizer.aborts,0);assert.equal(v.classes.contains('speaking'),true);assert.doesNotMatch(v.utterances.at(-1).text,/hey chrome/i);
});
test('an interim wake immediately interrupts reading without submitting an empty command',async t=>{
  const v=await voice(t);v.state({messages:[{role:'assistant',id:'one',text:'Here is a long answer.'}]});const before=v.cancels,old=v.utterances.at(-1);
  await v.hear('Hey Chrome',{final:false});assert.ok(v.cancels>before);assert.equal(v.classes.contains('speaking'),false);assert.equal(v.recognizer.running,true);await v.hear('Hey Chrome');await v.advance(6000);assert.deepEqual(v.turns(),[]);old.onend();assert.match(v.el('voiceStatus').textContent,/listening/i);
});
test('wake and command in the same utterance interrupt immediately but dispatch once after the pause',async t=>{
  const v=await voice(t);v.state({messages:[{role:'assistant',id:'one',text:'The previous reply.'}]});await v.hear('Hey Chrome quick search eclipses',{final:false});await v.hear('Hey Chrome quick search eclipses');await v.hear('Hey Chrome quick search eclipses');assert.deepEqual(v.turns(),[]);await v.advance(3000);assert.deepEqual(v.turns(),['quick search eclipses']);
});
test('ordinary TTS echo is ignored and late updates stay silent after interruption',async t=>{
  const v=await voice(t);v.state({messages:[{role:'assistant',id:'one',text:'Here are the results.'}]});await v.hear('Here are the results');assert.deepEqual(v.turns(),[]);await v.hear('Hey Chrome',{final:false,index:1});await v.hear('Hey Chrome',{index:1});v.state({messages:[{role:'assistant',id:'two',text:'Another progress update.'}]});assert.equal(v.utterances.length,1);
  await v.hear('open https://example.com',{index:2});await v.advance(3000);assert.deepEqual(v.turns(),['open https://example.com']);
});
test('recognition restarts during reading and retains drafts across recognition sessions',async t=>{
  const v=await voice(t);v.state({messages:[{role:'assistant',id:'one',text:'Still reading.'}]});v.recognizer.running=false;v.recognizer.onend();await v.advance(250);assert.equal(v.recognizer.running,true);
  await v.hear('Hey Chrome five adults');v.recognizer.onend();await v.advance(250);await v.hear('December 25th');await v.advance(3000);assert.deepEqual(v.turns(),['five adults December 25th']);
});
test('only completed answers are spoken, never a pending automatic browser step',async t=>{
  const v=await voice(t);v.state({busy:true,phase:'Researching…',messages:[{role:'assistant',id:'a1',text:'Searching'}]});assert.equal(v.el('activity').classList.contains('hidden'),false);assert.equal(v.utterances.length,0);
  v.state({busy:false,pending:{action:{type:'navigate'}},messages:[{role:'assistant',id:'a1',text:'Searching'}]});assert.equal(v.utterances.length,0);v.state({messages:[{role:'assistant',id:'a2',text:'Final answer'}]});assert.equal(v.utterances.length,1);assert.equal(v.el('activity').classList.contains('hidden'),true);
});
test('manual stop reading leaves recognition running; microphone off releases the capture stream',async t=>{
  const v=await voice(t);v.state({messages:[{role:'assistant',id:'one',text:'A reply.'}]});v.el('stopReading').onclick();assert.equal(v.recognizer.running,true);assert.equal(v.stops,0);v.el('stopVoice').onclick();assert.equal(v.recognizer.running,false);assert.equal(v.stops,1);assert.equal(v.el('voiceStatus').textContent,'Microphone off');
});
test('new typed requests restore narration, while updates for the interrupted task stay silent',async t=>{
  const v=await voice(t);v.state({messages:[{role:'user',id:'u1',text:'First question'},{role:'assistant',id:'a1',text:'First answer'}]});await v.hear('Hey Chrome');v.state({messages:[{role:'user',id:'u1',text:'First question'},{role:'assistant',id:'a2',text:'Late old-task update'}]});assert.equal(v.utterances.length,1);v.state({messages:[{role:'user',id:'u2',text:'New question'},{role:'assistant',id:'a3',text:'New answer'}]});assert.equal(v.utterances.length,2);
});
test('local audio gate rejects steady echo/noise, detects sustained louder input and releases',()=>{
  const c=vm.createContext({});vm.runInContext(gateCode,c);const gate=vm.runInContext('new HCVoiceGate()',c);
  for(let t=0;t<1000;t+=40)assert.equal(gate.sample(.004,t,false).started,false);
  for(let t=1000;t<2000;t+=40)assert.equal(gate.sample(.01,t,true).started,false);
  let starts=0;for(let t=2000;t<2400;t+=40)starts+=Number(gate.sample(.08,t,true).started);assert.equal(starts,1);
  assert.equal(gate.sample(.003,3000,false).ended,true);
});

test('microphone activity cancels playback before a wake transcript arrives, without sending noise',async t=>{
  const v=await voice(t,{audio:true});v.state({messages:[{role:'assistant',id:'read',text:'Reading a long result.'}]});v.setLevel(.01);await v.advance(800);assert.equal(v.classes.contains('speaking'),true);const before=v.cancels;
  v.setLevel(.08);await v.advance(240);assert.ok(v.cancels>before);assert.equal(v.classes.contains('speaking'),false);assert.equal(v.recognizer.running,true);assert.deepEqual(v.turns(),[]);await v.hear('Hey Chrome stop',{final:false});await v.hear('Hey Chrome stop');assert.ok(v.messages.some(m=>m.type==='STOP'));
});
test('microphone activity extends the pause while the user is still speaking',async t=>{
  const v=await voice(t,{audio:true});await v.hear('Hey Chrome five adults');v.setLevel(.05);await v.advance(5000);assert.deepEqual(v.turns(),[]);v.setLevel(.003);await v.advance(600);await v.hear('on December 25th',{index:1});await v.advance(3000);assert.deepEqual(v.turns(),['five adults on December 25th']);
});

test('an interruption at playback start is not learned as the echo baseline',()=>{
  const c=vm.createContext({});vm.runInContext(gateCode,c);const gate=vm.runInContext('new HCVoiceGate()',c);let starts=0;
  for(let t=0;t<400;t+=40)starts+=Number(gate.sample(.08,t,true).started);assert.equal(starts,1);
});
