import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import vm from 'node:vm';
const code=await readFile(new URL('../extension/voice.js',import.meta.url),'utf8');
async function voice(t){
  const elements=new Map(),messages=[],utterances=[];let listener,recognizer,cancels=0;
  const classes=()=>{const set=new Set();return{add:x=>set.add(x),remove:x=>set.delete(x),toggle:(x,on)=>on?set.add(x):set.delete(x),contains:x=>set.has(x)};};
  const el=id=>{if(!elements.has(id))elements.set(id,{textContent:'',value:id==='language'?'en-IN':'',checked:true,disabled:false,classList:classes()});return elements.get(id);};
  class Recognition{constructor(){recognizer=this;this.running=false;this.aborts=0;}start(){this.running=true;this.onstart?.();}abort(){this.aborts++;this.running=false;this.onend?.();}}
  const speechSynthesis={cancel(){cancels++;},speak:u=>utterances.push(u)};
  const chrome={runtime:{sendMessage:async r=>{messages.push(r);return r.type==='GET_STATE'?{state:{busy:false,messages:[]}}:{ok:true};},onMessage:{addListener:fn=>listener=fn}}};
  const context={window:{SpeechRecognition:Recognition},document:{getElementById:el,body:{classList:classes()}},navigator:{mediaDevices:{getUserMedia:async()=>({getTracks:()=>[{stop(){}}]})}},chrome,speechSynthesis,SpeechSynthesisUtterance:class{constructor(text){this.text=text;}},setTimeout,clearTimeout,setInterval,clearInterval,Date,addEventListener(){}};
  await vm.runInNewContext('(async()=>{'+code+'})()',context);
  const api={el,messages,utterances,recognizer,classes:context.document.body.classList,get cancels(){return cancels;},state:state=>listener({type:'STATE',state:{messages:[],busy:false,...state}}),async hear(text,{final=true,index=0}={}){const results=[];results[index]=Object.assign([{transcript:text}],{isFinal:final});await recognizer.onresult({resultIndex:index,results});}};
  t.after(()=>el('stopVoice').onclick());await el('start').onclick();return api;
}
test('reading keeps recognition active and removes the spoken wake phrase to avoid self-interruption',async t=>{
  const v=await voice(t);v.state({messages:[{role:'assistant',id:'one',text:'Say Hey Chrome to ask another question.'}]});
  assert.equal(v.recognizer.running,true);assert.equal(v.recognizer.aborts,0);assert.equal(v.classes.contains('speaking'),true);
  assert.doesNotMatch(v.utterances.at(-1).text,/hey chrome/i);assert.equal(v.el('stopReading').classList.contains('hidden'),false);
});
test('an interim wake phrase immediately interrupts reading without submitting an empty command',async t=>{
  const v=await voice(t);v.state({messages:[{role:'assistant',id:'one',text:'Here is a long answer.'}]});const before=v.cancels,old=v.utterances.at(-1);
  await v.hear('Hey Chrome',{final:false});assert.ok(v.cancels>before);assert.equal(v.classes.contains('speaking'),false);assert.equal(v.recognizer.running,true);
  await v.hear('Hey Chrome');assert.equal(v.messages.filter(m=>m.type==='TURN').length,0);assert.equal(v.utterances.length,1);
  old.onend();assert.match(v.el('voiceStatus').textContent,/listening|What would you/i);
});
test('wake and new command in the same utterance dispatch once after interrupting',async t=>{
  const v=await voice(t);v.state({messages:[{role:'assistant',id:'one',text:'The previous reply.'}]});
  await v.hear('Hey Chrome quick search eclipses',{final:false});await v.hear('Hey Chrome quick search eclipses');await v.hear('Hey Chrome quick search eclipses');
  assert.deepEqual(v.messages.filter(m=>m.type==='TURN').map(m=>m.text),['quick search eclipses']);
});
test('ordinary TTS echo is ignored and late updates stay silent after the user interrupts',async t=>{
  const v=await voice(t);v.state({messages:[{role:'assistant',id:'one',text:'Here are the results.'}]});
  await v.hear('Here are the results');assert.equal(v.messages.filter(m=>m.type==='TURN').length,0);
  await v.hear('Hey Chrome',{final:false,index:1});await v.hear('Hey Chrome',{index:1});
  v.state({messages:[{role:'assistant',id:'two',text:'Another progress update.'}]});assert.equal(v.utterances.length,1);assert.equal(v.el('reply').textContent,'Another progress update.');
  await v.hear('open https://example.com',{index:2});assert.equal(v.messages.filter(m=>m.type==='TURN').length,1);
});
test('recognition restarts during reading if the browser ends the recognition session',async t=>{
  const v=await voice(t);v.state({messages:[{role:'assistant',id:'one',text:'Still reading.'}]});
  v.recognizer.running=false;v.recognizer.onend();await new Promise(r=>setTimeout(r,550));assert.equal(v.recognizer.running,true);
});
test('loading state shows the actual phase and disappears on completion',async t=>{
  const v=await voice(t);v.state({busy:true,phase:'Researching current web sources…'});
  assert.equal(v.el('activity').classList.contains('hidden'),false);assert.match(v.el('activityDetail').textContent,/Researching/);assert.equal(v.classes.contains('thinking'),true);
  v.state({busy:false});assert.equal(v.el('activity').classList.contains('hidden'),true);assert.equal(v.classes.contains('thinking'),false);
});
test('manual stop reading leaves the microphone running; microphone off cancels both',async t=>{
  const v=await voice(t);v.state({messages:[{role:'assistant',id:'one',text:'A reply.'}]});v.el('stopReading').onclick();assert.equal(v.recognizer.running,true);
  v.el('stopVoice').onclick();assert.equal(v.recognizer.running,false);assert.equal(v.el('voiceStatus').textContent,'Microphone off');assert.equal(v.classes.contains('speaking'),false);
});
test('a new typed user request restores narration after interruption, but old-task updates do not',async t=>{
  const v=await voice(t);v.state({messages:[{role:'user',id:'u1',text:'First question'},{role:'assistant',id:'a1',text:'First answer'}]});
  await v.hear('Hey Chrome');v.state({messages:[{role:'user',id:'u1',text:'First question'},{role:'assistant',id:'a2',text:'Late old-task update'}]});assert.equal(v.utterances.length,1);
  v.state({messages:[{role:'user',id:'u2',text:'New typed question'},{role:'assistant',id:'a3',text:'New answer'}]});assert.equal(v.utterances.length,2);assert.equal(v.utterances.at(-1).text,'New answer');
});
