import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, unlinkSync, rmdirSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { join } from 'node:path';
import { hashToken, readMembers, writeMembers, resolveMember } from '../server/access.mjs';
import { createApp } from '../server/app.mjs';
const owner='owner-token-0123456789'.repeat(2),alice='alice-token-0123456789'.repeat(2),bob='bob-token-01234567890'.repeat(2);
test('member registry stores hashes, authenticates and revokes access',t=>{
  const dir=mkdtempSync(fileURLToPath(new URL('../../../work/member-test-',import.meta.url))),file=join(dir,'access.json');
  t.after(()=>{unlinkSync(file);rmdirSync(dir);});
  writeMembers(file,[{id:'alice',name:'Alice',tokenHash:hashToken(alice),revoked:false}]);
  assert.equal(readMembers(file)[0].token,undefined);assert.equal(resolveMember(file,alice).name,'Alice');assert.equal(resolveMember(file,bob),null);
  const members=readMembers(file);members[0].revoked=true;writeMembers(file,members);assert.equal(resolveMember(file,alice),null);
});
test('environment member registry survives missing local files and fails closed if invalid',()=>{
  const json=JSON.stringify([{id:'alice',name:'Alice',tokenHash:hashToken(alice),revoked:false}]);
  assert.equal(resolveMember('missing-registry-file',alice,json).id,'alice');
  assert.equal(resolveMember('missing-registry-file',alice,'bad-json'),null);
  assert.equal(resolveMember('missing-registry-file',alice,'[]'),null);
});
test('public Render health check reveals only liveness',async t=>{
  const app=createApp({token:owner,model:'test',demo:true});await new Promise(r=>app.listen(0,'127.0.0.1',r));t.after(()=>new Promise(r=>{app.close(r);app.closeAllConnections();}));
  const base=`http://127.0.0.1:${app.address().port}`;
  const r=await fetch(base+'/healthz');assert.equal(r.status,200);assert.deepEqual(await r.json(),{ok:true});assert.equal((await fetch(base+'/health')).status,401);
});
async function server(t,options={}){
  let revoked=false;
  const app=createApp({token:owner,model:'test',provider:async c=>({message:`History count ${c.history.length}`,intent:'general',flight:{},action:{type:'none'}}),resolvePrincipal:token=>!revoked&&token===alice?{id:'alice',name:'Alice'}:token===bob?{id:'bob',name:'Bob'}:null,...options});
  await new Promise(r=>app.listen(0,'127.0.0.1',r));t.after(()=>new Promise(r=>{app.close(r);app.closeAllConnections();}));
  const call=async(path,token=owner,data,method)=>{const response=await fetch(`http://127.0.0.1:${app.address().port}${path}`,{method:method||(data?'POST':'GET'),headers:{Authorization:`Bearer ${token}`,'Content-Type':'application/json'},...(data?{body:JSON.stringify(data)}:{})});return{status:response.status,body:await response.json()};};
  return {call,revoke:()=>revoked=true};
}
test('named users sharing one Gemini backend cannot read/reset each other’s sessions',async t=>{
  const s=await server(t),body={sessionId:'same-id',message:'Explain event loops'};
  assert.equal((await s.call('/api/turn',alice,body)).body.message,'History count 0');
  assert.equal((await s.call('/api/turn',bob,body)).body.message,'History count 0');
  await s.call('/api/reset',bob,{sessionId:'same-id'});
  assert.equal((await s.call('/api/turn',alice,body)).body.message,'History count 2');
  assert.equal((await s.call('/health',alice)).body.memberName,'Alice');s.revoke();assert.equal((await s.call('/health',alice)).status,401);
});
test('long-running jobs are private and can be cancelled by their owner',async t=>{
  let entered,ended;const started=new Promise(r=>entered=r),aborted=new Promise(r=>ended=r);
  const s=await server(t,{provider:async(c,signal)=>{entered();await new Promise(r=>signal.addEventListener('abort',()=>{ended();r();},{once:true}));return{message:'Abandoned',intent:'general',flight:{},action:{type:'none'}};}});
  const r=await s.call('/api/jobs',alice,{message:'Long task'});assert.equal(r.status,202);await started;
  const url='/api/jobs/'+r.body.jobId;assert.equal((await s.call(url,bob)).status,404);assert.equal((await s.call(url,alice)).body.status,'running');
  assert.equal((await s.call(url,bob,undefined,'DELETE')).status,404);assert.equal((await s.call(url,alice,undefined,'DELETE')).status,200);await aborted;
  assert.equal((await s.call(url,alice)).status,404);
});
test('server extension allowlist can restrict shared clients',async t=>{
  const app=createApp({token:owner,model:'test',demo:true,allowedExtensionIds:['a'.repeat(32)]});await new Promise(r=>app.listen(0,'127.0.0.1',r));t.after(()=>new Promise(r=>{app.close(r);app.closeAllConnections();}));
  const r=await fetch(`http://127.0.0.1:${app.address().port}/health`,{headers:{Authorization:`Bearer ${owner}`,Origin:'chrome-extension://'+'b'.repeat(32)}});assert.equal(r.status,403);
});
