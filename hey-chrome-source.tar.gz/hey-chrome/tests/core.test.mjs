import test from 'node:test';
import assert from 'node:assert/strict';
import {cleanFlight, missingFlight, flightSearchURL, validateAction, sanitizePage, safeURL} from '../server/core.mjs';
const complete={origin:'Goa',destination:'Delhi',departureDate:'2027-01-02',tripType:'one-way',passengers:2,departureTime:'morning',priority:'cheapest'};
test('flight collector preserves explicit fields, asks for essentials and does not assume passengers',()=>{
  const f=cleanFlight({}, {origin:'Goa',destination:'Delhi'},'2026-11-19');
  assert.equal(f.passengers,undefined);assert.equal(f.cabin,'economy');assert.ok(missingFlight(f).includes('departureDate'));
  const full=cleanFlight(f,complete,'2026-11-19');assert.deepEqual(missingFlight(full),[]);
  assert.equal(new URL(flightSearchURL(full)).hostname,'www.google.com');assert.match(decodeURIComponent(flightSearchURL(full)),/2 passengers/);
});
test('dates, passenger ranges and return trip order are validated',()=>{
  assert.ok(missingFlight(cleanFlight({}, {...complete,departureDate:'2025-01-01'},'2026-11-19')).includes('departureDate'));
  assert.equal(cleanFlight({}, {...complete,departureDate:'2027-02-30'},'2026-11-19').departureDate,undefined);
  assert.equal(cleanFlight({}, {...complete,passengers:0},'2026-11-19').passengers,undefined);
  const f=cleanFlight({}, {...complete,tripType:'round-trip',returnDate:'2027-01-01'},'2026-11-19');assert.ok(missingFlight(f).includes('returnDate'));
  assert.equal(cleanFlight(f,{tripType:'one-way'},'2026-11-19').returnDate,undefined);
});
test('model actions cannot escape allowed operations or target unseen/sensitive elements',()=>{
  const page={elements:[{id:'1',tag:'input',type:'text',label:'Destination'},{id:'2',tag:'input',type:'password',label:'Password',sensitive:true},{id:'3',tag:'button',label:'Pay now'}]};
  assert.equal(validateAction({type:'fill',targetId:'1',value:'Delhi'},page).value,'Delhi');
  for(const a of [{type:'evaluate',code:'1'},{type:'click',targetId:'missing'},{type:'fill',targetId:'2',value:'x'},{type:'click',targetId:'3'},{type:'fill',targetId:'1',value:{x:1}}])assert.throws(()=>validateAction(a,page));
});
test('navigation rejects non-HTTPS, credentials, local network literals and special schemes',()=>{
  for(const url of ['javascript:alert(1)','file:///etc/passwd','http://example.com','https://localhost','https://127.0.0.1','https://[::1]','https://192.168.1.1','https://user:pass@example.com','https://device.local','https://example.com:8443'])assert.throws(()=>safeURL(url));
  assert.equal(safeURL('https://example.com/a?q=b'),'https://example.com/a?q=b');
});
test('page payloads are bounded and form values are not passed to the model',()=>{
  const page=sanitizePage({text:'a'.repeat(20000),elements:[{id:'x',tag:'input',value:'SECRET',label:'Name'}]});
  assert.equal(page.text.length,18000);assert.equal(page.elements[0].value,undefined);
});
