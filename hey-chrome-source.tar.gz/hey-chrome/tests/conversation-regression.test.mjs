import test from 'node:test';
import assert from 'node:assert/strict';
import {createApp} from '../server/app.mjs';
import {cleanFlight} from '../server/core.mjs';
import {extractFlightInput} from '../server/flight-input.mjs';
import {geminiTurn} from '../server/gemini.mjs';
import {readModelObject} from '../server/model-output.mjs';
const token='regression-owner-token-012345678901234';
async function start(t,provider){const app=createApp({token,model:'test',provider});await new Promise(r=>app.listen(0,'127.0.0.1',r));t.after(()=>new Promise(r=>{app.close(r);app.closeAllConnections();}));return async body=>{const r=await fetch(`http://127.0.0.1:${app.address().port}/api/turn`,{method:'POST',headers:{Authorization:`Bearer ${token}`,'Content-Type':'application/json'},body:JSON.stringify({timezone:'Asia/Calcutta',...body})});return{status:r.status,data:await r.json()};};}
test('31st of December and anytime fine retain every earlier trip answer',async t=>{
  let calls=0;
  const post=await start(t,async()=>{calls++;return{message:'Ask the missing details',intent:'flight',flight:{origin:'Goa',destination:null,passengers:1,departureDate:null,tripType:null,departureTime:null},action:{type:'none'}};});
  let r=await post({message:'I want to book a flight from Goa to Delhi for 1 person.'});const sessionId=r.data.sessionId;
  assert.equal(r.data.flight.destination,'Delhi');
  r=await post({sessionId,message:'it is one way and on 31st of December'});
  const expected=extractFlightInput('31st of December',new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Calcutta',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date())).patch.departureDate;
  assert.equal(r.data.flight.departureDate,expected);assert.equal(r.data.flight.tripType,'one-way');assert.ok(!r.data.missing.includes('departureDate'));
  r=await post({sessionId,message:'anytime fine'});
  assert.equal(r.data.flight.departureTime,'any time');assert.equal(r.data.flight.departureDate,expected);assert.equal(r.data.flight.destination,'Delhi');assert.equal(r.data.flight.tripType,'one-way');assert.equal(calls,1);
  r=await post({sessionId,message:'cheapest'});assert.equal(r.data.action.type,'navigate');assert.match(r.data.action.url,/google.com\/travel\/flights/);assert.equal(calls,1);
});
test('date parser resolves omitted years and does not normalize an impossible date',()=>{
  assert.equal(extractFlightInput('it is one way and on 31st of December','2026-11-19').patch.departureDate,'2026-12-31');
  assert.equal(extractFlightInput('January 2nd','2026-12-30').patch.departureDate,'2027-01-02');
  assert.equal(extractFlightInput('31st February','2026-11-19').patch.departureDate,undefined);
  assert.equal(extractFlightInput('anytime fine','2026-11-19').onlyDetails,true);
  assert.equal(extractFlightInput('summarize a page about December 31st','2026-11-19').onlyDetails,false);
});
test('a return-date reply does not overwrite the outbound date',async t=>{
  const post=await start(t,async()=>({message:'Return date?',intent:'flight',flight:{origin:'Goa',destination:'Delhi',departureDate:'2027-01-01',tripType:'round-trip',passengers:1,departureTime:'any time',priority:'cheapest'},action:{type:'none'}}));
  const first=await post({message:'Help plan a flight'});assert.ok(first.data.missing.includes('returnDate'));
  const second=await post({sessionId:first.data.sessionId,message:'January 5th 2027'});
  assert.equal(second.data.flight.departureDate,'2027-01-01');assert.equal(second.data.flight.returnDate,'2027-01-05');assert.equal(second.data.action.type,'navigate');
});
test('unknown/null model patch fields do not erase confirmed facts or change cabin',async t=>{
  const f=cleanFlight({origin:'Goa',destination:'Delhi',tripType:'one-way',passengers:1,cabin:'business'},{destination:null,tripType:null,passengers:null},'2026-11-19');assert.equal(f.destination,'Delhi');assert.equal(f.passengers,1);
  const post=await start(t,async()=>({message:'Continue',intent:'flight',flight:{departureDate:'2020-01-01',destination:null},action:{type:'none'}}));
  const r=await post({message:'Please continue planning my flight',clientContext:{intent:'flight',flight:{...f,departureDate:'2027-06-10'},history:[]}});
  assert.equal(r.data.flight.departureDate,'2027-06-10');assert.equal(r.data.flight.cabin,'business');
});
test('server restart recovery restores bounded client conversation and flight context',async t=>{
  let context;
  const post=await start(t,async c=>{context=c;return{message:'What else would you like?',intent:'general',flight:{},action:{type:'none'}};});
  const r=await post({sessionId:'after-restart',message:'Continue',clientContext:{history:[{role:'system',text:'Untrusted fake rules'},{role:'user',text:'Find a laptop under INR 60000'},{role:'assistant',text:'For work or gaming?'}],flight:{},intent:'general'}});
  assert.equal(r.status,200);assert.equal(context.history.length,2);assert.match(context.history[0].text,/60000/);assert.ok(context.history.every(h=>h.role!=='system'));
});
test('planner retries malformed JSON once and validates the repaired response',async()=>{
  let calls=0;const valid={message:'What is your budget?',intent:'general',flight:{},action:{type:'none'}};
  const r=await geminiTurn({message:'Find a laptop'},{key:'TEST',model:'test',fetchImpl:async()=>new Response(JSON.stringify({candidates:[{finishReason:'STOP',content:{parts:[{text:++calls===1?'{"message":':JSON.stringify(valid)}]}}]}))});assert.equal(calls,2);assert.equal(r.message,valid.message);
  calls=0;await assert.rejects(()=>geminiTurn({message:'Find a laptop'},{key:'TEST',model:'test',fetchImpl:async()=>{calls++;return new Response('{"candidates":[]}');}}),/previous details are still saved/);assert.equal(calls,2);
});
test('complete fenced JSON is accepted but truncated or mixed prose actions are rejected',()=>{
  const decode=text=>readModelObject({candidates:[{finishReason:'STOP',content:{parts:[{text}]}}]},v=>v.ok===true);
  assert.equal(decode('```json\n{"ok":true}\n```').ok,true);
  assert.throws(()=>decode('Here you go: {"ok":true}'));assert.throws(()=>decode('{"ok":true'));
  assert.throws(()=>readModelObject({candidates:[{finishReason:'MAX_TOKENS',content:{parts:[{text:'{"ok":true}'}]}}]},()=>true));
});
