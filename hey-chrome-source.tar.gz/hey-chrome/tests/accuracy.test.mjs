import test from 'node:test';
import assert from 'node:assert/strict';
import { groundedSearch, reviewProposal } from '../server/accuracy.mjs';
import { createApp } from '../server/app.mjs';
import { fetchGemini } from '../server/gemini-http.mjs';
const token='accuracy-test-token-0123456789012345';
const result=(message,action={type:'none'})=>({message,intent:'general',flight:{},action});
async function server(t,config){const app=createApp({token,model:'test',...config});await new Promise(r=>app.listen(0,'127.0.0.1',r));t.after(()=>new Promise(r=>{app.close(r);app.closeAllConnections();}));return async body=>{const r=await fetch(`http://127.0.0.1:${app.address().port}/api/turn`,{method:'POST',headers:{Authorization:`Bearer ${token}`,'Content-Type':'application/json'},body:JSON.stringify(body)});return{status:r.status,body:await r.json()};};}
test('grounded research waits for explicit query approval and cannot be replayed',async t=>{
  let searches=0,reviews=0;
  const turn=await server(t,{provider:async c=>c.searchEvidence?result('The official docs support this answer.'):result('I can research this query.',{type:'web_search',query:'Node.js official documentation'}),search:async query=>{searches++;return{query,summary:'Node.js has official documentation.',citations:[{title:'Node.js',url:'https://nodejs.org/en/docs'}],grounded:true};},review:async c=>{reviews++;assert.ok(c.proposal);return{verdict:'allow',message:''};}});
  const first=await turn({message:'Research the Node.js docs'});assert.equal(first.status,200);assert.equal(first.body.action.type,'web_search');assert.equal(searches,0);
  const sessionId=first.body.sessionId,id=first.body.action.searchId;
  assert.equal((await turn({sessionId,message:'',observation:'approved',approvedSearchId:'wrong'})).status,400);assert.equal(searches,0);
  const second=await turn({sessionId,message:'',observation:'approved',approvedSearchId:id});assert.equal(second.status,200);assert.equal(searches,1);assert.equal(reviews,2);assert.match(second.body.message,/https:\/\/nodejs.org/);
  assert.equal((await turn({sessionId,message:'',observation:'approved',approvedSearchId:id})).status,400);assert.equal(searches,1);
});

test('browser research opens Google, uses visible snippets, and never calls a search provider',async t=>{
  let searches=0,seen;
  const turn=await server(t,{provider:async c=>{seen=c;return c.page?.research?result('The visible snippet links to https://nodejs.org/en/docs'):result('I will search',{type:'web_search',query:'Node docs'});},search:async()=>{searches++;throw Error('Must not call a search API');},review:async()=>({verdict:'allow',message:''})});
  const first=await turn({message:'Find Node docs',researchMode:'browser'});assert.equal(first.body.action.type,'navigate');assert.equal(new URL(first.body.action.url).searchParams.get('q'),'Node docs');
  const second=await turn({sessionId:first.body.sessionId,message:'',observation:'Opened the requested search page',researchMode:'browser',page:{url:first.body.action.url,text:'large duplicated body'.repeat(1000),research:{kind:'google-results',query:'Node docs',aiOverview:'Optional secondary summary',results:[{title:'Node',url:'https://nodejs.org/en/docs',snippet:'Official documentation'}]}}});
  assert.equal(searches,0);assert.equal(seen.searchUsed,true);assert.equal(second.body.sources.length,1);assert.ok(seen.page.text.length<200);assert.equal(seen.page.research.results[0].snippet,'Official documentation');
});

test('a Google verification challenge pauses without querying another provider',async t=>{
  let calls=0;const turn=await server(t,{provider:async()=>{calls++;throw Error('No model needed');}});
  const r=await turn({message:'Continue research',researchMode:'browser',page:{url:'https://www.google.com/search?q=docs',research:{kind:'google-results',blocked:'captcha',results:[]}}});
  assert.equal(r.body.action.type,'handoff');assert.equal(r.body.action.reason,'captcha');assert.equal(calls,0);
});
test('independent check can ask for missing details and withhold an action',async t=>{
  const turn=await server(t,{provider:async()=>result('Open an arbitrary store',{type:'navigate',url:'https://example.com'}),review:async()=>({verdict:'ask',message:'What is your budget and preferred screen size?'})});
  const r=await turn({message:'Find the right laptop'});assert.equal(r.body.action,null);assert.match(r.body.message,/budget/);assert.equal(r.body.review,'ask');
});
test('grounding quota failure proposes a checked browser search without inventing results',async t=>{
  const turn=await server(t,{provider:async()=>result('Research this query',{type:'web_search',query:'Node.js official documentation'}),search:async()=>{const e=new Error('Quota reached');e.status=429;throw e;},review:async()=>({verdict:'allow',message:''})});
  const first=await turn({message:'Find the official Node docs'});
  const next=await turn({sessionId:first.body.sessionId,message:'',observation:'Approved query',approvedSearchId:first.body.action.searchId});
  assert.equal(next.status,200);assert.equal(next.body.action.type,'navigate');assert.match(next.body.action.url,/google.com\/search/);assert.match(next.body.message,/open web search/);assert.doesNotMatch(next.body.message,/quota|approve|review the next/i);assert.equal(next.body.review,'allow');assert.deepEqual(next.body.sources,[]);
});
test('review failures never fall back to executing an unchecked action',async t=>{
  const turn=await server(t,{provider:async()=>result('Navigate',{type:'navigate',url:'https://example.com'}),review:async()=>{throw new Error('Independent check unavailable');}});
  const r=await turn({message:'Open example.com'});assert.equal(r.status,502);assert.equal(r.body.action,undefined);
});
test('research adapter keeps retrieved HTTPS sources and does not invent grounding',async()=>{
  let request;
  const options={key:'SEARCH_TEST_KEY',model:'test',fetchImpl:async(url,init)=>{request=JSON.parse(init.body);assert.equal(init.headers['x-goog-api-key'],'SEARCH_TEST_KEY');return new Response(JSON.stringify({candidates:[{content:{parts:[{text:'A sourced answer'}]},groundingMetadata:{groundingChunks:[{web:{uri:'https://nodejs.org',title:'Node'}},{web:{uri:'javascript:bad',title:'bad'}}]}}]}));}};
  const r=await groundedSearch('Node docs',options);assert.equal(r.grounded,true);assert.equal(r.citations.length,1);assert.deepEqual(request.tools,[{googleSearch:{}}]);
  const missing=await groundedSearch('Node docs',{...options,fetchImpl:async()=>new Response(JSON.stringify({candidates:[{content:{parts:[{text:'Unsupported assertion'}]}}]}))});assert.equal(missing.grounded,false);assert.ok(!missing.summary.includes('Unsupported assertion'));
});
test('review adapter accepts only the explicit allow/ask/block contract',async()=>{
  const fake=text=>async()=>new Response(JSON.stringify({candidates:[{content:{parts:[{text}]}}]}));
  assert.equal((await reviewProposal({},{key:'CHECK_TEST_KEY',model:'test',fetchImpl:fake('{"verdict":"allow","message":""}')})).verdict,'allow');
  await assert.rejects(()=>reviewProposal({},{key:'x',model:'test',fetchImpl:fake('{"verdict":"execute","message":""}')}),/previous details are still saved/);
});
test('transient generation failures get one retry and quota errors are not retried',async()=>{
  let attempts=0;
  const r=await fetchGemini({key:'test',model:'test',fetchImpl:async()=>new Response('{}',{status:++attempts===1?503:200})},{});
  assert.equal(r.status,200);assert.equal(attempts,2);
  attempts=0;const quota=await fetchGemini({key:'test',model:'test',fetchImpl:async()=>{attempts++;return new Response('{}',{status:429});}},{});
  assert.equal(quota.status,429);assert.equal(attempts,1);
});
