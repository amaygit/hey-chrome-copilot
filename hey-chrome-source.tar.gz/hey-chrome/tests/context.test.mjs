import test from 'node:test';
import assert from 'node:assert/strict';
import {compactHistory} from '../server/context.mjs';
test('compact context reduces repeated page payloads while retaining source URLs and user instructions',()=>{
  const history=[{role:'user',text:'Compare the two sources'},...Array.from({length:8},(_,i)=>({role:'untrusted-page-data',url:`https://example.org/${i}`,title:'Source',text:'Evidence '.repeat(700)}))];
  const compact=compactHistory(history);
  assert.equal(compact[0].text,'Compare the two sources');assert.equal(compact.at(-1).url,'https://example.org/7');
  assert.ok(JSON.stringify(compact).length<JSON.stringify(history).length*.25);
});
