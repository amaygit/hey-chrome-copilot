import test from 'node:test';
import assert from 'node:assert/strict';
import { createApp } from '../server/app.mjs';
test('disconnecting cancels the planner and does not commit an abandoned conversation',async t=>{
  const token='cancel-test-token-01234567890123456789';let count=0,entered,ended;
  const started=new Promise(r=>entered=r),aborted=new Promise(r=>ended=r);
  const app=createApp({token,model:'test',provider:async(c,signal)=>{
    count++;
    if(count===1){entered();await new Promise(resolve=>signal.addEventListener('abort',()=>{ended();resolve();},{once:true}));}
    else assert.equal(c.history.length,0);
    return {message:'Hello',intent:'general',flight:{},action:{type:'none'}};
  }});
  await new Promise(r=>app.listen(0,'127.0.0.1',r));t.after(()=>new Promise(r=>{app.close(r);app.closeAllConnections();}));
  const controller=new AbortController(),url=`http://127.0.0.1:${app.address().port}/api/turn`;
  const init={method:'POST',headers:{Authorization:`Bearer ${token}`,'Content-Type':'application/json'},body:JSON.stringify({sessionId:'cancel-me',message:'Hello'})};
  const first=fetch(url,{...init,signal:controller.signal}).catch(e=>e);await started;controller.abort();await aborted;await first;
  const second=await fetch(url,init);assert.equal(second.status,200);assert.equal(count,2);
});
