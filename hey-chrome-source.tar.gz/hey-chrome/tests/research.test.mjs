import test from 'node:test';
import assert from 'node:assert/strict';
import { researchRouter, grokSearch, tavilySearch } from '../server/research.mjs';
const sourced={grounded:true,citations:[{url:'https://example.org/',title:'Example'}],summary:'Checked source'};
test('keyless research sends only a public query and retains retrieved snippets with safe URLs',async()=>{
  const r=await tavilySearch('Node documentation',{fetchImpl:async(url,init)=>{
    assert.equal(url,'https://api.tavily.com/search');assert.equal(init.headers['X-Tavily-Access-Mode'],'keyless');assert.equal(init.headers.Authorization,undefined);
    assert.deepEqual(JSON.parse(init.body),{query:'Node documentation',max_results:5,search_depth:'basic',include_answer:false,include_raw_content:false});
    return Response.json({results:[{title:'Node',url:'https://nodejs.org/en/docs',content:'Retrieved official documentation snippet.'},{url:'javascript:bad',content:'Malicious result'},{url:'https://nodejs.org/en/docs',content:'Duplicate'},{url:'https://other.example/',content:''}]});
  }});
  assert.equal(r.grounded,true);assert.equal(r.citations.length,1);assert.match(r.summary,/Retrieved official/);assert.doesNotMatch(r.summary,/Malicious|Duplicate/);
});
test('empty keyless results cannot become a sourced answer and rate limits reach provider failover',async()=>{
  const empty=await tavilySearch('x',{fetchImpl:async()=>Response.json({results:[]})});assert.equal(empty.grounded,false);assert.deepEqual(empty.citations,[]);
  await assert.rejects(()=>tavilySearch('x',{fetchImpl:async()=>new Response('{}',{status:429})}),e=>e.status===429);
});
test('research fails over on quota and skips exhausted provider during cooldown',async()=>{
  let first=0,second=0,time=0;
  const search=researchRouter([{name:'a',search:async()=>{first++;throw Object.assign(Error('quota'),{status:429});}},{name:'b',search:async()=>{second++;return sourced;}}],{now:()=>time});
  assert.equal((await search('one')).grounded,true);await search('two');
  assert.equal(first,1);assert.equal(second,2);time=300001;await search('three');assert.equal(first,2);
});
test('all providers failing returns honest browser fallback without technical quota details',async()=>{
  const search=researchRouter([{name:'a',search:async()=>{throw Error('secret raw error');}},{name:'b',search:async()=>({grounded:false,citations:[]})}]);
  const r=await search('query');assert.equal(r.unavailable,true);assert.deepEqual(r.citations,[]);assert.doesNotMatch(r.summary,/quota|secret|found results/i);
});
test('cancellation never starts fallback provider',async()=>{
  const c=new AbortController();let fallback=false;
  const search=researchRouter([{name:'a',search:async()=>{c.abort();throw Error('stopped');}},{name:'b',search:async()=>{fallback=true;return sourced;}}]);
  await assert.rejects(()=>search('query',c.signal));assert.equal(fallback,false);
});
test('Grok uses web search and accepts only completed output with actual URL citations',async()=>{
  let payload;
  const response={status:'completed',output:[{type:'message',content:[{type:'output_text',text:'Verified answer',annotations:[{type:'url_citation',url:'https://example.org/',title:'Example'},{type:'url_citation',url:'javascript:bad'}]}]}]};
  const fetchImpl=async(url,init)=>{assert.equal(url,'https://api.x.ai/v1/responses');payload=JSON.parse(init.body);return Response.json(response);};
  const r=await grokSearch('query',{key:'test',fetchImpl});assert.equal(r.grounded,true);assert.equal(r.citations.length,1);assert.deepEqual(payload.tools,[{type:'web_search'}]);assert.equal(payload.store,false);
  response.output[0].content[0].annotations=[];
  const missing=await grokSearch('query',{key:'test',fetchImpl});assert.equal(missing.grounded,false);assert.doesNotMatch(missing.summary,/Verified answer/);
  response.status='incomplete';assert.equal((await grokSearch('query',{key:'test',fetchImpl})).grounded,false);
});
