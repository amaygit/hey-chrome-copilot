import {createServer} from 'node:http';
import {readFile} from 'node:fs/promises';
import {randomUUID} from 'node:crypto';
import {resolve,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {createApp} from '../server/app.mjs';
const here=dirname(fileURLToPath(import.meta.url)),root=resolve(here,'..');
const token=randomUUID()+randomUUID();
const backend=createApp({token,key:process.env.GEMINI_API_KEY,verifyKey:process.env.GEMINI_VERIFY_API_KEY,model:process.env.GEMINI_MODEL||'gemini-3.1-flash-lite',highAccuracy:true});
await new Promise(r=>backend.listen(0,'127.0.0.1',r));
const gateway=createServer(async(req,res)=>{
 try{
  const url=new URL(req.url,'http://127.0.0.1:8789');
  if(req.headers.origin&&!['http://127.0.0.1:8789','http://localhost:8789'].includes(req.headers.origin)){res.writeHead(403);res.end();return;}
  if(url.pathname.startsWith('/api/')||url.pathname==='/health'){
   if(req.headers.authorization!==`Bearer ${token}`){res.writeHead(401);res.end();return;}
   const chunks=[];for await(const c of req)chunks.push(c);
   const response=await fetch(`http://127.0.0.1:${backend.address().port}${req.url}`,{method:req.method,headers:{Authorization:`Bearer ${token}`,'Content-Type':'application/json'},...(['POST'].includes(req.method)?{body:Buffer.concat(chunks)}:{})});
   res.writeHead(response.status,{'Content-Type':'application/json'});res.end(await response.text());return;
  }
  if(url.pathname==='/connection.json'){res.writeHead(200,{'Content-Type':'application/json'});res.end(JSON.stringify({backend:'http://127.0.0.1:8789',token,share:true,autoRun:true}));return;}
  if(url.pathname==='/qa-core.mjs'){res.writeHead(200,{'Content-Type':'text/javascript'});res.end(await readFile(resolve(root,'server/core.mjs')));return;}
  const files={'/':'index.html','/qa.js':'qa.js','/fixture':'fixture.html','/fixture.js':'fixture.js'};
  let path=files[url.pathname]?resolve(here,files[url.pathname]):null;
  if(/^\/extension\/(background|content|search-snapshot)\.js$/.test(url.pathname))path=resolve(root,url.pathname.slice(1));
  if(!path){res.writeHead(404);res.end();return;}
  const data=await readFile(path);res.writeHead(200,{'Content-Type':path.endsWith('.html')?'text/html; charset=utf-8':'text/javascript; charset=utf-8','Cache-Control':'no-store'});res.end(data);
 }catch{res.writeHead(500);res.end('QA server request failed.');}
});
gateway.listen(8789,'127.0.0.1',()=>console.log('Private development QA lab at http://127.0.0.1:8789 — real DOM + actual Gemini; simulated Chrome tabs and booking. No credentials logged.'));
