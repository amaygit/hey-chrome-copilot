// UI-only lab: no real microphone, speech service, or AI requests.
const listeners=[];let speech,recognizer,spoken=0,cancelled=0,sent=0,lastTurn='',heardIndex=0;
let micLevel=.004;
window.AudioContext=class{async resume(){}createMediaStreamSource(){return{connect(){}};}createAnalyser(){return{fftSize:1024,getFloatTimeDomainData:a=>a.fill(micLevel)};}async close(){}};
const state={messages:[{id:'user-preview',role:'user',text:'Compare the available options for me.'}],flight:{},busy:true,phase:'Researching current web sources…',pending:null,handoff:null,target:{title:'Selected webpage'},mode:'preview',error:''};
const emit=()=>{for(const fn of listeners)fn({type:'STATE',state:structuredClone(state)});};
const settings={backend:'http://127.0.0.1:8789',token:'UI-PREVIEW-NOT-A-REAL-TOKEN',share:true,autoRun:true,browserResearch:true};
globalThis.chrome={storage:{local:{get:async()=>({}),set:async()=>{}}},runtime:{getURL:p=>location.origin+'/'+p,onMessage:{addListener:fn=>listeners.push(fn)},sendMessage:async req=>{if(req.type==='GET_STATE')return{state:structuredClone(state)};if(req.type==='GET_SETTINGS')return{settings};if(req.type==='TURN'){sent++;lastTurn=req.text;stats();}return{ok:true};}},permissions:{contains:async()=>true}};
class FakeRecognition{constructor(){recognizer=this;this.running=false;}start(){this.running=true;this.onstart?.();stats();}abort(){this.running=false;this.onend?.();stats();}}
window.SpeechRecognition=FakeRecognition;window.SpeechSynthesisUtterance=class{constructor(text){this.text=text;}};
Object.defineProperty(window,'speechSynthesis',{configurable:true,value:{speak:u=>{speech=u;spoken++;stats();},cancel:()=>{const old=speech;speech=null;cancelled++;old?.onend?.();stats();}}});
Object.defineProperty(navigator,'mediaDevices',{configurable:true,value:{getUserMedia:async()=>({getTracks:()=>[{stop(){}}]})}});
const bar=document.createElement('div');bar.id='previewToolbar';bar.style.cssText='position:fixed;top:0;left:0;right:0;z-index:10000;padding:9px;background:#23342a;color:#d5eccb;font:11px system-ui;display:flex;gap:6px;align-items:center;flex-wrap:wrap;border-bottom:1px solid #65825c';
const label=document.createElement('span');label.textContent='UI LAB · simulated audio';bar.append(label);
const button=(text,fn)=>{const b=document.createElement('button');b.textContent=text;b.style.cssText='font:11px system-ui;padding:5px 7px;background:#c5e8b1;color:#183521;border-radius:5px';b.onclick=fn;bar.append(b);};
button('Show loading',()=>{state.busy=true;state.phase='Checking the answer and next action…';emit();});
button('Read sample reply',()=>{state.busy=false;state.messages.push({id:crypto.randomUUID(),role:'assistant',text:'Here are the results for your request. I found three available options to compare. Say Hey Chrome whenever you want to interrupt this reply and ask another question.'});emit();});
async function hear(text,final=true){if(!recognizer)return;const results=[];results[heardIndex]=Object.assign([{transcript:text,confidence:.95}],{isFinal:final});await recognizer.onresult({resultIndex:heardIndex,results});if(final)heardIndex++;stats();}
button('Simulate Hey Chrome',async()=>{await hear('Hey Chrome',false);await hear('Hey Chrome');});
button('Simulate microphone speech',()=>{micLevel=.08;setTimeout(()=>micLevel=.004,1000);});
button('Simulate three speech fragments',async()=>{await hear('Hey Chrome five adults');await new Promise(r=>setTimeout(r,900));await hear('on the 25th');await new Promise(r=>setTimeout(r,900));await hear('of December');});
const info=document.createElement('span');info.id='previewStats';bar.append(info);
function stats(){if(info)info.textContent='Mic: '+(recognizer?.running?'listening':'off')+' · spoken: '+spoken+' · cancel: '+cancelled+' · sent: '+sent+(lastTurn?' · '+lastTurn:'');}
document.body.prepend(bar);document.body.style.paddingTop='78px';stats();
