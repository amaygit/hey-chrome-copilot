import {randomUUID,createHash} from 'node:crypto';
import {readFileSync,writeFileSync,mkdirSync,renameSync} from 'node:fs';
import {dirname} from 'node:path';
export function sentryTarget(dsn){
  if(!dsn)return null;const u=new URL(dsn);
  if(u.protocol!=='https:'||u.port||u.password||u.search||u.hash||!u.hostname.endsWith('.sentry.io')||!/^[a-f0-9]{16,64}$/i.test(u.username)||!/^\/\d+$/.test(u.pathname))throw Error('Use an HTTPS Sentry project DSN from sentry.io.');
  return{url:`https://${u.hostname}/api${u.pathname}/envelope/`,publicKey:u.username};
}
export function createTelemetry({file,limit=200,getSecrets=()=>[],getDSN=()=>'',fetchImpl=fetch,now=()=>Date.now()}={}){
  const started=now(),latencies=[],counts={requests:0,failed:0};let events=[];
  const clean=value=>{let s=String(value||'');for(const key of getSecrets().filter(v=>typeof v==='string'&&v.length>7).sort((a,b)=>b.length-a.length))s=s.split(key).join('[redacted]');return s.replace(/Bearer\s+\S+/gi,'Bearer [redacted]').replace(/(?:AIza|AQ\.|rnd_)[A-Za-z0-9_.-]{15,}/g,'[redacted]').replace(/https?:\/\/[^\s)]+/g,u=>{try{const x=new URL(u);return x.origin+x.pathname;}catch{return '[url]';}}).slice(0,1500);};
  const sanitize=e=>({id:String(e.id||randomUUID()),at:typeof e.at==='string'?e.at:new Date(now()).toISOString(),source:['backend','extension','admin'].includes(e.source)?e.source:'backend',level:e.level==='info'?'info':'error',operation:clean(e.operation).slice(0,100),status:Number.isInteger(e.status)?e.status:0,message:clean(e.message).slice(0,700),requestId:clean(e.requestId).slice(0,80),fingerprint:createHash('sha256').update(clean(e.operation)+'|'+e.status+'|'+clean(e.message).replace(/\d+/g,'#')).digest('hex').slice(0,12)});
  if(file)try{const data=JSON.parse(readFileSync(file,'utf8'));if(Array.isArray(data))events=data.slice(-limit).map(sanitize);}catch{}
  function persist(){if(file)try{mkdirSync(dirname(file),{recursive:true});writeFileSync(file+'.tmp',JSON.stringify(events),{mode:0o600});renameSync(file+'.tmp',file);}catch{}}
  async function forward(e){
    if(e.level!=='error')return;try{const target=sentryTarget(getDSN());if(!target)return;const id=e.id.replaceAll('-','');const envelope=[JSON.stringify({event_id:id,sent_at:new Date(now()).toISOString()}),JSON.stringify({type:'event'}),JSON.stringify({event_id:id,timestamp:Date.parse(e.at)/1000,platform:'node',level:'error',message:e.message,release:'hey-chrome@1.7.0',tags:{operation:e.operation,status:String(e.status),source:e.source},fingerprint:[e.fingerprint]})].join('\n');const r=await fetchImpl(target.url,{method:'POST',headers:{'content-type':'application/x-sentry-envelope','x-sentry-auth':`Sentry sentry_version=7,sentry_client=hey-chrome/1.7,sentry_key=${target.publicKey}`},body:envelope,signal:AbortSignal.timeout(4000)});await r.body?.cancel();}catch{}
  }
  return{
    capture(input){const e=sanitize(input);events.push(e);events=events.slice(-limit);persist();void forward(e);return e.id;},
    request(status,ms){counts.requests++;if(status>=400)counts.failed++;latencies.push(Math.max(0,ms));if(latencies.length>300)latencies.shift();},
    events:()=>events.slice().reverse(),
    summary(){const a=latencies.slice().sort((x,y)=>x-y);return{...counts,p95Ms:a.length?Math.round(a[Math.min(a.length-1,Math.ceil(a.length*.95)-1)]):0,uptimeSeconds:Math.floor((now()-started)/1000),storedEvents:events.length,limit,storage:file?'local-file':'memory',retention:'Recent events only; Render Free local storage is temporary. Connect Sentry for durable error history.'};},clean
  };
}
