// Deliberately small offline conversation demo. These are not live flights.
export function demoTurn(ctx) {
  const t = ctx.message.toLowerCase(); const f = {};
  if (/goa/.test(t)) f.origin = 'Goa (GOI or GOX)';
  if (/delhi/.test(t)) f.destination = 'Delhi (DEL)';
  if (/tomorrow/.test(t)) { const d = new Date(ctx.localDate + 'T12:00:00Z'); d.setUTCDate(d.getUTCDate()+1); f.departureDate = d.toISOString().slice(0,10); }
  const dates = t.match(/\d{4}-\d{2}-\d{2}/g); if (dates) { f.departureDate = dates[0]; if (dates[1]) f.returnDate = dates[1]; }
  if (/one[ -]?way/.test(t)) f.tripType = 'one-way';
  if (/round[ -]?trip|return trip/.test(t)) f.tripType = 'round-trip';
  const p = t.match(/\b([1-9])\s*(?:passengers?|people|adults?)/); if (p) f.passengers = +p[1];
  if (/two (passengers|people|adults)/.test(t)) f.passengers = 2;
  for (const time of ['morning','afternoon','evening','any time']) if (t.includes(time)) f.departureTime = time;
  for (const pref of ['cheapest','fastest','balanced']) if (t.includes(pref)) f.priority = pref;
  return { message: ctx.observation ? 'DEMO: The browser action finished. This offline demo collects trip details and opens a real search, but does not read or rank live fares. Switch DEMO_MODE=false and configure Gemini to analyze the page.' : 'DEMO: I can help plan a Goa to Delhi flight. Tell me the trip details.', intent:'flight', flight:f, action:{ type:'none' } };
}
