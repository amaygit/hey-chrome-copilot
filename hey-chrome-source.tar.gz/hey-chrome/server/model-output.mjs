export class ModelOutputError extends Error{
  constructor(reason='invalid'){super('I couldn’t read the AI response safely. Your previous details are still saved; please retry the last message.');this.name='ModelOutputError';this.code='MODEL_OUTPUT_INVALID';this.reason=reason;}
}
export function readModelObject(data,validate){
  const candidate=data?.candidates?.[0];
  if(candidate?.finishReason&&candidate.finishReason!=='STOP')throw new ModelOutputError(candidate.finishReason);
  const parts=candidate?.content?.parts;
  if(!Array.isArray(parts))throw new ModelOutputError(data?.promptFeedback?.blockReason||'empty');
  let text=parts.filter(p=>p&&!p.thought&&typeof p.text==='string').map(p=>p.text).join('').trim();
  if(text.startsWith('```')){const fenced=text.match(/^```(?:json)?\s*([\s\S]*?)\s*```$/i);if(!fenced)throw new ModelOutputError('incomplete-fence');text=fenced[1];}
  let value;try{value=JSON.parse(text);}catch{throw new ModelOutputError('json');}
  if(!value||Array.isArray(value)||typeof value!=='object'||!validate(value))throw new ModelOutputError('schema');
  return value;
}
