import { createHash, timingSafeEqual } from 'node:crypto';
import { existsSync, readFileSync, mkdirSync, writeFileSync, renameSync } from 'node:fs';
import { dirname } from 'node:path';
export const hashToken=token=>createHash('sha256').update(token).digest('hex');
export function readMembers(file) {
  if(!existsSync(file))return [];
  const data=JSON.parse(readFileSync(file,'utf8'));
  if(!Array.isArray(data))throw new Error('Invalid member registry.');
  return data;
}
export function writeMembers(file,members) {
  mkdirSync(dirname(file),{recursive:true});
  const tmp=file+'.tmp';writeFileSync(tmp,JSON.stringify(members,null,2)+'\n',{mode:0o600});renameSync(tmp,file);
}
export function resolveMember(file,token,environmentMembers) {
  if(typeof token!=='string'||token.length<32)return null;
  const hash=hashToken(token);
  let members;try{members=environmentMembers!==undefined?JSON.parse(environmentMembers):readMembers(file);if(!Array.isArray(members))return null;}catch{return null;}
  const member=members.find(m=>!m.revoked && /^[a-f0-9]{64}$/.test(m.tokenHash) && timingSafeEqual(Buffer.from(hash),Buffer.from(m.tokenHash)));
  return member?{id:member.id,name:member.name}:null;
}
