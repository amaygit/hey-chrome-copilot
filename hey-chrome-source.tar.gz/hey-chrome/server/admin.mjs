import {randomBytes,randomUUID,createHmac,timingSafeEqual} from 'node:crypto';
import {readFile,readdir} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {join} from 'node:path';
import {settingFields,validateSetting} from './runtime-settings.mjs';
import {hashToken} from './access.mjs';
import {zipFiles} from './zip.mjs';
import {DEFAULT_GROQ_MODEL} from './groq.mjs';
const assets=fileURLToPath(new URL('../admin/',import.meta.url)),extension=fileURLToPath(new URL('../extension/',import.meta.url));
const equal=(a,b)=>{const x=Buffer.from(a||''),y=Buffer.from(b||'');return x.length===y.length&&timingSafeEqual(x,y);};
const failure=(status,message)=>Object.assign(Error(message),{status});
export function createAdmin({config,telemetry,store,fetchImpl=fetch}){
  const attempts=new Map(),writes=new Map(),ttl=3600000;
  const sign=s=>createHmac('sha256',config.token).update('hey-chrome-admin-v1:'+s).digest('base64url');
  const origin=req=>config.adminOrigin||((req.headers.host||'').startsWith('127.0.0.1:')?'http://':'https://')+req.headers.host;
  const session=req=>{try{const raw=req.headers.cookie?.split(';').map(s=>s.trim()).find(s=>s.startsWith('hc_admin='))?.slice(9),[payload,sig]=raw?.split('.')||[];if(!payload||!equal(sign(payload),sig))return null;const s=JSON.parse(Buffer.from(payload,'base64url'));return s.role==='owner'&&s.exp>Date.now()&&s.exp<=Date.now()+ttl?s:null;}catch{return null;}};
  const csrf=s=>sign('csrf:'+s.nonce);
  async function body(req){if(!req.headers['content-type']?.startsWith('application/json'))throw failure(415,'Use application/json.');let text='';for await(const c of req){text+=c;if(Buffer.byteLength(text)>70000)throw failure(413,'Request too large.');}try{const b=JSON.parse(text);if(!b||typeof b!=='object'||Array.isArray(b))throw Error();return b;}catch{throw failure(400,'Invalid JSON.');}}
  async function probe(field,value){
    validateSetting(field,value);
    if(field==='GROQ_API_KEY'){
      if(!value)throw failure(400,'Enter or save a Groq API key first.');const model=store?.get('GROQ_MODEL')||config.groqModel||DEFAULT_GROQ_MODEL,started=Date.now();
      const r=await fetchImpl('https://api.groq.com/openai/v1/models',{headers:{Authorization:'Bearer '+value},signal:AbortSignal.timeout(15000)});
      if(!r.ok){await r.body?.cancel();throw failure(400,'Groq rejected the key check (HTTP '+r.status+'). Current provider was kept.');}
      const data=await r.json();if(!data.data?.some(m=>m.id===model&&m.active!==false))throw failure(400,'The selected Groq model is not available to this API key.');return{ok:true,provider:'groq',model,latencyMs:Date.now()-started};
    }
    if(!/^GEMINI_.*API_KEY$/.test(field)&&field!=='GEMINI_API_KEY')throw failure(400,'Online key testing is available for Gemini and Groq keys.');
    const modelKey=field==='GEMINI_VERIFY_API_KEY'?'GEMINI_VERIFY_MODEL':field==='GEMINI_SEARCH_API_KEY'?'GEMINI_SEARCH_MODEL':'GEMINI_MODEL',model=store?.get(modelKey)||config.model;
    const started=Date.now(),r=await fetchImpl('https://generativelanguage.googleapis.com/v1beta/models/'+encodeURIComponent(model),{headers:{'x-goog-api-key':value||config.key},signal:AbortSignal.timeout(15000)});await r.body?.cancel();if(!r.ok)throw failure(400,'Gemini rejected the key/model check (HTTP '+r.status+'). Current saved keys were kept.');return{ok:true,model,latencyMs:Date.now()-started};
  }
  const members=()=>config.getMembers?.()||[];
  const publicSettings=()=>settingFields.map(d=>({...d,configured:Boolean(store?.get(d.key)),...(d.type==='secret'||d.type==='dsn'?{}:{value:store?.get(d.key)|| (d.type==='days'?'30':d.type==='boolean'?'true':d.type==='provider'?'gemini':d.type==='provider-model'?DEFAULT_GROQ_MODEL:'')}),changedAt:store?.changedAt(d.key)||null}));
  return async(req,res)=>{
    const path=req.url?.split('?')[0];if(path!=='/admin'&&!path?.startsWith('/admin/')&&!path?.startsWith('/api/admin/'))return false;
    const headers={'cache-control':'no-store','x-content-type-options':'nosniff','referrer-policy':'no-referrer','x-frame-options':'DENY','content-security-policy':"default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self' data:; base-uri 'none'; frame-ancestors 'none'; form-action 'self'"};
    const send=(status,data,extra={})=>{res.writeHead(status,{...headers,'content-type':'application/json',...extra});res.end(JSON.stringify(data));};
    try{
      if(req.headers.origin&&req.headers.origin!==origin(req))throw failure(403,'Use this admin website from its own HTTPS address.');
      if(path==='/admin'||path==='/admin/'||path==='/admin/admin.js'||path==='/admin/admin.css'){
        if(req.method!=='GET')throw failure(405,'Use GET.');const name=path.endsWith('.js')?'admin.js':path.endsWith('.css')?'admin.css':'index.html';const data=await readFile(join(assets,name));res.writeHead(200,{...headers,'content-type':name.endsWith('.js')?'text/javascript; charset=utf-8':name.endsWith('.css')?'text/css; charset=utf-8':'text/html; charset=utf-8'});res.end(data);return true;
      }
      const secure=origin(req).startsWith('https:')?'; Secure':'';
      if(path==='/api/admin/login'&&req.method==='POST'){
        if(req.headers.origin!==origin(req))throw failure(403,'Open the admin website to sign in.');
        const ip=req.socket.remoteAddress||'local',a=attempts.get(ip);if(a&&Date.now()-a.at<900000&&a.count>=5)throw failure(429,'Too many sign-in attempts. Wait 15 minutes.');
        const b=await body(req);if(typeof b.code!=='string'||!equal(b.code,config.token)){const old=a&&Date.now()-a.at<900000?a:{at:Date.now(),count:0};old.count++;attempts.set(ip,old);throw failure(401,'Owner access code is incorrect. Tester codes cannot sign in here.');}
        attempts.delete(ip);const s={role:'owner',exp:Date.now()+ttl,nonce:randomBytes(24).toString('base64url')},p=Buffer.from(JSON.stringify(s)).toString('base64url');
        telemetry.capture({source:'admin',level:'info',operation:'admin.login',message:'Owner signed in.'});send(200,{ok:true,csrf:csrf(s),expiresAt:s.exp},{'set-cookie':`hc_admin=${p+'.'+sign(p)}; HttpOnly; SameSite=Strict; Path=/api/admin; Max-Age=3600${secure}`});return true;
      }
      const s=session(req);if(!s)throw failure(401,'Sign in with the owner access code.');
      if(req.method!=='GET'){
        if(req.method!=='POST')throw failure(405,'Use POST.');if(req.headers.origin!==origin(req)||!equal(req.headers['x-csrf-token'],csrf(s)))throw failure(403,'Security check failed. Reload the admin page.');
        const l=writes.get(s.nonce)||{at:Date.now(),count:0};if(Date.now()-l.at>60000){l.at=Date.now();l.count=0;}if(++l.count>20)throw failure(429,'Too many admin changes. Wait a minute.');writes.set(s.nonce,l);
      }
      if(path==='/api/admin/session'&&req.method==='GET'){send(200,{csrf:csrf(s),expiresAt:s.exp});return true;}
      if(path==='/api/admin/logout'&&req.method==='POST'){send(200,{ok:true},{'set-cookie':`hc_admin=; HttpOnly; SameSite=Strict; Path=/api/admin; Max-Age=0${secure}`});return true;}
      if(path==='/api/admin/status'&&req.method==='GET'){send(200,{version:'1.8.0',preview:Boolean(config.adminPreview),now:new Date().toISOString(),storage:store?.status()||{mode:'unconfigured',ready:false},settings:publicSettings(),metrics:telemetry.summary(),members:members().map(({id,name,createdAt,revoked})=>({id,name,createdAt,revoked:Boolean(revoked)})),sentryConfigured:Boolean(store?.get('SENTRY_DSN'))});return true;}
      if(path==='/api/admin/events'&&req.method==='GET'){send(200,{events:telemetry.events()});return true;}
      if(path==='/api/admin/test-error'&&req.method==='POST'){const id=telemetry.capture({source:'admin',operation:'admin.test',status:0,message:'Admin test event: error capture is working.'});send(200,{ok:true,eventId:id});return true;}
      if(path==='/api/admin/keys/test'&&req.method==='POST'){const b=await body(req),value=b.value||store?.get(b.field)||'';send(200,await probe(b.field,value));return true;}
      if(path==='/api/admin/settings'&&req.method==='POST'){
        const b=await body(req);if(!settingFields.some(f=>f.key===b.field))throw failure(400,'Unsupported setting.');validateSetting(b.field,b.value);
        if(!store?.status().ready)throw failure(503,'Connect Render in Hosting before changing persistent settings.');
        if((b.field==='GROQ_API_KEY'||b.field==='GEMINI_API_KEY'||/^GEMINI_.*API_KEY$/.test(b.field))&&b.value)await probe(b.field,b.value);
        if(b.field==='AI_PROVIDER'){if(b.value==='groq')await probe('GROQ_API_KEY',store.get('GROQ_API_KEY'));else await probe('GEMINI_API_KEY',store.get('GEMINI_API_KEY'));}
        if(b.field==='GROQ_API_KEY'&&!b.value&&store.get('AI_PROVIDER')==='groq')throw failure(400,'Select another provider before disabling the active Groq key.');
        const result=await store.save(b.field,b.value);telemetry.capture({source:'admin',level:'info',operation:'settings.update',message:'Updated '+b.field+'. Secret value omitted.'});send(200,result);return true;
      }
      if(path==='/api/admin/hosting'&&req.method==='POST'){
        if(!store)throw failure(503,'Runtime store unavailable.');const result=await store.connect(await body(req));telemetry.capture({source:'admin',level:'info',operation:'hosting.connect',message:'Connected persistent Render settings.'});send(200,result);return true;
      }
      if(path==='/api/admin/members'&&req.method==='POST'){
        if(!store?.status().ready)throw failure(503,'Connect Render in Hosting before creating members.');const b=await body(req),name=typeof b.name==='string'?b.name.trim():'';if(!name||name.length>80)throw failure(400,'Use a display name of 1 to 80 characters.');
        const list=members();if(list.length>=100)throw failure(400,'Member limit reached.');const token=randomBytes(32).toString('hex'),id=randomUUID(),createdAt=new Date().toISOString();
        const files=[];for(const file of await readdir(extension)){if(file==='connection.local.json'||file==='connection.json'||!/^[-a-z0-9.]+$/.test(file))continue;files.push({name:'Hey-Chrome/extension/'+file,data:await readFile(join(extension,file))});}
        files.push({name:'Hey-Chrome/extension/connection.local.json',data:JSON.stringify({backend:origin(req),token,assistantName:config.assistantName||'Hey Chrome',memberName:name})});
        files.push({name:'Hey-Chrome/INSTALL.txt',data:'Extract this ZIP and keep the extracted folder. Open chrome://extensions, enable Developer mode, click Load unpacked, and choose the extension folder. Open Hey Chrome, Settings, Save connection and allow the server once. To read/control pages, allow browsing access in Settings. For voice, open Voice mode, Start listening and allow the microphone. This personal member code uses the owner’s shared API quota. Do not post publicly. Login, CAPTCHA and payment stay manual.'});
        const zip=zipFiles(files);await store.save('ACCESS_MEMBERS_JSON',JSON.stringify([...list,{id,name,createdAt,tokenHash:hashToken(token),revoked:false}]));telemetry.capture({source:'admin',level:'info',operation:'member.create',message:'Created member '+id+'. Access code omitted.'});
        res.writeHead(200,{...headers,'content-type':'application/zip','content-disposition':'attachment; filename="Hey-Chrome-'+name.replace(/[^a-zA-Z0-9_-]/g,'-').slice(0,40)+'.zip"'});res.end(zip);return true;
      }
      if(path==='/api/admin/members/revoke'&&req.method==='POST'){
        const b=await body(req),list=members(),m=list.find(m=>m.id===b.id);if(!m)throw failure(404,'Member not found.');m.revoked=true;const result=await store.save('ACCESS_MEMBERS_JSON',JSON.stringify(list));telemetry.capture({source:'admin',level:'info',operation:'member.revoke',message:'Revoked member '+m.id+'.'});send(200,result);return true;
      }
      throw failure(404,'Admin route not found.');
    }catch(e){const status=e.status||400;res.hcDiagnosticRecorded=true;if(!(path==='/api/admin/session'&&status===401))telemetry.capture({source:'admin',operation:path,status,message:e.message});send(status,{error:telemetry.clean(e.message)});return true;}
  };
}
