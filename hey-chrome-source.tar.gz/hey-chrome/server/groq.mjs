import {PLANNER_INSTRUCTION,schema,validTurn} from './gemini.mjs';
import {REVIEW_INSTRUCTION} from './accuracy.mjs';
import {ModelOutputError,readModelObject} from './model-output.mjs';
export const DEFAULT_GROQ_MODEL='openai/gpt-oss-120b';
const jsonSchema=s=>{if(Array.isArray(s))return s.map(jsonSchema);if(!s||typeof s!=='object')return s;return Object.fromEntries(Object.entries(s).map(([k,v])=>[k,k==='type'&&typeof v==='string'?v.toLowerCase():jsonSchema(v)]));};
export async function groqJSON(context,{key,model=DEFAULT_GROQ_MODEL,signal,fetchImpl=fetch,timeoutMs=25000,retryDelayMs=500},system,validate,outputSchema){
  if(!key)throw Object.assign(Error('Add a Groq API key in admin before selecting Groq.'),{status:503});
  for(let attempt=0;attempt<2;attempt++){
    signal?.throwIfAborted();let r;
    try{r=await fetchImpl('https://api.groq.com/openai/v1/chat/completions',{method:'POST',headers:{Authorization:'Bearer '+key,'content-type':'application/json'},signal:signal?AbortSignal.any([signal,AbortSignal.timeout(timeoutMs)]):AbortSignal.timeout(timeoutMs),body:JSON.stringify({model,temperature:0.1,max_completion_tokens:4096,...(model.startsWith('openai/gpt-oss-')?{reasoning_effort:'medium'}:{}),response_format:{type:'json_object'},messages:[{role:'system',content:system+'\nReturn one complete JSON object. Match this output schema (omit unknown flight patch fields): '+JSON.stringify(outputSchema)+(attempt?'\nYour previous response failed. Produce complete valid JSON matching the schema.':'')},{role:'user',content:JSON.stringify(context)}]})});}
    catch(e){if(signal?.aborted||attempt||!['TimeoutError','TypeError'].includes(e.name))throw e;await new Promise(r=>setTimeout(r,retryDelayMs));signal?.throwIfAborted();continue;}
    if(!r.ok){const status=r.status;await r.body?.cancel();if([500,502,503,504].includes(status)&&!attempt){await new Promise(r=>setTimeout(r,retryDelayMs));signal?.throwIfAborted();continue;}throw Object.assign(Error(status===429?'Groq rate or free-tier limit reached. Wait and retry; no browser action was run.':'Groq returned HTTP '+status+'. Check its API key and selected model.'),{status:status===429?429:502});}
    const data=await r.json(),choice=data?.choices?.[0];
    try{if(choice?.finish_reason!=='stop'||choice?.message?.tool_calls?.length)throw new ModelOutputError(choice?.finish_reason||'empty');return readModelObject({candidates:[{finishReason:'STOP',content:{parts:[{text:choice.message.content}]}}]},validate);}
    catch(e){if(!(e instanceof ModelOutputError)||attempt)throw e;}
  }
}
export const groqTurn=(context,options)=>groqJSON(context,options,PLANNER_INSTRUCTION,validTurn,jsonSchema(schema));
export const groqReview=(context,options)=>groqJSON(context,options,REVIEW_INSTRUCTION,r=>['allow','ask','block'].includes(r.verdict)&&typeof r.message==='string'&&r.message.length<=2000,{type:'object',required:['verdict','message'],properties:{verdict:{type:'string',enum:['allow','ask','block']},message:{type:'string'}}});
