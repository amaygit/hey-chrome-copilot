import {readFileSync,writeFileSync,mkdirSync,renameSync} from 'node:fs';
import {dirname} from 'node:path';
import {sentryTarget} from './telemetry.mjs';
export const settingFields=[
 ['GEMINI_API_KEY','Gemini planning key','secret'],['GEMINI_VERIFY_API_KEY','Gemini verification key','secret'],['GEMINI_SEARCH_API_KEY','Gemini search key','secret'],
 ['GEMINI_MODEL','Planning model','model'],['GEMINI_VERIFY_MODEL','Verification model','model'],['GEMINI_SEARCH_MODEL','Search model','model'],
 ['HIGH_ACCURACY','Independent answer checks','boolean'],['XAI_API_KEY','Optional Grok key','secret'],['TAVILY_API_KEY','Optional Tavily key','secret'],['SENTRY_DSN','Optional Sentry project DSN','dsn'],['KEY_ROTATION_DAYS','Key rotation reminder interval (days)','days']
].map(([key,label,type])=>({key,label,type}));
const allowed=new Set([...settingFields.map(f=>f.key),'ACCESS_MEMBERS_JSON']);
export function validateSetting(field,value){
  if(!allowed.has(field)||typeof value!=='string'||value.length>60000)throw Error('Unsupported setting.');
  if(field==='ACCESS_MEMBERS_JSON'){const a=JSON.parse(value);if(!Array.isArray(a)||a.length>100||a.some(m=>!m||typeof m.id!=='string'||typeof m.name!=='string'||m.name.length>80||!/^[a-f0-9]{64}$/.test(m.tokenHash)))throw Error('Invalid member registry.');return;}
  const def=settingFields.find(f=>f.key===field);
  if(def.type==='secret'&&(!/^[\x21-\x7e]{16,512}$/.test(value)&&!(value===''&&field!=='GEMINI_API_KEY')))throw Error('Use a valid API key without spaces.');
  if(def.type==='model'&&!/^[a-zA-Z0-9][a-zA-Z0-9._-]{1,100}$/.test(value))throw Error('Use a valid Gemini model ID.');
  if(def.type==='boolean'&&!['true','false'].includes(value))throw Error('Choose true or false.');
  if(def.type==='days'&&(!/^\d{1,3}$/.test(value)||Number(value)<1||Number(value)>365))throw Error('Choose 1 to 365 days.');
  if(def.type==='dsn')sentryTarget(value);
}
function readSnapshot(env,file,hosted){try{const s=JSON.parse(hosted?env.HEY_CHROME_SETTINGS_JSON||'{}':readFileSync(file,'utf8'));const values={};for(const [k,v] of Object.entries(s.values||{})){validateSetting(k,v);values[k]=v;}return{values,changedAt:s.changedAt&&typeof s.changedAt==='object'?s.changedAt:{}};}catch{return{values:{},changedAt:{}};}}
export function loadRuntimeSettings(env,file){const s=readSnapshot(env,file,Boolean(env.RENDER));Object.assign(env,s.values);return s;}
export function createRuntimeStore({env=process.env,file,fetchImpl=fetch,now=()=>new Date().toISOString()}={}){
  const hosted=Boolean(env.RENDER),listeners=[];let snapshot=readSnapshot(env,file,hosted),locked=false;Object.assign(env,snapshot.values);
  const service=()=>env.RENDER_ADMIN_SERVICE_ID||env.RENDER_SERVICE_ID||'';
  const status=()=>({mode:hosted?'render':'local',ready:!hosted||Boolean(env.RENDER_ADMIN_API_KEY&&/^srv-[a-z0-9]{8,64}$/.test(service())),serviceId:service(),durable:hosted?Boolean(env.RENDER_ADMIN_API_KEY):true});
  async function renderCall(path,method,body,key=env.RENDER_ADMIN_API_KEY){const r=await fetchImpl('https://api.render.com/v1'+path,{method,headers:{Authorization:'Bearer '+key,'content-type':'application/json',accept:'application/json'},...(body?{body:JSON.stringify(body)}:{}),signal:AbortSignal.timeout(20000)});if(!r.ok){await r.body?.cancel();throw Object.assign(Error('Render returned HTTP '+r.status+'. Check the admin integration key and its environment/deploy permissions.'),{status:502});}let data={};try{data=await r.json();}catch{}return data;}
  async function deploy(){try{const d=await renderCall(`/services/${service()}/deploys`,'POST',{clearCache:'do_not_clear'});return{restartRequested:true,deployId:typeof d.id==='string'?d.id:null};}catch{return{restartRequested:false,warning:'Saved persistently and applied to this process. Render did not accept a deploy request; a future deploy will load the saved settings.'};}}
  return{
    status,get:key=>env[key]||'',changedAt:key=>snapshot.changedAt[key]||null,subscribe:fn=>listeners.push(fn),
    async save(field,value){validateSetting(field,value);if(!status().ready)throw Object.assign(Error('Connect Render in Hosting before changing persistent settings.'),{status:503});if(locked)throw Object.assign(Error('Another settings update is running.'),{status:409});locked=true;
      try{const next={values:{...snapshot.values,[field]:value},changedAt:{...snapshot.changedAt,[field]:now()}};
        if(hosted)await renderCall(`/services/${service()}/env-vars/HEY_CHROME_SETTINGS_JSON`,'PUT',{value:JSON.stringify(next)});
        else{mkdirSync(dirname(file),{recursive:true});writeFileSync(file+'.tmp',JSON.stringify(next),{mode:0o600});renameSync(file+'.tmp',file);}
        snapshot=next;if(hosted)env.HEY_CHROME_SETTINGS_JSON=JSON.stringify(next);env[field]=value;for(const fn of listeners)fn(field,value);return{saved:true,changedAt:next.changedAt[field],...(hosted?await deploy():{restartRequested:false})};
      }finally{locked=false;}
    },
    async connect({apiKey,serviceId}){
      if(locked)throw Object.assign(Error('Another settings update is running.'),{status:409});
      if(typeof apiKey!=='string'||!/^[\x21-\x7e]{16,512}$/.test(apiKey)||typeof serviceId!=='string'||!/^srv-[a-z0-9]{8,64}$/.test(serviceId))throw Error('Enter your Render API key and service ID.');
      if(env.RENDER_SERVICE_ID&&serviceId!==env.RENDER_SERVICE_ID)throw Error('Connect only this backend’s Render service.');
      locked=true;try{await renderCall(`/services/${serviceId}`,'GET',null,apiKey);
      await renderCall(`/services/${serviceId}/env-vars/RENDER_ADMIN_API_KEY`,'PUT',{value:apiKey},apiKey);
      await renderCall(`/services/${serviceId}/env-vars/RENDER_ADMIN_SERVICE_ID`,'PUT',{value:serviceId},apiKey);
      env.RENDER_ADMIN_API_KEY=apiKey;env.RENDER_ADMIN_SERVICE_ID=serviceId;return{connected:true,...await deploy()};}finally{locked=false;}
    }
  };
}
