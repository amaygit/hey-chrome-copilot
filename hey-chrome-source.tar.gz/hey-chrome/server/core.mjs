export const flightKeys = ['origin','destination','departureDate','returnDate','tripType','passengers','departureTime','priority','cabin'];
export function cleanFlight(previous = {}, patch = {}, today = new Date().toISOString().slice(0,10)) {
  const next = { ...previous };
  for (const k of flightKeys) {
    // Model nulls mean "not supplied in this turn", never erase a user's prior answer.
    if (patch[k] !== null && patch[k] !== undefined) next[k] = patch[k];
  }
  for (const k of ['origin','destination','departureTime']) if (next[k] !== undefined && (typeof next[k] !== 'string' || !next[k].trim() || next[k].length > 120)) delete next[k];
  for (const k of ['departureDate','returnDate']) if (next[k] && (!/^\d{4}-\d{2}-\d{2}$/.test(next[k]) || !Number.isFinite(Date.parse(next[k])) || new Date(next[k]).toISOString().slice(0,10) !== next[k] || next[k] < today)) delete next[k];
  if (!Number.isInteger(next.passengers) || next.passengers < 1 || next.passengers > 9) delete next.passengers;
  if (!['one-way','round-trip'].includes(next.tripType)) delete next.tripType;
  if (!['cheapest','fastest','balanced'].includes(next.priority)) delete next.priority;
  if (!['economy','premium economy','business','first'].includes(next.cabin)) next.cabin = 'economy';
  if (next.tripType === 'one-way') delete next.returnDate;
  if (next.returnDate && next.returnDate < next.departureDate) delete next.returnDate;
  if (next.origin?.toLowerCase() === next.destination?.toLowerCase()) delete next.destination;
  return next;
}
const questions = {
  origin: 'Where are you flying from?', destination: 'Where would you like to fly?',
  departureDate: 'What date would you like to depart?', tripType: 'Is this one-way or a round trip?',
  returnDate: 'What is your return date?', passengers: 'How many passengers are travelling? Include adults, children, and infants if relevant.',
  departureTime: 'What departure time do you prefer, or is any time fine?',
  priority: 'Should I prioritize the cheapest fare, shortest journey, or a balance of both?'
};
export function missingFlight(f) {
  return ['origin','destination','departureDate','tripType', ...(f.tripType === 'round-trip' ? ['returnDate'] : []),'passengers','departureTime','priority'].filter(k => !f[k]);
}
export function flightQuestion(f) { return missingFlight(f).slice(0,2).map(k => questions[k]).join(' '); }
export function flightSearchURL(f) {
  const q = `${f.tripType} flights from ${f.origin} to ${f.destination} on ${f.departureDate}${f.returnDate ? ` returning ${f.returnDate}` : ''}, ${f.passengers} passengers, ${f.cabin}, departure ${f.departureTime}, ${f.priority}`;
  return `https://www.google.com/travel/flights?q=${encodeURIComponent(q)}`;
}
export function safeURL(input) {
  let u; try { u = new URL(input); } catch { throw new Error('Invalid navigation URL.'); }
  if (u.protocol !== 'https:' || u.username || u.password || u.port || u.hostname === 'localhost' || u.hostname.endsWith('.local') || u.hostname.endsWith('.localhost') || !u.hostname.includes('.') || /^[\d.]+$/.test(u.hostname) || u.hostname.includes(':')) throw new Error('Only public HTTPS websites can be opened.');
  return u.href;
}
export function validateAction(a, page) {
  if (!a || a.type === 'none') return null;
  if(a.type==='handoff'){if(!['login','captcha','payment','manual'].includes(a.reason))throw new Error('Invalid handoff reason.');return {type:'handoff',reason:a.reason};}
  if (!['navigate','click','fill','scroll','back'].includes(a.type)) throw new Error('Unsupported browser action.');
  const out = { type: a.type };
  if (a.type === 'navigate') out.url = safeURL(a.url);
  if (['click','fill'].includes(a.type)) {
    const el = page?.elements?.find(e => e.id === a.targetId);
    if (!el) throw new Error('The requested element is no longer in the page snapshot.');
    if (el.sensitive || /password|credit.?card|card.?number|cvv|cvc|otp|one.?time|passport|social.?security|payment|pay now|confirm booking|place order|purchase|buy now|delete|remove account|send|publish|submit order|complete booking|confirm reservation|log.?in|sign.?in|captcha/i.test(`${el.label} ${el.type}`)) throw new Error('Complete payment, sensitive information, and final submissions manually.');
    out.targetId = a.targetId; out.label = String(el.label || el.tag).slice(0,180);
    if (a.type === 'fill') {
      if (!['input','textarea','select'].includes(el.tag)) throw new Error('This element is not an editable form control.');
      if (typeof a.value !== 'string' || a.value.length > 500) throw new Error('Invalid field value.');
      out.value = a.value;
    }
  }
  if (a.type === 'scroll') out.direction = a.direction === 'up' ? 'up' : 'down';
  return out;
}
export function sanitizePage(raw) {
  if (!raw || typeof raw !== 'object') return null;
  return { url: String(raw.url || '').slice(0,2000), title: String(raw.title || '').slice(0,300), snapshotId: String(raw.snapshotId || '').slice(0,80),
    text: String(raw.text || '').slice(0,18000),
    elements: Array.isArray(raw.elements) ? raw.elements.slice(0,120).map(e => ({ id: String(e.id).slice(0,80), tag: String(e.tag).slice(0,20), type: String(e.type || '').slice(0,40), label: String(e.label || '').slice(0,180), sensitive: Boolean(e.sensitive) })) : [] };
}
