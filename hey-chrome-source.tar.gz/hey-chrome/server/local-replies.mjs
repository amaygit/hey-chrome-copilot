export function localGreeting(message){
  const text=String(message).trim();if(!/^(?:(?:hello|hi|hey)(?:[ ,]+(?:chrome|there))?|namaste|नमस्ते|नमस्कार|हैलो|हेलो|हाय)[.!?।\s]*$/i.test(text))return null;
  return /[\u0900-\u097f]/.test(text)?'नमस्ते! मैं आपके ब्राउज़र में क्या करने में मदद करूँ?':'Hello! What would you like me to do in your browser?';
}
