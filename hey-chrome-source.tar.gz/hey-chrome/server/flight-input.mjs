import { cleanFlight } from './core.mjs';
// Extract only explicit user text. Never run this over page text or AI output.
const months={january:1,jan:1,february:2,feb:2,march:3,mar:3,april:4,apr:4,may:5,june:6,jun:6,july:7,jul:7,august:8,aug:8,september:9,sep:9,sept:9,october:10,oct:10,november:11,nov:11,december:12,dec:12};
const monthPattern=Object.keys(months).join('|');
function calendarDate(year,month,day){const d=new Date(Date.UTC(year,month-1,day));return d.getUTCFullYear()===year&&d.getUTCMonth()===month-1&&d.getUTCDate()===day?d.toISOString().slice(0,10):null;}
export function extractFlightInput(message,today,dateField='departureDate'){
  const original=String(message||'');let rest=original.toLowerCase();const patch={};
  const consume=(pattern,apply)=>{rest=rest.replace(pattern,(...args)=>{apply?.(...args);return ' ';});};
  const route=/\bfrom\s+([a-z][a-z .()'-]{0,60}?)\s+to\s+([a-z][a-z .()'-]{0,60}?)(?=\s+(?:for|on|with|at|departing|leaving)\b|[,.!?]|$)/i;
  const routeMatch=original.match(route);
  if(!/\b(?:destination|arrival|origin)\b.*\bfrom\b/i.test(original))consume(route,(_,origin,destination)=>{patch.origin=(routeMatch?.[1]||origin).trim();patch.destination=(routeMatch?.[2]||destination).trim();});
  consume(/\bone[\s-]?way\b/g,()=>patch.tripType='one-way');
  consume(/\bround[\s-]?trip\b|\breturn trip\b/g,()=>patch.tripType='round-trip');
  consume(/\b(\d{4}-\d{2}-\d{2})\b/,(_,date)=>{patch.departureDate=date;});
  const named=new RegExp(`\\b(\\d{1,2})(?:st|nd|rd|th)?\\s+(?:of\\s+)?(${monthPattern})(?:\\s+(\\d{4}))?\\b`,'i');
  const monthFirst=new RegExp(`\\b(${monthPattern})\\s+(\\d{1,2})(?:st|nd|rd|th)?(?:,?\\s+(\\d{4}))?\\b`,'i');
  const setDate=(day,month,year)=>{
    const y=year?Number(year):Number(today.slice(0,4));let date=calendarDate(y,months[month.toLowerCase()],Number(day));
    if(date&&!year&&date<today)date=calendarDate(y+1,months[month.toLowerCase()],Number(day));
    if(date)patch.departureDate=date;
  };
  if(!patch.departureDate){if(named.test(rest))consume(named,(_,day,month,year)=>setDate(day,month,year));else consume(monthFirst,(_,month,day,year)=>setDate(day,month,year));}
  if(!patch.departureDate)consume(/\b(day after tomorrow|tomorrow|today)\b/,(_,relative)=>{const d=new Date(today+'T12:00:00Z');d.setUTCDate(d.getUTCDate()+({'day after tomorrow':2,tomorrow:1,today:0}[relative]));patch.departureDate=d.toISOString().slice(0,10);});
  consume(/\b(?:any\s*time|anytime|flexible)(?:\s+(?:is\s+)?fine)?\b/g,()=>patch.departureTime='any time');
  consume(/\b(morning|afternoon|evening|night)\b/,(_,time)=>patch.departureTime=time);
  consume(/\b(cheapest|lowest price|lowest fare|fastest|shortest journey|balanced|balance of both)\b/,(_,value)=>patch.priority=/cheapest|lowest/.test(value)?'cheapest':/fastest|shortest/.test(value)?'fastest':'balanced');
  const counts={one:1,two:2,three:3,four:4,five:5,six:6,seven:7,eight:8,nine:9};
  if(!/\bchildren|child|infants?|bab(?:y|ies)\b/.test(rest))consume(/\b([1-9]|one|two|three|four|five|six|seven|eight|nine)\s*(?:passengers?|people|persons?|adults?)\b/,(_,n)=>patch.passengers=counts[n]||Number(n));
  // A command with other meaningful words still goes through the general planner.
  const remainder=rest.replace(/\b(?:it|is|its|it’s|and|on|at|for|the|a|an|i|we|would|like|want|prefer|please|fine|okay|ok|sure|yes|make|that|change|to|departure|depart|date|time|in|of|be|just)\b/g,' ').replace(/[^a-z0-9]/g,'').trim();
  const onlyDetails=Object.keys(patch).length>0&&!remainder;
  const returnDate=/\b(?:return(?:ing)?(?!\s+trip)|back on)\b/i.test(original)||dateField==='returnDate'&&!/\b(?:departure|departing|outbound|leaving)\b/i.test(original);
  if(patch.departureDate&&returnDate){patch.returnDate=patch.departureDate;delete patch.departureDate;}
  return{patch,onlyDetails};
}
export function groundedFlightPatch(previous,modelPatch,explicit,message,today){
  const valid=cleanFlight({},modelPatch,today),result={};
  const words=String(message).toLowerCase().replace(/[^\p{L}\p{N}]+/gu,' ').trim();
  const mentions=value=>{const city=String(value).replace(/\([^)]*\)/g,'').toLowerCase().replace(/[^\p{L}\p{N}]+/gu,' ').trim();return city.length>1&&(' '+words+' ').includes(' '+city+' ');};
  for(const key of Object.keys(modelPatch||{})){
    const value=valid[key];if(modelPatch[key]==null||value===undefined)continue;
    if(previous[key]===value||explicit[key]!==undefined){result[key]=value;continue;}
    if(['origin','destination','cabin'].includes(key)&&mentions(value))result[key]=value;
    if(key==='passengers'&&value===1&&/\b(?:solo|just me|only me|by myself)\b/i.test(message))result[key]=value;
    if(['departureDate','returnDate'].includes(key)&&/\b(?:next\s+(?:monday|tuesday|wednesday|thursday|friday|saturday|sunday|week)|in\s+\d+\s+days?)\b/i.test(message))result[key]=value;
    if(key==='departureTime'&&/\b\d{1,2}(?::\d{2})?\s*(?:am|pm)\b/i.test(message))result[key]=value;
    // Trip type, count, time and ranking have no implicit defaults. Ask rather than guess.
  }
  return result;
}
