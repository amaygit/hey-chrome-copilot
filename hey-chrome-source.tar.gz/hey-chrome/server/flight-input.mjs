import { cleanFlight } from './core.mjs';
// Only explicit USER text belongs here, never page text or AI output.
const months={january:1,jan:1,february:2,feb:2,march:3,mar:3,april:4,apr:4,may:5,june:6,jun:6,july:7,jul:7,august:8,aug:8,september:9,sep:9,sept:9,october:10,oct:10,november:11,nov:11,december:12,dec:12};
const monthPattern=Object.keys(months).join('|');
function calendarDate(year,month,day){const d=new Date(Date.UTC(year,month-1,day));return d.getUTCFullYear()===year&&d.getUTCMonth()===month-1&&d.getUTCDate()===day?d.toISOString().slice(0,10):null;}
export function cleanDateHints(input){
  const out={};for(const field of ['departureDate','returnDate']){
    const h=input?.[field];if(!h||typeof h!=='object')continue;const next={};
    for(const [k,max,min] of [['day',31,1],['month',12,1],['year',2200,2000]])if(Number.isInteger(h[k])&&h[k]>=min&&h[k]<=max)next[k]=h[k];
    if(Object.keys(next).length){if(h.invalid===true)next.invalid=true;out[field]=next;}
  }return out;
}
export function extractFlightInput(message,today,dateField='departureDate',dateHints={},returnNotBefore=today){
  const original=String(message||'');let rest=original.toLowerCase();const patch={};
  const returnDate=/\b(?:return(?:ing)?(?!\s+trip)|back on)\b/i.test(original)||dateField==='returnDate'&&!/\b(?:departure|departing|outbound|leaving)\b/i.test(original);
  const field=returnDate?'returnDate':'departureDate';let dateHint={...cleanDateHints(dateHints)[field]},hasDateFragments=false,invalidDate=false;
  const consume=(pattern,apply)=>{rest=rest.replace(pattern,(...args)=>{apply?.(...args);return ' ';});};
  const route=/\bfrom\s+([a-z][a-z .()'-]{0,60}?)\s+to\s+([a-z][a-z .()'-]{0,60}?)(?=\s+(?:for|on|with|at|departing|leaving|one[\s-]?way|round[\s-]?trip|return trip|tomorrow|today|cheapest|fastest|economy|business|premium economy|first class|any\s*time|morning|afternoon|evening|night)\b|[,.!?]|$)/i;
  const routeMatch=original.match(route);
  if(!/\b(?:destination|arrival|origin)\b.*\bfrom\b/i.test(original))consume(route,(_,origin,destination)=>{patch.origin=(routeMatch?.[1]||origin).trim();patch.destination=(routeMatch?.[2]||destination).trim();});
  consume(/\bone[\s-]?way\b/g,()=>patch.tripType='one-way');
  consume(/\bround[\s-]?trip\b|\breturn trip\b/g,()=>patch.tripType='round-trip');
  const counts={one:1,two:2,three:3,four:4,five:5,six:6,seven:7,eight:8,nine:9};
  if(!/\bchildren|child|infants?|bab(?:y|ies)\b/.test(rest))consume(/\b([1-9]|one|two|three|four|five|six|seven|eight|nine)\s*(?:passengers?|people|persons?|adults?)\b/,(_,n)=>patch.passengers=counts[n]||Number(n));
  // Normalize spoken ordinals, but do not interpret "first class/option" as a date.
  const ordinals=['first','second','third','fourth','fifth','sixth','seventh','eighth','ninth','tenth','eleventh','twelfth','thirteenth','fourteenth','fifteenth','sixteenth','seventeenth','eighteenth','nineteenth','twentieth','twenty first','twenty second','twenty third','twenty fourth','twenty fifth','twenty sixth','twenty seventh','twenty eighth','twenty ninth','thirtieth','thirty first'];
  rest=rest.replace(/\b(?:twenty[ -](?:first|second|third|fourth|fifth|sixth|seventh|eighth|ninth)|thirty[ -]first|first|second|third|fourth|fifth|sixth|seventh|eighth|ninth|tenth|eleventh|twelfth|thirteenth|fourteenth|fifteenth|sixteenth|seventeenth|eighteenth|nineteenth|twentieth|thirtieth)\b(?!\s+(?:class|option|choice|time|person|passenger))/g,word=>`${ordinals.indexOf(word.replace('-',' '))+1}th`);
  consume(/\b(\d{4})-(\d{2})-(\d{2})\b/,(_,year,month,day)=>{hasDateFragments=true;dateHint={year:Number(year),month:Number(month),day:Number(day)};});
  const named=new RegExp(`\\b(\\d{1,2})(?:st|nd|rd|th)?\\s+(?:of\\s+)?(${monthPattern})(?:\\s+(\\d{4}))?\\b`,'i');
  const monthFirst=new RegExp(`\\b(${monthPattern})\\s+(\\d{1,2})(?:st|nd|rd|th)?(?:,?\\s+(\\d{4}))?\\b`,'i');
  const setDate=(day,month,year)=>{hasDateFragments=true;dateHint={day:Number(day),month:months[month.toLowerCase()],...(year?{year:Number(year)}:{})};};
  if(!hasDateFragments){if(named.test(rest))consume(named,(_,day,month,year)=>setDate(day,month,year));else if(monthFirst.test(rest))consume(monthFirst,(_,month,day,year)=>setDate(day,month,year));}
  if(!hasDateFragments)consume(/\b(day after tomorrow|tomorrow|today)\b/,(_,relative)=>{const d=new Date(today+'T12:00:00Z');d.setUTCDate(d.getUTCDate()+({'day after tomorrow':2,tomorrow:1,today:0}[relative]));hasDateFragments=true;dateHint={day:d.getUTCDate(),month:d.getUTCMonth()+1,year:d.getUTCFullYear()};});
  if(!hasDateFragments){
    consume(new RegExp(`\\b(${monthPattern})\\b(?!\\s+(?:i|we|you|please|be|have|can)\\b)`,'i'),(_,month)=>{hasDateFragments=true;dateHint.month=months[month];});
    // Bare small counts are ambiguous. Days 1–9 require an ordinal or "on".
    consume(/\b(\d{1,2})(?:st|nd|rd|th)\b|\bon\s+(\d{1,2})\b|^\s*(1\d|2\d|3[01])\s*[.!]?\s*$/,(_,ordinal,on,bare)=>{hasDateFragments=true;dateHint.day=Number(ordinal||on||bare);});
    if(hasDateFragments)consume(/\b(20\d{2}|21\d{2}|2200)\b/,(_,year)=>dateHint.year=Number(year));
  }
  if(hasDateFragments){
    delete dateHint.invalid;
    if(dateHint.day&&dateHint.month){
      const year=dateHint.year||Number(today.slice(0,4));let date=calendarDate(year,dateHint.month,dateHint.day);
      const earliest=field==='returnDate'&&returnNotBefore>today?returnNotBefore:today;
      if(date&&!dateHint.year&&date<earliest)date=calendarDate(Math.max(year+1,Number(earliest.slice(0,4))),dateHint.month,dateHint.day);
      if(date&&!dateHint.year&&date<earliest)date=calendarDate(Number(earliest.slice(0,4))+1,dateHint.month,dateHint.day);
      if(date&&date>=earliest)patch[field]=date;else invalidDate=true;
    }else if(dateHint.day<1||dateHint.day>31||dateHint.month<1||dateHint.month>12)invalidDate=true;
    if(invalidDate)dateHint.invalid=true;
  }
  consume(/\b(?:any\s*time|anytime|flexible)(?:\s+(?:is\s+)?fine)?\b/g,()=>patch.departureTime='any time');
  consume(/\b(morning|afternoon|evening|night)\b/,(_,time)=>patch.departureTime=time);
  consume(/\b(cheapest|lowest price|lowest fare|fastest|shortest journey|balanced|balance of both)\b/,(_,value)=>patch.priority=/cheapest|lowest/.test(value)?'cheapest':/fastest|shortest/.test(value)?'fastest':'balanced');
  const remainder=rest.replace(/\b(?:it|is|its|it’s|and|on|at|for|the|a|an|i|we|would|like|want|prefer|please|fine|okay|ok|sure|yes|make|that|change|to|departure|depart|departing|return|returning|outbound|leaving|back|date|time|in|of|be|just)\b/g,' ').replace(/[^a-z0-9]/g,'').trim();
  return{patch,onlyDetails:(Object.keys(patch).length>0||hasDateFragments)&&!remainder,dateHint,hasDateFragments,invalidDate,dateField:field};
}
export function groundedFlightPatch(previous,modelPatch,explicit,message,today){
  const valid=cleanFlight({},modelPatch,today),result={};
  const words=String(message).toLowerCase().replace(/[^\p{L}\p{N}]+/gu,' ').trim();
  const mentions=value=>{const city=String(value).replace(/\([^)]*\)/g,'').toLowerCase().replace(/[^\p{L}\p{N}]+/gu,' ').trim();return city.length>1&&(' '+words+' ').includes(' '+city+' ');};
  for(const key of Object.keys(modelPatch||{})){
    const value=valid[key];if(modelPatch[key]==null||value===undefined)continue;
    if(previous[key]===value||explicit[key]!==undefined){result[key]=value;continue;}
    if(['origin','destination','cabin'].includes(key)&&mentions(value))result[key]=value;
    if(key==='passengers'&&value===1&&/\b(?:solo|just me|only me|by myself)\b/i.test(message))result[key]=value;
    if(['departureDate','returnDate'].includes(key)&&/\b(?:next\s+(?:monday|tuesday|wednesday|thursday|friday|saturday|sunday|week)|in\s+\d+\s+days?)\b/i.test(message))result[key]=value;
    if(key==='departureTime'&&/\b\d{1,2}(?::\d{2})?\s*(?:am|pm)\b/i.test(message))result[key]=value;
  }return result;
}
