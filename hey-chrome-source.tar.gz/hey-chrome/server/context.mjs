// Keep prior evidence for comparisons without resending full page copies every turn.
export function compactHistory(history){
  return history.slice(-12).map(h=>{
    if(h.role==='untrusted-page-data')return{role:h.role,url:h.url,title:h.title,text:String(h.text||'').slice(0,1000)};
    if(h.role==='untrusted-search-evidence')return{role:h.role,query:h.query,summary:String(h.summary||'').slice(0,1600),citations:h.citations?.slice(0,4)};
    return{role:h.role,text:String(h.text||'').slice(0,h.role==='user'?4000:1400)};
  });
}
