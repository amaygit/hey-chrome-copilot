// Retries are limited to inference requests. Browser actions are never replayed.
async function delay(ms,signal){await new Promise((resolve,reject)=>{const stop=()=>{clearTimeout(timer);reject(signal.reason||new DOMException('Aborted','AbortError'));};const timer=setTimeout(()=>{signal?.removeEventListener('abort',stop);resolve();},ms);if(signal?.aborted)stop();else signal?.addEventListener('abort',stop,{once:true});});}
export async function fetchGemini({key,model,signal,fetchImpl=fetch,timeoutMs=25000,retryDelayMs=750},body){
  for(let attempt=0;attempt<2;attempt++){
    signal?.throwIfAborted();const timeout=AbortSignal.timeout(timeoutMs);let response;
    try{response=await fetchImpl(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`,{method:'POST',headers:{'content-type':'application/json','x-goog-api-key':key},signal:signal?AbortSignal.any([signal,timeout]):timeout,body:JSON.stringify(body)});}
    catch(e){if(signal?.aborted||attempt||!(timeout.aborted||e.name==='TimeoutError'||e.name==='TypeError'))throw e;await delay(retryDelayMs,signal);continue;}
    if(response.status!==503||attempt===1)return response;
    await response.body?.cancel();await delay(retryDelayMs,signal);
  }
}
