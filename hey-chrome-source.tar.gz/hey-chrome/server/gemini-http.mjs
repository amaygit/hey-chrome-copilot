// Only generation requests are retried; browser actions are never replayed.
export async function fetchGemini({key,model,signal,fetchImpl=fetch},body){
  for(let attempt=0;attempt<2;attempt++){
    const timeout=AbortSignal.timeout(25000);
    const response=await fetchImpl(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`,{
      method:'POST',headers:{'content-type':'application/json','x-goog-api-key':key},signal:signal?AbortSignal.any([signal,timeout]):timeout,body:JSON.stringify(body)
    });
    if(response.status!==503 || attempt===1)return response;
    await response.body?.cancel();
    await new Promise((resolve,reject)=>{
      const stop=()=>{clearTimeout(timer);reject(signal.reason || new Error('Request cancelled.'));};
      const timer=setTimeout(()=>{signal?.removeEventListener('abort',stop);resolve();},750);
      if(signal?.aborted)stop();else signal?.addEventListener('abort',stop,{once:true});
    });
  }
}
