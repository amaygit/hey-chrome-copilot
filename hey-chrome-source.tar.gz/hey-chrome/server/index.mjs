import { createApp } from './app.mjs';
import { resolveMember,readMembers } from './access.mjs';
import { resolve } from 'node:path';
import {createRuntimeStore,loadRuntimeSettings} from './runtime-settings.mjs';
const runtimeFile=resolve('.data/runtime-settings.json');loadRuntimeSettings(process.env,runtimeFile);
const adminStore=createRuntimeStore({file:runtimeFile});
const port=Number(process.env.PORT || 8787);
if (!Number.isInteger(port) || port<1024 || port>65535) throw new Error('Invalid PORT.');
const host=process.env.HOST || (process.env.RENDER?'0.0.0.0':'127.0.0.1');
if(!['127.0.0.1','0.0.0.0'].includes(host))throw new Error('HOST must be 127.0.0.1 or 0.0.0.0.');
const accessFile=resolve(process.env.ACCESS_FILE||'.data/access.json');
const app=createApp({token:process.env.BACKEND_TOKEN,key:process.env.GEMINI_API_KEY,model:process.env.GEMINI_MODEL || 'gemini-3.1-flash-lite',demo:process.env.DEMO_MODE === 'true',
  adminStore,adminOrigin:process.env.RENDER_EXTERNAL_URL||process.env.ADMIN_ORIGIN,telemetryFile:resolve('.data/diagnostics.json'),
  getMembers:()=>process.env.ACCESS_MEMBERS_JSON!==undefined?JSON.parse(process.env.ACCESS_MEMBERS_JSON):readMembers(accessFile),
  xaiKey:process.env.XAI_API_KEY,xaiModel:process.env.XAI_SEARCH_MODEL,
  tavilyKey:process.env.TAVILY_API_KEY,keylessSearch:process.env.KEYLESS_SEARCH!=='false',
  highAccuracy:process.env.HIGH_ACCURACY!=='false',searchKey:process.env.GEMINI_SEARCH_API_KEY,verifyKey:process.env.GEMINI_VERIFY_API_KEY,
  searchModel:process.env.GEMINI_SEARCH_MODEL,verifyModel:process.env.GEMINI_VERIFY_MODEL,assistantName:process.env.ASSISTANT_NAME,
  allowedExtensionIds:(process.env.ALLOWED_EXTENSION_IDS||'*').split(',').map(x=>x.trim()),resolvePrincipal:token=>resolveMember(accessFile,token,process.env.ACCESS_MEMBERS_JSON)});
app.requestTimeout=50000; app.headersTimeout=10000;
app.listen(port,host,()=>console.log(`Hey Chrome backend listening on http://${host}:${port}. Private configuration loaded; no keys or conversation text are logged.`));
