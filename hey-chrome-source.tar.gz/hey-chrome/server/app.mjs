import { createServer } from 'node:http';
import { randomUUID, timingSafeEqual } from 'node:crypto';
import { cleanFlight, flightQuestion, flightSearchURL, missingFlight, sanitizePage, validateAction } from './core.mjs';
import { geminiTurn } from './gemini.mjs';
import { reviewProposal } from './accuracy.mjs';
import { demoTurn } from './demo.mjs';
import { extractFlightInput, groundedFlightPatch } from './flight-input.mjs';
import { ModelOutputError } from './model-output.mjs';
import { configuredResearch } from './research.mjs';
import { compactHistory } from './context.mjs';
function auth(a,b){const x=Buffer.from(a||''),y=Buffer.from(b);return x.length===y.length&&timingSafeEqual(x,y);}
function problem(status,message){const e=new Error(message);e.status=status;return e;}
export function createApp(config){
  if(!config.token || config.token.length<32)throw new Error('BACKEND_TOKEN must contain at least 32 characters. Run node scripts/setup.mjs.');
  const sessions=new Map(),busy=new Set(),limits=new Map(),jobs=new Map();
  const provider=config.provider || (config.demo?async c=>demoTurn(c):(c,signal)=>geminiTurn(c,{key:config.key,model:config.model,signal,thinkingLevel:config.highAccuracy?'medium':'low'}));
  const search=config.search || configuredResearch(config);
  const reviewer=config.review || (config.highAccuracy&&!config.demo&&config.key?((c,signal)=>reviewProposal(c,{key:config.verifyKey||config.key,model:config.verifyModel||config.model,signal})):null);
  const origins=config.allowedExtensionIds || ['*'];
  function cleanup(){
    const now=Date.now();for(const [id,s] of sessions)if(now-s.updatedAt>3600000)sessions.delete(id);
    for(const [id,l] of limits)if(now-l.start>60000)limits.delete(id);
    for(const [id,j] of jobs)if(now-j.createdAt>600000){j.controller.abort();jobs.delete(id);}
  }
  async function runTurn(body,principal,signal,onStage=()=>{}){
    onStage('Understanding your request…');
    cleanup();
    const sessionId=typeof body.sessionId==='string'&&/^[\w-]{1,80}$/.test(body.sessionId)?body.sessionId:randomUUID();
    const sessionKey=principal.id+':'+sessionId;
    if(busy.has(sessionKey))throw problem(409,'A turn is already running.');
    const now=Date.now();
    for(const [id,max] of [['global',80],['member:'+principal.id,principal.id==='owner'?40:12]]){
      const limit=limits.get(id)||{start:now,count:0};limit.count++;limits.set(id,limit);
      if(limit.count>max)throw problem(429,'Request limit reached. Wait a minute.');
    }
    if(sessions.size>=100&&!sessions.has(sessionKey))throw problem(429,'Session limit reached. Reset an old conversation.');
    if(!config.demo&&!config.provider&&!config.key)throw problem(503,'The server owner must configure Gemini, or enable DEMO_MODE=true.');
    if(typeof body.message!=='string'||body.message.length>4000||(!body.message.trim()&&!body.observation))throw problem(400,'A message of up to 4000 characters is required.');
    const timezone=typeof body.timezone==='string'?body.timezone.slice(0,80):'UTC';
    let localDate;try{localDate=new Intl.DateTimeFormat('en-CA',{timeZone:timezone,year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());}catch{throw problem(400,'Invalid timezone.');}
    busy.add(sessionKey);
    try{
      const client=body.clientContext;
      const restoredHistory=Array.isArray(client?.history)?client.history.filter(h=>h&&['user','assistant'].includes(h.role)&&typeof h.text==='string').slice(-12).map(h=>({role:h.role,text:h.text.slice(0,2000)})):[];
      if(restoredHistory.at(-1)?.role==='user'&&restoredHistory.at(-1)?.text===body.message)restoredHistory.pop();
      const restoredFlight=client?.flight&&typeof client.flight==='object'&&!Array.isArray(client.flight)&&Object.keys(client.flight).some(k=>k!=='cabin')?cleanFlight({},client.flight,localDate):{};
      const session=structuredClone(sessions.get(sessionKey)||{history:restoredHistory,flight:restoredFlight,intent:client?.intent==='flight'?'flight':'general',flightStage:body.observation?'searching':'collecting',updatedAt:now});
      const priorFlight=JSON.stringify(session.flight);
      const flightContext=session.intent==='flight'||/\b(?:flights?|flying|fly|air ticket|plane ticket)\b/i.test(body.message)||(!session.intent&&Object.keys(session.flight).some(k=>k!=='cabin'));
      const dateField=session.flight.departureDate&&session.flight.tripType==='round-trip'&&!session.flight.returnDate?'returnDate':'departureDate';
      const explicit=flightContext&&!body.observation?extractFlightInput(body.message,localDate,dateField):{patch:{},onlyDetails:false};
      if(Object.keys(explicit.patch).length)session.flight=cleanFlight(session.flight,explicit.patch,localDate);
      const page=sanitizePage(body.page);
      const restoredRequests=Array.isArray(client?.requests)?client.requests.filter(x=>typeof x==='string').slice(-3).map(x=>x.slice(0,4000)):restoredHistory.filter(h=>h.role==='user').map(h=>h.text).slice(-3);
      session.requests=session.requests||restoredRequests;
      if(body.message.trim()&&session.requests.at(-1)!==body.message)session.requests=[...session.requests,body.message].slice(-3);
      const researchMode=body.researchMode==='browser'?'browser':'api';
      const context={message:body.message,observation:body.observation?String(body.observation).slice(0,2000):null,requests:session.requests,history:compactHistory(session.history),flight:session.flight,flightStage:session.flightStage,page,localDate,timezone,researchMode};
      let evidence=null;
      if(page?.research&&session.browserSearch?.query===page.research.query){
        context.searchUsed=true;
        if(page.research.results.length){evidence={query:page.research.query,summary:'Visible Google search snippets are in page.research. Original source pages have not been read. The AI Overview is a secondary summary, not independent verification.',citations:page.research.results.map(r=>({title:r.title,url:r.url})),grounded:true,kind:'browser-search-snippets'};context.searchEvidence=evidence;}
      }
      if(body.approvedSearchId){
        if(!session.pendingSearch || session.pendingSearch.id!==body.approvedSearchId || now-session.pendingSearch.createdAt>120000)throw problem(400,'The research proposal expired or was already used. Ask again.');
        onStage('Researching current web sources…');
        try{evidence=await search(session.pendingSearch.query,signal);}
        catch(error){
          if(![429,503].includes(error.status)&&error.name!=='TimeoutError')throw error;
          evidence={query:session.pendingSearch.query,summary:'I’ll open web search to continue looking for sources.',citations:[],grounded:false,unavailable:true};
        }
        context.searchEvidence=evidence;context.searchUsed=true;delete session.pendingSearch;
      }else if(body.message.trim())delete session.pendingSearch;
      onStage('Planning the next step…');
      let output;
      if(page?.research?.blocked==='captcha')output={message:'Google is asking for a browser verification. Complete it on the page, then press Resume.',intent:'general',flight:{},action:{type:'handoff',reason:'captcha'}};
      else if(evidence?.unavailable)output={message:evidence.summary,intent:'general',flight:{},action:{type:'navigate',url:'https://www.google.com/search?q='+encodeURIComponent(evidence.query)}};
      else if(explicit.onlyDetails&&session.intent==='flight')output={message:'Your trip details are saved.',intent:'flight',flight:{},action:{type:'none'}};
      else{
        try{output=await provider(context,signal);}
        catch(error){if(error instanceof ModelOutputError&&flightContext&&Object.keys(explicit.patch).length)output={message:'Your trip details are saved.',intent:'flight',flight:{},action:{type:'none'}};else throw error;}
      }
      if(!flightContext&&output.intent==='flight')output={...output,intent:'general',flight:{}};
      if(signal.aborted)throw problem(499,'Request cancelled.');
      let message=output.message,action=null;
      if(output.intent==='flight'){
        const modelPatch=groundedFlightPatch(session.flight,output.flight,explicit.patch,body.message,localDate);
        session.flight=cleanFlight(session.flight,{...modelPatch,...explicit.patch},localDate);
        if(missingFlight(session.flight).length){const accepted=Object.entries(explicit.patch).filter(([k,v])=>session.flight[k]===v).map(([,v])=>v);const noted=explicit.onlyDetails&&accepted.length?`Noted: ${accepted.join(' · ')}. `:'';message=(config.demo?'DEMO · ':'')+noted+flightQuestion(session.flight);session.flightStage='collecting';}
        else if(session.flightStage==='collecting'||(priorFlight!==JSON.stringify(session.flight)&&!body.observation)){
          action={type:'navigate',url:flightSearchURL(session.flight)};
          message=`Ready to search ${session.flight.origin} → ${session.flight.destination} on ${session.flight.departureDate} for ${session.flight.passengers} passenger(s), ${session.flight.cabin}. Review the search below. Verify the provider's actual filters, prices and age rules.`;session.flightStage='searching';
        }else action=output.action;
      }else action=output.action;
      if(action?.type==='web_search'){
        if(config.demo)throw problem(400,'Grounded research is available only with Gemini enabled.');
        if(context.searchUsed)throw problem(502,'Only one grounded search can run in an approved step. Ask a follow-up to research further.');
        const query=action.query;
        if(typeof query!=='string'||!query.trim()||query.length>500)throw problem(502,'Invalid public search query; nothing was searched.');
        if(researchMode==='browser'){
          session.browserSearch={query:query.trim()};delete session.pendingSearch;
          action=validateAction({type:'navigate',url:'https://www.google.com/search?q='+encodeURIComponent(query.trim())},page);
        }else{const id=randomUUID();session.pendingSearch={id,query:query.trim(),createdAt:Date.now()};action={type:'web_search',query:query.trim(),searchId:id};}
      }else action=validateAction(action,page);
      let review=null;
      if(reviewer && (action||evidence)){
        onStage('Checking the answer and next action…');review=await reviewer({...context,proposal:{message,action}},signal);
        if(review.verdict!=='allow'){action=null;delete session.pendingSearch;message=review.message || 'Please clarify your goal before I continue.';}
      }
      if(evidence?.grounded && review?.verdict!=='block'){
        const sources=evidence.citations.slice(0,5).filter(c=>!message.includes(c.url));
        if(sources.length)message+='\n\nRetrieved sources:\n'+sources.map(c=>`${c.title}: ${c.url}`).join('\n');
      }
      if(signal.aborted)throw problem(499,'Request cancelled.');
      if(page)session.history.push({role:'untrusted-page-data',url:page.url,title:page.title,text:page.research?JSON.stringify(page.research).slice(0,3000):page.text.slice(0,6000)});
      if(evidence)session.history.push({role:'untrusted-search-evidence',...evidence,summary:evidence.summary.slice(0,6000)});
      session.history.push(body.observation?{role:'observation',text:context.observation}:{role:'user',text:body.message},{role:'assistant',text:message});
      session.history=session.history.slice(-20);session.intent=output.intent;session.updatedAt=Date.now();sessions.set(sessionKey,session);
      return{sessionId,message,intent:session.intent,flight:session.flight,missing:missingFlight(session.flight),action,mode:config.demo?'demo':'gemini',accuracy:reviewer?'high':'balanced',review:review?.verdict||null,sources:evidence?.citations||[]};
    }finally{busy.delete(sessionKey);}
  }
  return createServer(async(req,res)=>{
    const headers={'content-type':'application/json','cache-control':'no-store','x-content-type-options':'nosniff'};
    const send=(code,data)=>{if(!res.destroyed){res.writeHead(code,headers);res.end(code===204?undefined:JSON.stringify(data));}};
    const abort=new AbortController();res.on('close',()=>{if(!res.writableEnded)abort.abort();});
    try{
      // Public liveness only: no model, account, configuration or credentials are disclosed.
      if(req.method==='GET'&&req.url==='/healthz')return send(200,{ok:true});
      const origin=req.headers.origin;
      const extensionId=origin?.match(/^chrome-extension:\/\/([a-p]{32})$/)?.[1];
      if(origin&&(!extensionId||(!origins.includes('*')&&!origins.includes(extensionId))))return send(403,{error:'This extension is not allowed by the server.'});
      if(origin){headers['access-control-allow-origin']=origin;headers.vary='Origin';}
      if(req.method==='OPTIONS'){headers['access-control-allow-methods']='POST, GET, DELETE, OPTIONS';headers['access-control-allow-headers']='Authorization, Content-Type';return send(204,{});}
      const bearer=req.headers.authorization?.startsWith('Bearer ')?req.headers.authorization.slice(7):'';
      const principal=auth(bearer,config.token)?{id:'owner',name:'Owner'}:config.resolvePrincipal?.(bearer);
      if(!principal)return send(401,{error:'Access code is missing, incorrect, or revoked. Ask the server owner for access.'});
      if(req.url==='/health'&&req.method==='GET')return send(200,{ok:true,version:'1.5.0',mode:config.demo?'demo':'gemini',configured:config.demo||Boolean(config.key),model:config.model,...(principal.id==='owner'?{research:search.diagnostics?.()||[]}:{ }),assistantName:config.assistantName||'Hey Chrome',memberName:principal.name,accuracy:reviewer?'high':'balanced'});
      const jobId=req.url?.match(/^\/api\/jobs\/([\w-]+)$/)?.[1];
      if(jobId&&['GET','DELETE'].includes(req.method)){
        cleanup();const job=jobs.get(jobId);if(!job||job.owner!==principal.id)return send(404,{error:'Job not found.'});
        if(req.method==='DELETE'){job.controller.abort();jobs.delete(jobId);return send(200,{ok:true});}
        return send(200,{status:job.status,stage:job.stage,...(job.status==='complete'?{result:job.result}:job.status==='failed'?{error:job.error}:{} )});
      }
      if(req.method!=='POST'||!['/api/turn','/api/reset','/api/jobs'].includes(req.url))return send(404,{error:'Not found.'});
      if(!req.headers['content-type']?.startsWith('application/json'))return send(415,{error:'Use application/json.'});
      const chunks=[];let bytes=0;for await(const chunk of req){bytes+=chunk.length;if(bytes>100000)return send(413,{error:'Request too large.'});chunks.push(chunk);}
      let body;try{body=JSON.parse(Buffer.concat(chunks).toString('utf8'));}catch{return send(400,{error:'Invalid JSON.'});}
      if(!body||typeof body!=='object'||Array.isArray(body))return send(400,{error:'Expected a JSON object.'});
      if(req.url==='/api/reset'){
        const key=principal.id+':'+body.sessionId;if(busy.has(key))return send(409,{error:'Stop the running request before resetting.'});sessions.delete(key);return send(200,{ok:true});
      }
      if(req.url==='/api/jobs'){
        cleanup();if(jobs.size>=100||[...jobs.values()].filter(j=>j.owner===principal.id&&j.status==='running').length>=2)return send(429,{error:'Too many active jobs. Stop a request or wait.'});
        const id=randomUUID(),controller=new AbortController();
        const job={owner:principal.id,status:'running',createdAt:Date.now(),controller};jobs.set(id,job);
        const deadline=setTimeout(()=>controller.abort(),110000);deadline.unref?.();
        runTurn(body,principal,controller.signal,stage=>job.stage=stage).then(result=>{job.status='complete';job.result=result;}).catch(e=>{job.status='failed';job.error=e.name==='TimeoutError'?'Gemini timed out. Please retry.':e.message;}).finally(()=>clearTimeout(deadline));
        return send(202,{jobId:id});
      }
      return send(200,await runTurn(body,principal,abort.signal));
    }catch(e){return send(e.status||502,{error:e.name==='TimeoutError'?'Gemini timed out. Please retry.':e.message||'Backend request failed.'});}
  });
}
