# Release 1.4.0 verification

54 automated tests pass. Controlled browser QA uses the production content/background scripts, real Chromium DOM and the actual Gemini planner/verifier, with a simulated Chrome tabs/permissions adapter and a fake booking site. It does not certify real travel websites or the installed Chrome integration. No real credentials, tickets or payments are used.

Tavily keyless search returned HTTP 200 and retrieved linked snippets during live checks. No Tavily signup/key/card was needed. Rate limits still apply.

The browser QA found and fixed dropdown-label contamination, missing selection/completion state, a mistaken flight collector on a non-flight task and a redundant review confirmation before payment. Final recorded results and screenshots are in the separate 1.4.0 test report.

## Earlier release evidence

# Release 1.3.0 verification

49 offline tests pass, including automatic navigation/research, bounded action loops, Stop cancellation, manual login/payment handoff and Resume, independent-provider failover, quota cooldowns, citation validation and the flight conversation regressions. JavaScript syntax checks pass.

Grok support uses the xAI Responses API with web_search and requires XAI_API_KEY on the server. No xAI key is configured yet; actual Grok responses have not been tested.

Actual end-to-end bookings, microphone recognition and arbitrary booking websites have not been verified. The adapter supports top-frame ordinary controls; cross-origin widgets, CAPTCHA, complex custom forms or anti-bot systems may require manual work. Payment and login remain manual.

## Earlier deployment evidence

# Verified deployment — 19 November 2026

Backend: https://hey-chrome-copilot.onrender.com

Render service: `srv-dbvan2cs728c73dli6ug`. Live deployment: `dep-dbvasjrl550s7398e940`, source commit `a315bfd715451f6827a577e60e044dda90c4bc8e`. Plan: Free. Runtime: Node.js 26.13.1. Local test runtime: Node.js 24.22.1 on Windows.

## Automated verification

**32 tests pass**, covering general-task follow-up questions, flight validation, retained page evidence, explicit action/query approval, stale-tab checks, replay protection, cancellation, named-user session isolation, revocation, public liveness versus protected account data, environment-backed member storage, private job access, grounding sources, independent verification, research-quota fallback and bounded model retries. All JavaScript passes syntax checks.

Background-worker tests use actual worker code with a real HTTP backend and mocked Chrome APIs. Most model outputs in unit tests are mocked. These checks do not establish a real-world accuracy percentage.

## Live hosted checks

| Check | Observed result |
| --- | --- |
| Public `/healthz` | HTTP 200 |
| `/health` without an access code | HTTP 401 |
| `/health` with the owner code | HTTP 200; Gemini configured; high-accuracy mode enabled |
| Active model | `gemini-3.1-flash-lite` |
| “Help me find a laptop” | Asked for budget and intended use, with no premature action |
| “Open https://example.com/” | Proposed navigation to the exact URL; independent verifier returned `allow` |
| Public Node.js documentation research | Proposed a research query; independent verifier returned `allow` |
| Approved grounded research | Google's search tool returned quota HTTP 429; backend proposed a Google browser search, explicitly reported no retrieved results, returned zero fabricated source citations, and passed independent verification |

The first supplied key is used for planning/default research; the second is used for verification. Both were accepted by Google's model-list API, and the planner and verifier have now returned live answers. Gemini 3.8 Flash timed out in earlier checks; the active configuration was deliberately changed to the responsive 3.1 Flash-Lite model. Keys do not themselves increase accuracy or multiply project quotas.

No browser navigation was executed by these API-only integration checks: they verified proposals and reviews. The actual Chrome extension still requires installation, site access grants and a user click to enable voice. Live microphone recognition, arbitrary website forms and actual flight/product availability have not been tested end to end.

## Deployment and distribution

The GitHub repository was made public with explicit user approval. Uploaded source was checked for both Gemini keys and the owner access code; none were included. Gemini keys and owner authorization are stored in Render's environment settings. Existing Render services and GitHub deployment credentials were not changed.

The personal extension package contains the owner's prefilled server URL and access code, but no Gemini key. Client computers need no local Node server or `.env` file. Keep that personal access package private; use separately generated member packages for other people.

Render Free can sleep and take about a minute to wake. Member registrations must be saved in Render's `ACCESS_MEMBERS_JSON` setting to survive restarts; in-memory conversation history does not survive them. No paid compute plan or database was selected. Google API quotas/billing remain separate.

Deployment screenshot is provided beside the project as `render-deployment.jpg`. See INSTALL-EXTENSION.md and RENDER-DEPLOYMENT.md for usage and maintenance.
