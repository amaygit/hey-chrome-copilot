# Verification record — 19 November 2026

Environment: Windows, Node.js v24.22.1. Application version: 1.1.0.

## Automated checks

- All JavaScript passes syntax checks and the extension manifest entry points exist.
- 29 automated tests cover multi-turn requirements, general-task routing, retained source evidence, action validation, stale tab proposals, explicit approvals, replay prevention, cancellation, separate named-user sessions, access revocation, job isolation, grounded-source handling, verification failures and bounded generation retries.
- Background tests run the actual worker against a real local HTTP backend with mocked Chrome APIs. Provider/grounding outputs in automated tests are mocked. Passing these checks is not a measured real-world accuracy score.

## Live Gemini checks

- Google accepted both supplied credentials for the model-list API.
- The configured `gemini-3.8-flash` model was listed for each credential.
- The first credential is saved privately for planning/default research. The second is saved privately for verification. Neither is embedded in the shareable extension source.
- Live generation attempts encountered an upstream HTTP 503 and timeouts. A small model probe also returned a timeout for 3.8 Flash, HTTP 503 for 3.5 Flash and HTTP 404 for 2.5 Flash. No silent model substitution was made.
- Consequently, a complete live planner → grounded search → verification success has **not** been demonstrated. The live smoke script is included for a later retry. API key acceptance alone does not establish generation availability or quota.

## UI and deployment

- The earlier browser preview verified general-task questions, action review, settings feedback and a 390-pixel-wide side-panel layout. It used simulated responses. The preview screenshot beside the project folder is labeled accordingly.
- The private project now has persistent backend settings and a pre-connected personal extension. It requires no repeated key entry.
- Hosting configuration and named member packaging are included, but no public HTTPS server has been deployed. A hosting destination is still needed for a single shared backend reachable across computers.
- Chrome installation, live microphone recognition, real third-party form behavior, and live flight/product availability are not verified end to end. No accuracy percentage or universal-site success claim is made.

## Reproduce

```powershell
node scripts/check.mjs
node --test tests/*.test.mjs
node --env-file=.env scripts/check-gemini.mjs
# Makes live AI calls using the configured project's quota:
node --env-file=.env scripts/smoke-live.mjs
```

The configured private archive contains credentials for the owner. The source archive excludes `.env`, personal extension connection settings, member registrations and exported member packages. Share a generated member extension package to grant revocable access.
