# Admin and sharing verification — 1.7.0

98 automated tests pass, including 13 admin, persistence and telemetry tests. Checks cover owner-only authentication, HttpOnly cookies, throttling, signed sessions across restarts, CSRF and same-origin enforcement, tampered sessions, protected settings, failed key checks preserving the old key, persistent saves before activation, Render failures, restricted integration targets, member ZIP secret exclusion, immediate revocation, fixed diagnostic categories and report limits, background job failures, bounded redacted storage and Sentry endpoint restrictions.

Browser UI testing used production admin HTML/CSS/JS and server handlers with simulated provider/Render endpoints. Owner sign-in, simulated hosting connection, key rotation date, tester ZIP download and test-error capture all worked. The browser-downloaded ZIP was extracted by Windows and checked for v1.7.0 and the correct limited member connection. Simulated hosting/provider checks are explicitly labeled in that preview. They do not establish production Render connectivity or Sentry delivery.

Shared testers membership was activated on the actual Render backend and returned HTTP 200 from a different Chrome extension origin. Owner-only diagnostics were absent. The share ZIP was checked to exclude Gemini credentials and the owner code.

# Voice turn-taking verification — 1.6.0

85 automated tests pass, including 17 voice/audio-controller cases and six new date/route conversation regressions. Tests cover merged final fragments, unfinished interim results, the silence timer, microphone activity extending the timer, editing/manual Send, uncertain recognition, queued speech while busy, wake interruption, sustained audio cancelling synthesis before a transcript, echo rejection, resource cleanup and final-answer-only narration. Date regressions cover day/month in separate turns, spoken ordinals, preserved passenger counts, unknown counts, restart recovery, outbound/return separation and invalid corrections.

A real Gemini planner/verifier check on the updated local backend passed the full five-turn conversation: Goa → Delhi, one way, five adults; 25th; December; anytime fine cheapest; then a laptop request. The live check found the route suffix bug before the final hosted revision: the parser now stops before one-way/round-trip and common preferences instead of absorbing them into the destination.

The browser UI lab uses the production voice HTML/CSS/JS with simulated Chrome, recognition, synthesis and microphone samples. It verifies actual control wiring and rendered state; it does not measure a physical microphone, Chrome's real speech service, accents, or acoustic echo. The previous release's simulated tests passed despite the reported real-audio failure. This release adds buffering and a second audio-based interruption path, but real-device performance remains unverified until tested by the user.

# Loading and voice update — 1.5.1

70 automated tests pass, including eight voice tests: microphone remains active while reading, interim wake interrupts immediately, same-utterance commands dispatch once, ordinary echo is ignored, recognition restarts during reading, loading phases toggle correctly, manual stop reading preserves the microphone, and a new typed request restores narration.

Browser UI preview checked loading → reply → loading, then reading → simulated Hey Chrome → listening. Real extension HTML/CSS/JS ran with simulated Chrome and speech APIs. The animation, buttons and state changes were visually checked; physical microphone/speaker echo and real speech recognition accuracy were not measured.

## Earlier release evidence

# Release 1.5.0 verification

62 automated tests and 28 controlled browser checks pass. The actual Gemini booking simulation again reached payment after login handoff and Resume. Browser fixture tests verify zero AI jobs for Quick search/open, optional Google AI Overview extraction, visible results without an Overview, ad/hidden-card filtering, and compact search context. The measured fixture shrank from 8202 to 1216 characters (about 85%); this is a character count for the fixture, not a measured end-to-end token/cost reduction. Live Google DOM inspection informed nested Overview and redirect handling.

Production scripts are exercised in real Chromium with simulated Chrome APIs. This does not certify every live Google variation or arbitrary booking website. Google excerpts remain unverified external content; normal agent reasoning still consumes Gemini quota.

## Earlier release evidence

# Release 1.4.0 verification

54 automated tests pass. Controlled browser QA uses the production content/background scripts, real Chromium DOM and the actual Gemini planner/verifier, with a simulated Chrome tabs/permissions adapter and a fake booking site. It does not certify real travel websites or the installed Chrome integration. No real credentials, tickets or payments are used.

Tavily keyless search returned HTTP 200 and retrieved linked snippets during live checks. No Tavily signup/key/card was needed. Rate limits still apply.

The browser QA found and fixed dropdown-label contamination, missing selection/completion state, a mistaken flight collector on a non-flight task and a redundant review confirmation before payment. Final recorded results and screenshots are in the separate 1.4.0 test report.

## Earlier release evidence

# Release 1.3.0 verification

49 offline tests pass, including automatic navigation/research, bounded action loops, Stop cancellation, manual login/payment handoff and Resume, independent-provider failover, quota cooldowns, citation validation and the flight conversation regressions. JavaScript syntax checks pass.

Grok support uses the xAI Responses API with web_search and requires XAI_API_KEY on the server. No xAI key is configured yet; actual Grok responses have not been tested.

Actual end-to-end bookings, microphone recognition and arbitrary booking websites have not been verified. The adapter supports top-frame ordinary controls; cross-origin widgets, CAPTCHA, complex custom forms or anti-bot systems may require manual work. Payment and login remain manual.

## Earlier deployment evidence

# Verified deployment — 19 November 2026

Backend: https://hey-chrome-copilot.onrender.com

Render service: `srv-dbvan2cs728c73dli6ug`. Live deployment: `dep-dbvasjrl550s7398e940`, source commit `a315bfd715451f6827a577e60e044dda90c4bc8e`. Plan: Free. Runtime: Node.js 26.13.1. Local test runtime: Node.js 24.22.1 on Windows.

## Automated verification

**32 tests pass**, covering general-task follow-up questions, flight validation, retained page evidence, explicit action/query approval, stale-tab checks, replay protection, cancellation, named-user session isolation, revocation, public liveness versus protected account data, environment-backed member storage, private job access, grounding sources, independent verification, research-quota fallback and bounded model retries. All JavaScript passes syntax checks.

Background-worker tests use actual worker code with a real HTTP backend and mocked Chrome APIs. Most model outputs in unit tests are mocked. These checks do not establish a real-world accuracy percentage.

## Live hosted checks

| Check | Observed result |
| --- | --- |
| Public `/healthz` | HTTP 200 |
| `/health` without an access code | HTTP 401 |
| `/health` with the owner code | HTTP 200; Gemini configured; high-accuracy mode enabled |
| Active model | `gemini-3.1-flash-lite` |
| “Help me find a laptop” | Asked for budget and intended use, with no premature action |
| “Open https://example.com/” | Proposed navigation to the exact URL; independent verifier returned `allow` |
| Public Node.js documentation research | Proposed a research query; independent verifier returned `allow` |
| Approved grounded research | Google's search tool returned quota HTTP 429; backend proposed a Google browser search, explicitly reported no retrieved results, returned zero fabricated source citations, and passed independent verification |

The first supplied key is used for planning/default research; the second is used for verification. Both were accepted by Google's model-list API, and the planner and verifier have now returned live answers. Gemini 3.8 Flash timed out in earlier checks; the active configuration was deliberately changed to the responsive 3.1 Flash-Lite model. Keys do not themselves increase accuracy or multiply project quotas.

No browser navigation was executed by these API-only integration checks: they verified proposals and reviews. The actual Chrome extension still requires installation, site access grants and a user click to enable voice. Live microphone recognition, arbitrary website forms and actual flight/product availability have not been tested end to end.

## Deployment and distribution

The GitHub repository was made public with explicit user approval. Uploaded source was checked for both Gemini keys and the owner access code; none were included. Gemini keys and owner authorization are stored in Render's environment settings. Existing Render services and GitHub deployment credentials were not changed.

The personal extension package contains the owner's prefilled server URL and access code, but no Gemini key. Client computers need no local Node server or `.env` file. Keep that personal access package private; use separately generated member packages for other people.

Render Free can sleep and take about a minute to wake. Member registrations must be saved in Render's `ACCESS_MEMBERS_JSON` setting to survive restarts; in-memory conversation history does not survive them. No paid compute plan or database was selected. Google API quotas/billing remain separate.

Deployment screenshot is provided beside the project as `render-deployment.jpg`. See INSTALL-EXTENSION.md and RENDER-DEPLOYMENT.md for usage and maintenance.
