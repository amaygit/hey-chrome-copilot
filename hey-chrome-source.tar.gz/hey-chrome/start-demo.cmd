@echo off
cd /d "%~dp0"
if not exist .env node scripts/setup.mjs
set DEMO_MODE=true
node --env-file=.env server/index.mjs
pause
