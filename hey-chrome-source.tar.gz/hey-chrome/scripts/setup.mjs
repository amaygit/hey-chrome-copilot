import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { randomBytes } from 'node:crypto';
if (!existsSync('.env')) {
  writeFileSync('.env', readFileSync('.env.example', 'utf8').replace('BACKEND_TOKEN=','BACKEND_TOKEN=' + randomBytes(32).toString('hex')), { mode: 0o600 });
  console.log('Created .env. Add your new Gemini key there. Copy BACKEND_TOKEN into extension Settings.');
} else console.log('.env already exists; no changes made.');
