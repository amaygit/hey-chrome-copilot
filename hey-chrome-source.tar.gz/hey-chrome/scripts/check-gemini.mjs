const key=process.env.GEMINI_API_KEY;
if(!key)throw new Error('The private backend has no Gemini key configured.');
try{
  const r=await fetch('https://generativelanguage.googleapis.com/v1beta/models',{headers:{'x-goog-api-key':key},signal:AbortSignal.timeout(20000)});
  if(!r.ok){console.log(`Gemini credential check: HTTP ${r.status}. No key or provider response body was logged.`);process.exitCode=1;}
  else{const body=await r.json();const available=body.models?.filter(m=>m.supportedGenerationMethods?.includes('generateContent')).map(m=>m.name.replace('models/',''))||[];console.log('Gemini accepted the configured credential.');console.log(`Configured model listed: ${available.includes(process.env.GEMINI_MODEL||'gemini-3.1-flash-lite')}`);console.log('Available text model examples:',available.filter(n=>/flash|hydrogen/.test(n)&&!/image|tts|live|audio/.test(n)).slice(0,8).join(', '));}
}catch(e){console.log(`Gemini credential check could not complete: ${e.name}. No key was logged.`);process.exitCode=1;}
