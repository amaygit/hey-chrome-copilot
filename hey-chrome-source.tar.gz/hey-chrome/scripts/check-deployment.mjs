import { randomUUID } from 'node:crypto';
const base=new URL(process.argv[2]||'https://hey-chrome-copilot.onrender.com').origin;
if(!process.env.BACKEND_TOKEN)throw new Error('Load the private backend .env first.');
const headers={Authorization:`Bearer ${process.env.BACKEND_TOKEN}`,'Content-Type':'application/json'};
async function request(path,{body,method='GET',authenticated=true}={}){
  const r=await fetch(base+path,{method,headers:authenticated?headers:{},...(body?{body:JSON.stringify(body)}:{}),signal:AbortSignal.timeout(80000)});
  if(!r.headers.get('content-type')?.includes('application/json'))throw new Error(`Server returned a non-JSON response (HTTP ${r.status}). It may be waking up.`);
  return{status:r.status,body:await r.json()};
}
const health=await request('/healthz',{authenticated:false});if(health.status!==200)throw new Error('Public health check failed.');console.log('PASS: public health check returns 200.');
const denied=await request('/health',{authenticated:false});if(denied.status!==401)throw new Error('Unauthenticated account access was not rejected.');console.log('PASS: private API rejects requests without credentials.');
const account=await request('/health');if(account.status!==200||!account.body.configured)throw new Error('Configured owner authentication failed.');console.log(`PASS: owner authenticated; mode=${account.body.mode}, accuracy=${account.body.accuracy}.`);
if(!process.argv.includes('--live'))process.exit(0);
const sessionId='cloud-smoke-'+randomUUID();let jobId;
try{
  const job=await request('/api/jobs',{method:'POST',body:{sessionId,message:'Help me find a laptop.',timezone:'Asia/Calcutta'}});
  if(job.status!==202)throw new Error(job.body.error||'Could not start the live planner.');jobId=job.body.jobId;
  const start=Date.now();let stage='';
  while(Date.now()-start<115000){
    const poll=await request('/api/jobs/'+jobId);
    if(poll.body.stage&&poll.body.stage!==stage){stage=poll.body.stage;console.log(stage);}
    if(poll.body.status==='failed')throw new Error(poll.body.error||'Planner failed.');
    if(poll.body.status==='complete'){
      const r=poll.body.result;
      console.log(`LIVE result: action=${r.action?.type||'none'}; clarification=${/budget|spend|use|work|gaming|purpose/i.test(r.message)}.`);
      console.log('Assistant:',r.message);break;
    }
    await new Promise(resolve=>setTimeout(resolve,1000));
  }
}finally{
  if(jobId)await request('/api/jobs/'+jobId,{method:'DELETE'}).catch(()=>{});
  await request('/api/reset',{method:'POST',body:{sessionId}}).catch(()=>{});
}
