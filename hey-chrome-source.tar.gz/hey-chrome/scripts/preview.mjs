// Standalone, dependency-free UI preview. No Chrome privileges and no Gemini calls.
import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
const bridge=`const listeners=[]; let state={messages:[],flight:{},pending:null,busy:false,target:null,mode:'preview',error:''};let settings={backend:'http://127.0.0.1:8787',token:'UI-PREVIEW-ONLY',share:false};
const publish=()=>listeners.forEach(f=>f({type:'STATE',state:structuredClone(state)}));
const add=(role,text)=>state.messages.push({id:crypto.randomUUID(),role,text});
window.chrome={runtime:{onMessage:{addListener:f=>listeners.push(f)},sendMessage:async req=>{
if(req.type==='GET_STATE')return{state:structuredClone(state)};if(req.type==='GET_SETTINGS')return{settings};
if(req.type==='SETTINGS'){settings=req.settings;return{ok:true};}if(req.type==='HEALTH')return{configured:true,mode:'UI preview',model:'No AI calls'};
if(req.type==='RESET'){state.messages=[];state.flight={};state.pending=null;publish();return{ok:true};}
if(req.type==='BIND'){state.target={id:1,title:'Preview page · no browser control'};publish();return{ok:true};}
if(req.type==='VOICE'){return{error:'Voice runs in the installed extension. See README.md for setup.'};}
if(req.type==='STOP'||req.type==='CANCEL_ACTION'){state.pending=null;state.busy=false;publish();return{ok:true};}
if(req.type==='APPROVE'){state.pending=null;add('tool','UI PREVIEW: No real browser action was executed.');publish();return{ok:true};}
if(req.type==='TURN'){add('user',req.text);state.busy=true;publish();await new Promise(r=>setTimeout(r,350));let answer;
if(/laptop|computer|budget/i.test(req.text))answer='What is your budget, and what will you use it for—work, gaming, or study? Any preferred screen size?';
else if(/summar|page/i.test(req.text))answer='Choose the page you want me to read, then enable sharing for that site. I can summarize the key ideas and answer your questions about it.';
else if(/flight|goa|delhi/i.test(req.text))answer='Sure. What date would you like to depart, and is this a one-way or round trip?';
else {answer='Here is a search I could open for you. This is an interface preview; install the extension and configure Gemini for real browsing.';state.pending={id:crypto.randomUUID(),action:{type:'navigate',url:'https://www.google.com/search?q='+encodeURIComponent(req.text)}};}
add('assistant',answer);state.busy=false;publish();return{ok:true};}
return{ok:true};}},tabs:{get:async()=>({url:'https://example.com'})},permissions:{request:async()=>false}};`;
const server=createServer(async(req,res)=>{
  const name=({'/':'panel.html','/panel.html':'panel.html','/styles.css':'styles.css','/panel.js':'panel.js','/voice.html':'voice.html','/voice.js':'voice.js'})[req.url];
  if(req.url==='/preview-bridge.js'){res.setHeader('content-type','text/javascript');return res.end(bridge);}
  if(!name){res.writeHead(404);return res.end('Not found');}
  try{let data=await readFile(new URL('../extension/'+name,import.meta.url));if(name.endsWith('.html'))data=data.toString().replace('</head>','<script src="/preview-bridge.js"></script></head>');res.setHeader('content-type',name.endsWith('.html')?'text/html':name.endsWith('.css')?'text/css':'text/javascript');res.setHeader('cache-control','no-store');res.end(data);}catch{res.writeHead(500);res.end('Preview failed');}
});
server.listen(8788,'127.0.0.1',()=>console.log('UI preview: http://127.0.0.1:8788 · simulated responses; no real browser control or AI calls.'));
