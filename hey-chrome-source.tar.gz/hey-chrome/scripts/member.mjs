import { cpSync, mkdirSync, writeFileSync, readFileSync } from 'node:fs';
import { resolve, join, relative, sep } from 'node:path';
import { randomBytes, randomUUID } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { hashToken, readMembers, writeMembers } from '../server/access.mjs';
const root=fileURLToPath(new URL('../',import.meta.url));
const file=resolve(root,process.env.ACCESS_FILE || '.data/access.json');
const [command,name,server]=process.argv.slice(2);
const members=readMembers(file);
if(command==='list') {
  console.table(members.map(({id,name,revoked,createdAt})=>({id,name,revoked:Boolean(revoked),createdAt})));
} else if(command==='revoke') {
  const member=members.find(m=>m.id===name);if(!member)throw new Error('Member ID not found. Run list.');
  member.revoked=true;writeMembers(file,members);console.log('Access revoked. Already completed requests cannot be undone.');
} else if(command==='add' || command==='owner') {
  if(!name || name.length>80)throw new Error('Supply a display name up to 80 characters.');
  const url=new URL(server || 'http://127.0.0.1:8787');
  if((url.protocol!=='https:' && !(url.protocol==='http:'&&url.hostname==='127.0.0.1')) || url.username || url.password || url.pathname!=='/' || url.search || url.hash)throw new Error('Use an HTTPS server origin, or local http://127.0.0.1:PORT.');
  const token=command==='owner'?process.env.BACKEND_TOKEN:randomBytes(32).toString('hex');
  if(!token || token.length<32)throw new Error('Load .env with node --env-file=.env.');
  const id=randomUUID();
  const slug=name.replace(/[^a-zA-Z0-9_-]/g,'-').slice(0,40)||'member';
  const output=resolve(root,'exports',`${slug}-${id.slice(0,8)}`);
  if(relative(resolve(root,'exports'),output).startsWith('..'+sep))throw new Error('Invalid output path.');
  mkdirSync(output,{recursive:true});cpSync(join(root,'extension'),join(output,'extension'),{recursive:true});
  const assistantName=(process.env.ASSISTANT_NAME||'Hey Chrome').slice(0,45);
  writeFileSync(join(output,'extension','connection.local.json'),JSON.stringify({backend:url.origin,token,assistantName,memberName:name},null,2)+'\n',{mode:0o600});
  const manifest=JSON.parse(readFileSync(join(output,'extension','manifest.json'),'utf8'));manifest.name=`${assistantName} · Voice Copilot`;
  writeFileSync(join(output,'extension','manifest.json'),JSON.stringify(manifest,null,2)+'\n');
  writeFileSync(join(output,'INSTALL.txt'),`Install this extension folder using Chrome > Extensions > Developer mode > Load unpacked.\nServer: ${url.origin}\nMember: ${name}\nOpen Settings and Save once to grant HTTPS server access. The Gemini key is on the server.\nThis package contains a personal access code; share only with its intended member.\n`);
  if(command==='add'){members.push({id,name,tokenHash:hashToken(token),createdAt:new Date().toISOString(),revoked:false});writeMembers(file,members);}
  console.log(`Created ${command==='owner'?'private owner':'named member'} extension: ${output}`);
  if(command==='add')console.log(`Member ID: ${id}. Use this ID to revoke access. No email was sent.`);
} else throw new Error('Usage: node --env-file=.env scripts/member.mjs owner|add "Name" [https://your-server.example] | list | revoke MEMBER_ID');
