import { readdirSync, readFileSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
for (const dir of ['server','extension','scripts','tests','qa']) for (const f of readdirSync(dir)) {
  if (/\.(m?js)$/.test(f)) {
    const r = spawnSync(process.execPath, ['--check',`${dir}/${f}`], { encoding: 'utf8' });
    if (r.status) { console.error(r.stderr); process.exit(1); }
  }
}
const manifest = JSON.parse(readFileSync('extension/manifest.json'));
for (const file of [manifest.background.service_worker, manifest.side_panel.default_path, 'voice.html', 'search-snapshot.js']) readFileSync(`extension/${file}`);
console.log('JavaScript syntax and extension entry points OK.');
