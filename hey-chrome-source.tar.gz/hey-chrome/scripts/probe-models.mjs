const key=process.env.GEMINI_API_KEY;
const models=[...new Set([process.env.GEMINI_MODEL||'gemini-3.8-flash','gemini-3.5-flash','gemini-2.5-flash'])];
const results=await Promise.allSettled(models.map(async model=>{
  try{
    const r=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`,{method:'POST',headers:{'content-type':'application/json','x-goog-api-key':key},signal:AbortSignal.timeout(15000),body:JSON.stringify({contents:[{parts:[{text:'Reply with the single word OK.'}]}],generationConfig:{maxOutputTokens:128,thinkingConfig:model.startsWith('gemini-2.5')?{thinkingBudget:0}:{thinkingLevel:'low'}}})});
    if(!r.ok)return {model,status:r.status};const body=await r.json();return{model,status:r.status,answer:Boolean(body.candidates?.[0]?.content?.parts?.some(p=>!p.thought&&p.text))};
  }catch(e){return{model,error:e.name};}
}));
for(const r of results)console.log(JSON.stringify(r.value||{error:'Probe failed'}));
