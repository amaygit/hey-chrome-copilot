# One assistant, several computers, named members

The setup is: each Chrome extension → one HTTPS backend → your centrally stored Gemini credentials. Each computer controls its own browser. Your mailbox is not involved.

## What is already done

- Your private server copy has both supplied Gemini credentials configured once.
- The personal extension is pre-connected to `http://127.0.0.1:8787` for local use.
- You can create named, revocable member extension packages.
- The backend supports shared HTTPS clients, per-member chat isolation, request limits, grounded public research and verification.
- Docker files are included for an always-on server.

## What is needed to reach it from another computer

You need a real, reachable **HTTPS backend URL**. `127.0.0.1` always means the current computer; it cannot reach the backend on your other computer. The backend machine must remain running. This project has not been deployed to a hosting account, and no account has been created on your behalf.

One option is a server you control running Node.js, with your domain and an HTTPS reverse proxy forwarding to `127.0.0.1:8787`. Keep the application's raw port private. Another is a container hosting service that supplies HTTPS. Set its secret environment variables using the values from your private server configuration. Do not upload `.env` into a public repository or put Gemini keys in extension source.

For Docker on a machine you control:

```powershell
# From the private project, with .env present:
docker compose up -d --build
```

The included compose configuration exposes the app only on the server's loopback port for an HTTPS reverse proxy and mounts `.data` for persistent member registrations. Configure a longer reverse-proxy timeout for `/api/turn` if using that direct API; the extension uses the faster job/poll endpoints. Ensure the container's node user can read your mounted member registry. Set `ALLOWED_EXTENSION_IDS` to approved IDs for a controlled deployment; unpacked extension IDs may differ across computers.

## Connect your own computers without retyping credentials

After you have the real HTTPS address, create a pre-connected owner package once:

```powershell
node --env-file=.env scripts/member.mjs owner "Owner" https://YOUR-REAL-SERVER
```

Copy the generated **exports/Owner-.../extension** folder to your other computers and load it unpacked in Chrome. Open Settings and click Save or Test once to grant access to the HTTPS server. No Gemini key and no `.env` is needed on these client computers. The owner code has broad owner access; use named members for other people.

## Give a person access by name

```powershell
node --env-file=.env scripts/member.mjs add "Alex" https://YOUR-REAL-SERVER
node --env-file=.env scripts/member.mjs list
node --env-file=.env scripts/member.mjs revoke MEMBER_ID
```

Send Alex only the generated **exports/Alex-...** folder (or zip that folder). It contains a member access code and the server URL, not your Gemini credentials. Your server stores only a hash of that member code. Keep its `.data/access.json` backed up. Revocation denies subsequent authenticated requests; it cannot undo completed actions or retract results already received. Editing a display name does not verify identity or send an invitation email.

Do not share **hey-chrome-private-ready.zip**: it is your private configured server project. The credential-free **hey-chrome.zip** is for sharing source code and is not a connected member invitation.

## Is adding a member free?

There is no per-member fee implemented by this application. Local unpacked extension installation does not involve a Chrome Web Store purchase. Gemini offers a limited free tier for eligible models/projects; paid usage, grounded search and hosting may incur costs. All members consume the centrally configured project's quota/billing. High-accuracy mode adds model calls. Multiple keys in the same Google project do not multiply project limits.

Publishing an extension through the Chrome Web Store requires its developer registration process and a one-time registration fee; this project has not been published. You do not need Microsoft Copilot or Copilot Studio for this custom application.

Sources: [Gemini pricing](https://ai.google.dev/gemini-api/docs/pricing), [Gemini project-level rate limits](https://ai.google.dev/gemini-api/docs/rate-limits), [Chrome Web Store registration](https://developer.chrome.com/docs/webstore/register).
