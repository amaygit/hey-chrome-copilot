# Render deployment

- Backend: https://hey-chrome-copilot.onrender.com
- Public liveness: https://hey-chrome-copilot.onrender.com/healthz
- Dashboard: https://dashboard.render.com/web/srv-dbvan2cs728c73dli6ug
- Source: https://github.com/amaygit/hey-chrome-copilot
- Plan: **Free ($0/month compute)**. Usage limits still apply.
- Region: Oregon. Runtime selected by Render: Node.js 26.13.1.
- AI configuration: Gemini 3.1 Flash-Lite, with separate planning and verification credentials.
- Build: `tar -xzf hey-chrome-source.tar.gz --strip-components=1 && node --check server/index.mjs`
- Start: `node server/index.mjs`; bind `0.0.0.0` on Render's supplied port.
- Health check: `/healthz`. Account/model information remains behind authenticated `/health`.

The source was made public with the owner's explicit approval. The uploaded archive was scanned for both Gemini credentials and the owner code; none were included. Runtime secrets were entered only in Render environment settings. Existing services and GitHub credentials were left unchanged.

## Update code

The repository versions a credential-free `hey-chrome-source.tar.gz` containing the project. Upload a new credential-free archive with that name and observe Render's linked deployment. Exclude `.env`, personal connection files, `.data` and exported access packages.

## Named users on the free plan

Render Free has temporary local storage. The deployed backend therefore uses its persistent **ACCESS_MEMBERS_JSON** environment setting as the member registry.

From your private project:

```powershell
node --env-file=.env scripts/member.mjs add "Alex" https://hey-chrome-copilot.onrender.com
node --env-file=.env scripts/export-render-env.mjs
```

Set Render's **ACCESS_MEMBERS_JSON** to the value exported in the private `exports/render-private.env`, then save/deploy. Share only Alex's generated extension folder. The registry contains hashes, not raw member codes. Keep the local registry as the source for future updates; do not overwrite a populated Render registry with an older copy.

To revoke: run `member.mjs revoke MEMBER_ID`, export again and update that Render variable. Saving environment settings restarts the service and clears in-memory chats, while saved AI credentials and membership persist. Gemini keys do not need to change when adding members.

[Render Free limits](https://render.com/docs/free) cover sleep, storage and usage. No paid compute plan or database was selected. Google's API usage has separate quota/billing.
