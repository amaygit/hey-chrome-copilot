# Use Hey Chrome on your computers

Backend: **https://hey-chrome-copilot.onrender.com**

1. Extract **hey-chrome-personal-extension.zip**.
2. In Chrome open `chrome://extensions`, enable **Developer mode**, click **Load unpacked**, and select the extracted **extension** folder.
3. Pin and open **Hey Chrome · Voice Copilot**. Click Settings → **Save** or **Test** once to allow access to the prefilled HTTPS server.
4. Try “Help me find a laptop.” Answer its follow-up questions and let routine searches and browsing run automatically.
5. In Settings choose **Allow browsing across websites once**. For speech: **Voice mode** → **Start listening**.
6. Try **Hey Chrome, quick search how does a solar eclipse happen** for visible Google content without a Gemini call. Normal booking and comparison requests still use Gemini.

Install this personal extension on your own other computers. Clients need **no Node.js, local server, .env file or Gemini key**. Each computer controls its own Chrome.

Keep the personal package for yourself: it contains your owner access code. Other people should receive named member packages. Gemini keys remain on the backend.

Render Free can take about a minute to wake after inactivity. Wait and retry if needed. Research uses Google pages by default when browsing access is enabled. The optional API path uses Tavily keyless and other configured providers. In Settings, allow browsing across websites once. Login, CAPTCHA and payment pause with a Resume button. Website behavior and voice recognition can vary; no accuracy percentage is guaranteed.
