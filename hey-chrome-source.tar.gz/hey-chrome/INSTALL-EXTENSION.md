# Use Hey Chrome on your computers

Backend: **https://hey-chrome-copilot.onrender.com**

1. Extract **hey-chrome-personal-extension.zip**.
2. In Chrome open `chrome://extensions`, enable **Developer mode**, click **Load unpacked**, and select the extracted **extension** folder.
3. Pin and open **Hey Chrome · Voice Copilot**. Click Settings → **Save** or **Test** once to allow access to the prefilled HTTPS server.
4. Try “Help me find a laptop.” Answer its follow-up questions and review proposed searches/actions.
5. For page reading/control: select a tab → **Use current tab** → **Allow this site**. For speech: **Voice mode** → **Start listening**.

Install this personal extension on your own other computers. Clients need **no Node.js, local server, .env file or Gemini key**. Each computer controls its own Chrome.

Keep the personal package for yourself: it contains your owner access code. Other people should receive named member packages. Gemini keys remain on the backend.

Render Free can take about a minute to wake after inactivity. Wait and retry if needed. If Google's grounded research quota is exhausted, the assistant can propose a separately reviewed browser search instead. Website behavior and voice recognition can vary; no accuracy percentage is guaranteed.
